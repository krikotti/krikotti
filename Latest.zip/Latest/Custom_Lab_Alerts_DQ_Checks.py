# Databricks notebook source
import sys, json, smtplib, email.mime.multipart, email.mime.text, email.mime.base, os, datetime
from pyspark.sql.functions import col, udf
from pyspark.sql.types import BooleanType
from datetime import datetime
from pyspark.sql import Window
from pyspark.sql.functions import count
from pyspark.sql.functions import lit, current_timestamp

# COMMAND ----------

#Maintains The Each Step Of The Main Pipeline Execution Used For Logging (Optional)
message=''
def step_control_log(log):
  global message
  message+= "\n" +log.replace("'","")

#Default Dictionary To Be Returned To The CDP Wrapper Notebook
return_dict = {
              "source_layer": "",
              "target_layer": "",
              "source_object_location":"",
              "source_object_name":"",
              "target_object_location":"",
              "target_object_name":"",
              "source_count":0,
              "target_count":0,
              "error_msg":"No Error",
              "message":""
            }

# COMMAND ----------

# Null NPI Check
def null_npi_check(schema_name, table_name):
  df = spark.sql(f"select * from {schema_name}.{table_name} where npi is null or npi=''")
  if df.count() > 0:
    df = df \
        .withColumn("error_message", lit("null npi")) \
        .withColumn("created_timestamp", current_timestamp())
    df.write \
    .format("delta") \
    .mode("append") \
    .option("overwriteSchema", "false") \
    .option("mergeSchema", "false") \
    .saveAsTable(f"{schema_name}.{table_name}_rejected")
    print(f"Null NPIs found in table {schema_name}.{table_name}")
    step_control_log(f"Null NPIs found in table {schema_name}.{table_name}")
    return 'Y'
  else:
    print(f"No null NPIs found in table {schema_name}.{table_name}")
    step_control_log(f"No null NPIs found in table {schema_name}.{table_name}")
    return 'N'

# COMMAND ----------

# Table Headers Check
def check_table_headers(schema_name, table_name, column_list):
    df = spark.sql(f"select * from {schema_name}.{table_name} limit 1")
    mand_col_status = True
    #Rertriving the columns in their order from config table 
    mandatory_column_list = [column.lower().strip() for column in column_list.split('|')]
    #Rertriving the columns in their order from the file 
    df_mandatory_column_list = [column.lower().strip() for column in df.columns]
    # comparing columns with their order from file with config table entry
    if mandatory_column_list == df_mandatory_column_list:
        print(f"Mandatory column names in the table {schema_name}.{table_name} matched\n")
        step_control_log(f"Mandatory column names in the table {schema_name}.{table_name} matched\n")
        return 'N'
    else:
        mand_col_status = False
        print(f"Mandatory column names in the {schema_name}.{table_name} are missing and do not match with the existing column names\n")
        step_control_log(f"Mandatory column names in the {schema_name}.{table_name} are missing and do not match with the existing column names\n")
        return 'Y'

# COMMAND ----------

# Duplicate Check
def check_duplicate_records(schema_name, table_name, duplicate_column_key):
    df = spark.sql(f"select * from {schema_name}.{table_name}")
    columns_list = [cl.strip() for cl in duplicate_column_key.split('|')]
    #creating a "window" grouped by columns_list
    window_spec = Window.partitionBy(columns_list)
    # adding analytical function window over it 
    count_column = count('*').over(window_spec).alias('count_1')
    #appling "count_column" over to daftarframe in order to receive number of records by this combination
    #used instead of regular group by in order to keep entire record and avoid additional joins
    df_count = df.select('*', count_column)
    #filtering out and keep only those which has duplicates
    duplicates_df = df_count.filter(col("count_1") > 1)
    duplicates_df = duplicates_df.drop("count_1")
    if duplicates_df.count() > 0:
      duplicates_df = duplicates_df \
          .withColumn("error_message", lit("duplicate record")) \
          .withColumn("created_timestamp", current_timestamp())
      duplicates_df.write \
      .format("delta") \
      .mode("append") \
      .option("overwriteSchema", "false") \
      .option("mergeSchema", "false") \
      .saveAsTable(f"{schema_name}.{table_name}_rejected")
      print(f"Duplicates found in the table {schema_name}.{table_name}\n")
      step_control_log(f"Duplicates found in the table {schema_name}.{table_name}\n")
      return 'Y'
    else:
      print(f"No duplicates found in the table {schema_name}.{table_name}\n")
      step_control_log(f"No duplicates found in the table {schema_name}.{table_name}\n")
      return 'N'

# COMMAND ----------

# Date Format Check
# Define a UDF to check the date format
def check_date_format(date_string):
    try:
        datetime.strptime(date_string, '%m/%d/%Y')
        return True
    except ValueError:
        return False

# Register the UDF
check_date_format_udf = udf(check_date_format, BooleanType())

# Date Format Check Function
def check_week_end_date_format(schema_name, table_name):
    df = spark.sql(f"SELECT * FROM {schema_name}.{table_name}")
    # Add a new column to indicate if the date format is correct
    df = df.withColumn("is_desired_date_format", check_date_format_udf(col("week_ending_date")))
    rejected_df = df.filter(col('is_desired_date_format') == False)
    if rejected_df.count() > 0:
      rejected_df = rejected_df.drop("is_desired_date_format")
      rejected_df = rejected_df \
          .withColumn("error_message", lit("week_ending_date is not in format: M/d/yyyy")) \
          .withColumn("created_timestamp", current_timestamp())
      rejected_df.write \
      .format("delta") \
      .mode("append") \
      .option("overwriteSchema", "false") \
      .option("mergeSchema", "false") \
      .saveAsTable(f"{schema_name}.{table_name}_rejected")
      print(f"Issue in Week Ending Date format in the table {schema_name}.{table_name}\n")
      step_control_log(f"Issue in Week Ending Date format in the table {schema_name}.{table_name}\n")
      return 'Y'
    else:
      print(f"No Issue in Week Ending Date format in the table {schema_name}.{table_name}\n")
      step_control_log(f"No Issue in Week Ending Date format in the table {schema_name}.{table_name}\n")
      return 'N'

# COMMAND ----------

# Trend Check- Current Count vs Avg Count
def trend_check_avg(schema_name, table_name):
  df = spark.sql(f"""
                 SELECT * 
                  FROM (
                      SELECT (((current_count - avg_count_last_5_weeks)/avg_count_last_5_weeks) * 100) AS percentage_deviation 
                      FROM (
                          SELECT AVG(week_count) AS avg_count_last_5_weeks, 
                                (SELECT COUNT(*) FROM {schema_name}.{table_name}) AS current_count
                          FROM (
                              SELECT COUNT(*) AS week_count
                              FROM {schema_name}.{table_name}_historical
                              WHERE created_timestamp >= DATEADD(week, -5, CURRENT_DATE)
                              GROUP BY YEAR(created_timestamp), WEEKOFYEAR(created_timestamp)
                          )
                      )
                  ) 
                  WHERE percentage_deviation > 5 or percentage_deviation < -5
                """)
  if df.count() > 0:
    print(f"Difference between average count and current count is greater/less than 5% in the table {schema_name}.{table_name}\n")
    step_control_log(f"Difference between average count and current count is greater/less than 5% in the table {schema_name}.{table_name}\n")
    return 'Y'
  else:
    print(f"Difference between average count and current count is in sync for the table {schema_name}.{table_name}\n")
    step_control_log(f"Difference between average count and current count is in sync for the table {schema_name}.{table_name}\n")
    return 'N'

# COMMAND ----------

# Trend Check- Current vs Previous Iteration
def trend_check_prev_vs_curr(schema_name, table_name):
  df = spark.sql(f"""
                 SELECT 
                      * 
                  FROM 
                      (SELECT 
                          (((current_count - prev_count)/prev_count) * 100) AS percentage_deviation 
                      FROM 
                          (SELECT 
                              COUNT(*) AS prev_count, 
                              (SELECT COUNT(*) FROM {schema_name}.{table_name}) AS current_count 
                          FROM 
                              (SELECT
                                  *,
                                  DENSE_RANK() OVER (ORDER BY created_timestamp DESC) AS dense_rank_column
                              FROM
                                  {schema_name}.{table_name}_historical
                              ) 
                          WHERE 
                              dense_rank_column = 2
                          )
                      ) 
                  WHERE 
                      percentage_deviation > 5 or percentage_deviation < -5
                  """)
  if df.count() > 0:
    print(f"Difference between previous count and current count is greater/less than 5% in the table {schema_name}.{table_name}\n")
    step_control_log(f"Difference between previous count and current count is greater/less than 5% in the table {schema_name}.{table_name}\n")
    return 'Y'
  else:
    print(f"Difference between previous count and current count is in sync for the table {schema_name}.{table_name}\n")
    step_control_log(f"Difference between previous count and current count is in sync for the table {schema_name}.{table_name}\n")
    return 'N'

# COMMAND ----------

def archive_file(schema_name, table_name):
  df = spark.sql(f"select distinct File_Name from {schema_name}.{table_name}")
  file_name_parts = df.select('File_Name').first()[0].split("_")[:-1]
  file_name_regex = "_".join(file_name_parts)
  print(f"file_name_regex--> {file_name_regex}")
  if 'diaceutics' in table_name:
    source_folder = "s3://tpc-aws-ted-prd-edpp-diaceutics-us-east-1/inbound/Lab_Alerts_Raw_Files/"
    archive_folder = f"s3://tpc-aws-ted-prd-edpp-diaceutics-us-east-1/inbound/archive/Lab_Alerts_Raw_Files/{datetime.now().strftime('%Y-%m-%d')}/"
  elif 'mmit' in table_name:
    source_folder = "s3://tpc-aws-ted-prd-edpp-mmit-us-east-1/inbound/Lab_Alerts_Raw_Files/"
    archive_folder = f"s3://tpc-aws-ted-prd-edpp-mmit-us-east-1/inbound/archive/Lab_Alerts_Raw_Files/{datetime.now().strftime('%Y-%m-%d')}/"
  print(f"source_folder--> {source_folder}")
  print(f"archive_folder--> {archive_folder}")
  files_in_s3 = dbutils.fs.ls(source_folder)
  for file in files_in_s3:
    file_name = file.name
    print(f"file_name--> {file_name.lower()}")
    print(f"file_name_regex--> {file_name_regex.lower()}")
    if file_name_regex.lower() in file_name.lower() or 'tak_disg_0001' in file_name.lower():
      print(f"Moving file {source_folder}{file_name} to {archive_folder}")
      step_control_log(f"Moving file {source_folder}{file_name} to {archive_folder}")
      dbutils.fs.mv(source_folder + file_name, archive_folder + file_name)

# COMMAND ----------

def send_email(dq_check_name, dq_check_flag, schema_name, table_name):
  email_body = ""
  #set sender email and password
  sender = "vivek.verma@takeda.com"
  #set receivers
  receivers = ["vivek.verma@takeda.com,apoorv.srivastava@takeda.com,chandan-kumar.singh@takeda.com"]
  main_msg = email.mime.multipart.MIMEMultipart()
  if dq_check_name == 'null_npi_check' and dq_check_flag == 'Y':
    email_body = f""" Null NPIs found in table {schema_name}.{table_name}, please check {schema_name}.{table_name}_rejected"""
  elif dq_check_name == 'null_npi_check' and dq_check_flag == 'N':
    email_body = f" No null NPIs found in table {schema_name}.{table_name}"
  elif dq_check_name == 'check_table_headers' and dq_check_flag == 'Y':
    email_body = f""" Mandatory column names in the {schema_name}.{table_name} are missing and does not match with the existing column names"""
  elif dq_check_name == 'check_table_headers' and dq_check_flag == 'N':
    email_body = f" Mandatory column names in the table {schema_name}.{table_name} matched"
  elif dq_check_name == 'check_duplicate_records' and dq_check_flag == 'Y':
    email_body = f""" Duplicates found in the table {schema_name}.{table_name}, please check {schema_name}.{table_name}_rejected"""
  elif dq_check_name == 'check_duplicate_records' and dq_check_flag == 'N':
    email_body = f" No duplicates found in the table {schema_name}.{table_name}"
  elif dq_check_name == 'check_week_end_date_format' and dq_check_flag == 'Y':
    email_body = f""" Issue in Week Ending Date format in the table {schema_name}.{table_name}, please check {schema_name}.{table_name}_rejected"""
  elif dq_check_name == 'check_week_end_date_format' and dq_check_flag == 'N':
    email_body = f" No Issue in Week Ending Date format in the table {schema_name}.{table_name}"
  elif dq_check_name == 'trend_check_avg' and dq_check_flag == 'Y':
    email_body = f""" Difference between average count and current count is greater/less than 5% in the table {schema_name}.{table_name}"""
  elif dq_check_name == 'trend_check_avg' and dq_check_flag == 'N':
    email_body = f" Difference between average count and current count is in sync for the table {schema_name}.{table_name}"
  elif dq_check_name == 'trend_check_prev_vs_curr' and dq_check_flag == 'Y':
    email_body = f""" Difference between previous count and current count is greater/less than 5% in the table {schema_name}.{table_name}"""
  elif dq_check_name == 'trend_check_prev_vs_curr' and dq_check_flag == 'N':
    email_body =f" Difference between previous count and current count is in sync for the table {schema_name}.{table_name}"
  
  if len(email_body) > 0:
    email_body = email_body.replace("""<html><body>""","""<html><style>
    table, th, td {
      border: 1px solid black;
      border-collapse: collapse;
      padding: 8px;  
    }
    </style><body>""")
    email_body = email_body.replace("""<th style="text-align: right;">""","""<th>""")
    email_body = email_body.replace("""<td style="text-align: right;">""","""<td>""")
    
    text_msg = email.mime.text.MIMEText(email_body, "html")
    #add MIMEText object to MIMEMultipart object
    main_msg.attach(text_msg)
    
    #create MIMEBase object
    contype = 'application/octet-stream'
    maintype, subtype = contype.split('/', 1)
    #set email format
    main_msg['From'] = sender
    main_msg['To'] = "; ".join(receivers)
    #main_msg['To'] = receivers
    
    main_msg['Subject'] = "Takeda Lab Alerts Job run status"
    main_msg['Date'] = email.utils.formatdate( ) 
    #full content of email
    message = main_msg.as_string()
    
    #send email by outlook smtp
    try:
        server = smtplib.SMTP('smtprelay.onetakeda.com')
        #server.ehlo()
        #server.starttls()
        #server.ehlo()    
        #server.login(sender,password)
        server.sendmail(sender, receivers, message)
        print ("Successfully sent email")
    except Exception as e:
        print ("Error: unable to send email, cause: ",e)

# COMMAND ----------

#Try/except block is used for handling exceptions in the user's code
try:
    param_dict_str = dbutils.widgets.get("custom_notebook_param")
    # param_dict_str = "schema_name:com_us_mart_obu_phx,table_name:lab_diaceutics_alu,mandatory_column_list:Week_Ending_Date|Practice_Name|Practice_Address_Line_1|Practice_Address_Line_2|City|State|Zip_Code|Provider_First_Name|Provider_Last_Name|NPI|Specialty_1|Specialty_2|Alert_Type|Count|LAB_SOURCE_FLAG|File_Name,duplicate_column_key:Week_Ending_Date|NPI|Alert_Type"

    # Splitting the input string by commas to separate key-value pairs
    pairs = param_dict_str.split(',')

    # Initializing an empty dictionary
    param_dict = {}

    # Iterating over the key-value pairs and adding them to the dictionary
    for pair in pairs:
        key, value = pair.split(':')
        param_dict[key] = value

    schema_name = param_dict["schema_name"]
    table_name = param_dict["table_name"]
    mandatory_column_list = param_dict["mandatory_column_list"]
    duplicate_column_key = param_dict["duplicate_column_key"]
    flag = null_npi_check(schema_name, table_name)
    send_email("null_npi_check", flag , schema_name, table_name)
    flag = check_table_headers(schema_name, table_name, mandatory_column_list)
    send_email("check_table_headers", flag , schema_name, table_name)
    flag = check_duplicate_records(schema_name, table_name, duplicate_column_key)
    send_email("check_duplicate_records", flag , schema_name, table_name)
    flag = check_week_end_date_format(schema_name, table_name)
    send_email("check_week_end_date_format", flag , schema_name, table_name)
    flag = trend_check_avg(schema_name, table_name)
    send_email("trend_check_avg", flag , schema_name, table_name)
    flag = trend_check_prev_vs_curr(schema_name, table_name)
    send_email("trend_check_prev_vs_curr", flag , schema_name, table_name)
    archive_file(schema_name, table_name)


    return_dict["source_layer"]='xyz'
    return_dict["target_layer"]='xyz'
    return_dict["source_object_location"]='xyz'
    return_dict["source_object_name"]='xyz'
    return_dict["target_object_location"]='xyz'
    return_dict["target_object_name"]='xyz'
    return_dict["source_count"]=3
    return_dict["target_count"]=3
  
except Exception as e:
  #Any Error In The User's Code Will Execute This Block And Updating The Default error_msg Value In The Dictionary
  return_dict.update({"error_msg":str(e)})
finally:
  #The Notebook Exit Command Will Exit Once The User's Code Is Executed And It Returns The User-Updated Dictionary In String Format
  return_dict.update({"message":message})
  dbutils.notebook.exit(json.dumps(return_dict))
