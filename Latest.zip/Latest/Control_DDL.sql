CREATE TABLE dbx_uc_usdev.abc_us_hub.audit_table (
  USERNAME STRING,
  USER_ID BIGINT,
  JOB_ID BIGINT,
  RUN_ID BIGINT,
  JOB_NAME STRING,
  TRIGGER_TYPE STRING,
  OPERATION_TIMESTAMP TIMESTAMP,
  VERSION BIGINT,
  OPERATION STRING,
  SRC_SYSTEM STRING,
  TGT_TBL_NM STRING,
  AUD_DTM TIMESTAMP,
  SRC_TOTAL_RECORDS BIGINT,
  TGT_TOTAL_RECORDS BIGINT,
  TGT_RECORDS_INSERTED BIGINT,
  TGT_RECORDS_UPDATED BIGINT,
  TGT_RECORDS_DELETED BIGINT,
  TGT_RECORDS_SKIPPED BIGINT,
  CLUSTER_ID STRING)
USING delta
LOCATION 's3://abcd-us-east-1/abc_us_hub/PPM/audit_table/DELTA';

Sample:
USERNAME	USER_ID	JOB_ID	RUN_ID	JOB_NAME	TRIGGER_TYPE	OPERATION_TIMESTAMP	VERSION	OPERATION	SRC_SYSTEM	TGT_TBL_NM	AUD_DTM	SRC_TOTAL_RECORDS	TGT_TOTAL_RECORDS	TGT_RECORDS_INSERTED	TGT_RECORDS_UPDATED	TGT_RECORDS_DELETED	TGT_RECORDS_SKIPPED	CLUSTER_ID
kkk@gmail	101724			null	null	2022-03-15T07:36:33.000+00:00	8	MERGE	hub	abc_us_hub.txn_disco_input_ppm_glbl_stg 	2022-04-28T11:38:34.558+00:00		7772	1616	0	0	0	0927-170152-arid674


CREATE TABLE dbx_uc_usdev.abc_us_hub.audit_log (
  OPERATION_TIMESTAMP TIMESTAMP COMMENT 'The timestamp of the operation, indicating when the action was performed.',
  OPERATION_TYPE STRING COMMENT 'Represents the type of operation that was executed, such as insert, update, or delete.',
  SRC_SYSTEM STRING COMMENT 'The name of the source system that initiated the operation.',
  SRC_TBL_NM STRING COMMENT 'The name of the source table from which the operation originated.',
  TGT_TBL_NM STRING COMMENT 'The name of the target table where the operation was applied.',
  TGT_RECORDS_INSERTED BIGINT COMMENT 'The number of records inserted into the target table as a result of the operation.',
  TGT_RECORDS_UPDATED BIGINT COMMENT 'The number of records updated in the target table as a result of the operation.',
  TGT_RECORDS_DELETED BIGINT COMMENT 'The number of records deleted from the target table as a result of the operation.',
  CLUSTER_ID STRING COMMENT 'A unique identifier for the cluster that the operation was associated with. This can be used to track and analyze operations within specific clusters.')
USING delta
COMMENT 'The \'audit_log\' table records all operations performed on the US hub\'s data. It includes details such as the timestamp, operation type, source system, target table, and the number of records inserted, updated, and deleted. This data can be used to monitor and analyze the activity on the US hub, providing insights into the frequency and nature of data operations. It can also be used to track the performance of the hub and identify potential issues or bottlenecks.'
LOCATION 's3://tpc-aws-ted-dev-edpp-hub-gms-us-east-1/abc_us_hub/PPM/audit_log_n/DELTA';

Sample Record:
OPERATION_TIMESTAMP	OPERATION_TYPE	SRC_SYSTEM	SRC_TBL_NM	TGT_TBL_NM	TGT_RECORDS_INSERTED	TGT_RECORDS_UPDATED	TGT_RECORDS_DELETED	CLUSTER_ID
2022-04-26T12:39:40.000+00:00	MERGE	HUB	abc_us_hub.source_dummy	abc_us_hub.target_dummy	2	0	0	0224-170209-doors220



CREATE TABLE dbx_uc_usdev.gms_us_mart.gmsgq_hubtomart_batch_audit_job_master (
  src_system STRING,
  tgt_tbl_nm STRING,
  src_tbl_nm STRING,
  status STRING,
  full_load_flg STRING,
  load_dtm TIMESTAMP,
  load_month STRING,
  batch_id BIGINT,
  log_file_nm STRING,
  nb_job_link STRING)
USING delta
PARTITIONED BY (src_system, src_tbl_nm, tgt_tbl_nm, load_month)
LOCATION 's3://tpc-aws-ted-dev-edpp-mart-gms-us-east-1/gms_us_mart/GMSGQ_DDM/BATCH/gmsgq_hubtomart_batch_audit_job_master'
TBLPROPERTIES (
  'Type' = 'EXTERNAL',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2',
  'upgraded_to' = 'dbx_uc_usdev.gms_us_mart.gmsgq_hubtomart_batch_audit_job_master')
  
  
  ENG	gms_us_mart.ref_equipment_eng_glbl	gms_us_hub.ref_equip_eng_glbl	completed	N	2024-05-21T12:46:34.942+00:00	2024-05	1716295425	eng-ref_equip_eng_glbl-ref_equipment_eng_glbl-20240521124330.txt	https://onetakeda-usdev.cloud.databricks.com/?o=631113751561990#/job/922623941265396/run/1
ENG	gms_us_mart.ref_equipment_eng_glbl	gms_us_hub.ref_equip_eng_glbl	completed	N	2024-05-22T09:51:15.480+00:00	2024-05	1716371289	eng-ref_equip_eng_glbl-ref_equipment_eng_glbl-20240522094753.txt	https://onetakeda-usdev.cloud.databricks.com/?o=631113751561990#/job/508033822184036/run/1
ENG	gms_us_mart.ref_equipment_eng_glbl	gms_us_hub.ref_equip_eng_glbl	completed	N	2024-05-25T04:17:38.274+00:00	2024-05	1716610515	eng-ref_equip_eng_glbl-ref_equipment_eng_glbl-20240525041417.txt	https://onetakeda-usdev.cloud.databricks.com/?o=631113751561990#/job/867321328777988/run/1


CREATE TABLE dbx_uc_usdev.gms_us_mart.gmsgq_hubtomart_batch_audit_job_log (
  BATCH_ID BIGINT,
  SRC_SYSTEM STRING,
  SRC_TBL_NM STRING,
  TGT_TBL_NM STRING,
  OP_FLG STRING,
  FULL_LOAD_FLG STRING,
  AUD_DTM TIMESTAMP,
  SRC_TOTAL_RECORDS BIGINT,
  TGT_TOTAL_RECORDS BIGINT,
  TGT_RECORDS_INSERTED BIGINT,
  TGT_RECORDS_UPDATED BIGINT,
  TGT_RECORDS_DELETED BIGINT,
  TGT_RECORDS_SKIPPED BIGINT,
  CLUSTER_ID STRING)
USING delta
PARTITIONED BY (SRC_SYSTEM, SRC_TBL_NM, TGT_TBL_NM)
LOCATION 's3://tpc-aws-ted-dev-edpp-mart-gms-us-east-1/gms_us_mart/GMSGQ_DDM/BATCH/gmsgq_hubtomart_batch_audit_job_log'
TBLPROPERTIES (
  'Type' = 'EXTERNAL',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2',
  'upgraded_to' = 'dbx_uc_usdev.gms_us_mart.gmsgq_hubtomart_batch_audit_job_log')
  
  BATCH_ID	SRC_SYSTEM	SRC_TBL_NM	TGT_TBL_NM	OP_FLG	FULL_LOAD_FLG	AUD_DTM	SRC_TOTAL_RECORDS	TGT_TOTAL_RECORDS	TGT_RECORDS_INSERTED	TGT_RECORDS_UPDATED	TGT_RECORDS_DELETED	TGT_RECORDS_SKIPPED	CLUSTER_ID
1719576497	ENG	gms_us_hub.ref_equip_eng_glbl	gms_us_mart.ref_equipment_eng_glbl	MERGE	N	2024-06-28T12:10:06.513+00:00	0	0	0	0	0	0	0628-120010-mb60ki7s
1718712475	ENG	gms_us_hub.ref_equip_eng_glbl	gms_us_mart.ref_equipment_eng_glbl	MERGE	N	2024-06-18T12:10:05.963+00:00	0	0	0	0	0	0	0618-120025-u72fvy1v
1718280602	ENG	gms_us_hub.ref_equip_eng_glbl	gms_us_mart.ref_equipment_eng_glbl	MERGE	N	2024-06-13T12:11:59.201+00:00	2	0	0	0	0	2	0613-120016-sgm2rmma
1719058031	ENG	gms_us_hub.ref_equip_eng_glbl	gms_us_mart.ref_equipment_eng_glbl	MERGE	N	2024-06-22T12:09:12.165+00:00	0	0	0	0	0	0	0622-120016-jp4tgfti
1718021217	ENG	gms_us_hub.ref_equip_eng_glbl	gms_us_mart.ref_equipment_eng_glbl	MERGE	N	2024-06-10T12:08:57.387+00:00	0	0	0	0	0	0	0610-120009-u0e53m87
1718539662	ENG	gms_us_hub.ref_equip_eng_glbl	gms_us_mart.ref_equipment_eng_glbl	MERGE	N	2024-06-16T12:09:43.869+00:00	0	0	0	0	0	0	0616-120039-mkynw2tv



CREATE TABLE dbx_uc_usdev.gms_us_lake.auto_data_ingestion_config (
  File_Name STRING,
  File_Type STRING,
  Column_Name STRING,
  Data_Type STRING,
  Null_NotNull STRING,
  Date_Timestamp_Format STRING,
  Table_Type STRING,
  Table_Name STRING,
  Load_Strategy STRING,
  Status_Flag STRING)
USING parquet
LOCATION 's3://tpc-aws-ted-dev-edpp-lake-gms-us-east-1/gms_us_lake/GMSGQ_MI/EHS_POC/AUTO_DATA_INGESTION_CONFIG'


File_Name	File_Type	Column_Name	Data_Type	Null_NotNull	Date_Timestamp_Format	Table_Type	Table_Name	Load_Strategy	Status_Flag
EHS_TEST_1	CSV	col1	String	Not Null	null	Ref	EHS_TEST_1	Append	New
EHS_TEST_1	CSV	col2	String	Null	null	Ref	EHS_TEST_1	Append	New
EHS_TEST_1	CSV	col3	String	Null	null	Ref	EHS_TEST_1	Append	New
EHS_TEST_1	CSV	col4	String	Null	null	Ref	EHS_TEST_1	Append	New


CREATE TABLE dbx_uc_usdev.gms_us_lake.batch_load_mstr (
  ID STRING NOT NULL,
  BATCH_ID BIGINT NOT NULL,
  BATCH_STATUS STRING,
  BATCH_START_TIME TIMESTAMP,
  BATCH_END_TIME TIMESTAMP,
  PROJECT_LINE STRING NOT NULL,
  SOURCE_SYSTEM STRING NOT NULL,
  SOURCE_LAYER STRING NOT NULL,
  TARGET_LAYER STRING NOT NULL,
  COMMENTS STRING)
USING delta
PARTITIONED BY (BATCH_ID, PROJECT_LINE, SOURCE_SYSTEM, SOURCE_LAYER, TARGET_LAYER)
LOCATION 's3://tpc-aws-ted-dev-edpp-lake-gms-us-east-1/gms_us_lake/GMSGQ/AUDIT/BATCH_LOAD_MSTR_test1'
TBLPROPERTIES (
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2',)
  
  ID	BATCH_ID	BATCH_STATUS	BATCH_START_TIME	BATCH_END_TIME	PROJECT_LINE	SOURCE_SYSTEM	SOURCE_LAYER	TARGET_LAYER	COMMENTS
f15d28a58b5a8b3efacf585a14bb6699	20200609183512	COMPLETED	2020-06-09T18:35:12.878+00:00	2020-06-09T18:37:12.173+00:00	gmsgqmi	apds	LAKE	HUB	 
5990b324a18fff096db1fc1e1eca0513	20200611145509	RUNNING	2020-06-11T14:55:09.559+00:00	-	gmsgqmi	apds	LAKE	HUB	null
8367893b26611e2c7d65810d230f5fef	20200611145509	RUNNING	2020-06-11T14:55:09.888+00:00	-	gmsgqmi	apds	SRC	LAKE	null


CREATE TABLE hive_metastore.eds_us_lake_cdp.batch_metadata (
  Batch_Id INT,
  App_Id STRING,
  Batch_Name STRING,
  Batch_Description STRING,
  Created_Date_Time TIMESTAMP,
  Created_User STRING,
  Updated_Date_Time TIMESTAMP,
  Updated_User STRING,
  Execution_Engine STRING)
USING delta
LOCATION 's3://tpc-aws-ted-dev-edpp-lake-cdp-us-east-1/eds_us_lake_cdp/batch_metadata/delta'
TBLPROPERTIES (
  'delta.columnMapping.mode' = 'name',
  'delta.minReaderVersion' = '2',
  'delta.minWriterVersion' = '5')
  
  Batch_Id	App_Id	Batch_Name	Batch_Description	Created_Date_Time	Created_User	Updated_Date_Time	Updated_User	Execution_Engine
236762	ENTITY9_DEMO	CDP-APPNAME-ENTITY9-DEMO	Parent batch job for DQ demo app	2024-06-07T17:37:04.233+00:00	ana-karen.perez@takeda.com	-	null	Tidal
237185	AXTCOMMAPP0001	GIBU-IBD-EPSILON-DAILY-ORCHESTRATION	GIBU-IBD-EPSILON-DAILY-ORCHESTRATION	2024-06-19T08:01:17.633+00:00	n.naveena@takeda.com	2024-06-19T08:01:17.633+00:00	n.naveena@takeda.com	Tidal
28599	CDP-M-ERP	CDP-GIBU-SSR-TO-KAM-MAPPING-SIT	NA	-	NA	2022-08-16T14:25:33.000+00:00	NA	Tidal
33763	CDP-D-NONERP	CDP-GIBU-SSR-TO-KAM-MAPPING-SIT	NA	-	NA	2022-08-16T14:25:27.000+00:00	NA	Tidal

Batch_Id	App_Id	Batch_Name	Batch_Description	Created_Date_Time	Created_User	Updated_Date_Time	Updated_User	Execution_Engine
POC-CDP-AIRFLOW-INGESTION	DEMO_APP	POC-CDP-AIRFLOW-INGESTION	Sample Ingestion Pipeline for Airflow	2024-02-05T10:09:32.985+00:00	mfn8642	2024-02-05T10:09:32.985+00:00	mfn8642	Airflow


CREATE TABLE hive_metastore.eds_us_lake_cdp.cdp_batch_log (
  Batch_Run_Id STRING,
  Batch_Id BIGINT,
  App_Id STRING,
  Batch_Status STRING,
  Batch_Start_Date_Time TIMESTAMP,
  Batch_End_Date_Time TIMESTAMP,
  Error_Description STRING,
  Batch_Run_User_Id STRING,
  Created_Date_Time TIMESTAMP,
  MD5_HASH STRING,
  Tidal_Batch_No INT,
  Duration DOUBLE,
  Average_Run DOUBLE,
  load_dtm TIMESTAMP,
  load_month STRING,
  Src_system STRING,
  Tgt_tbl_nm STRING,
  Src_tbl_nm STRING,
  Log_file_Nm STRING,
  lake_to_hub_batch_run_id BIGINT,
  batch_load_flg STRING,
  Pipeline_Type STRING)
USING delta
PARTITIONED BY (Batch_Id)
LOCATION 's3://tpc-aws-ted-dev-edpp-lake-cdp-us-east-1/eds_us_lake_cdp/cdp_batch_log/delta'
TBLPROPERTIES (
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2')
CREATE TABLE hive_metastore.eds_us_lake_cdp.cdp_dq_rule_type (
  Check_Type_Id INT,
  Check_Type_Nm STRING)
USING delta
TBLPROPERTIES (
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2')
  
  
  Check_Type_Id	Check_Type_Nm
1	Not Null Check
2	Referential Integrity Check
3	Domain Check
4	Count Check
5	Number Check
6	Non Zero Check
7	Pattern Check
8	Data Availability Check
9	Uniqueness Check
10	Range Check
11	Data Availability Range Check
12	Count Distinct Check
13	Sum Check
14	Variation Count Check
15	Variation Count Distinct Check
16	Trend Sum Check
18	Comparision Check
19	Date Format Check
20	Length Check
21	Variation Sum Check
24	Trend Count Distinct Check
25	Custom SQL Check


CREATE TABLE hive_metastore.eds_us_lake_cdp.cdp_job_log (
  Job_Run_Id STRING,
  Job_Id BIGINT,
  Batch_Run_Id STRING,
  Tidal_Job_No INT,
  Source_Layer STRING,
  Source_Object_Location STRING,
  Source_Object_Name STRING,
  Target_Layer STRING,
  Target_Object_Location STRING,
  Target_Object_Name STRING,
  Status STRING,
  Status_Source STRING,
  Step_Control_Log STRING,
  Job_Scheduled_Date_Time TIMESTAMP,
  Job_Start_Date_Time TIMESTAMP,
  Job_End_Date_Time TIMESTAMP,
  Error_Description STRING,
  Source_Record_Count BIGINT,
  Target_Record_Count BIGINT,
  MD5_HASH STRING,
  User_Id STRING,
  Created_Date_Time TIMESTAMP,
  Duration DOUBLE,
  Average_Run DOUBLE,
  Src_system STRING,
  Cluster_Id STRING,
  Tgt_records_inserted BIGINT,
  Tgt_records_updated BIGINT,
  Tgt_records_deleted BIGINT,
  Tgt_records_skipped BIGINT,
  lake_to_hub_batch_run_id BIGINT,
  Pipeline_Type STRING,
  aud_dtm TIMESTAMP)
USING delta
PARTITIONED BY (Job_Id)
LOCATION 's3://tpc-aws-ted-dev-edpp-lake-cdp-us-east-1/eds_us_lake_cdp/cdp_job_log/delta'
TBLPROPERTIES (
  'delta.columnMapping.mode' = 'name',
  'delta.minReaderVersion' = '2',
  'delta.minWriterVersion' = '5')
  
  
  Job_Run_Id	Job_Id	Batch_Run_Id	Tidal_Job_No	Source_Layer	Source_Object_Location	Source_Object_Name	Target_Layer	Target_Object_Location	Target_Object_Name	Status	Status_Source	Step_Control_Log	Job_Scheduled_Date_Time	Job_Start_Date_Time	Job_End_Date_Time	Error_Description	Source_Record_Count	Target_Record_Count	MD5_HASH	User_Id	Created_Date_Time	Duration	Average_Run	Src_system	Cluster_Id	Tgt_records_inserted	Tgt_records_updated	Tgt_records_deleted	Tgt_records_skipped	lake_to_hub_batch_run_id	Pipeline_Type	aud_dtm
36d46913-c048-45db-a55e-0753706ca327|195302	195302	01519603-b6b1-43a4-95e9-2b1a90a183bf|195027	25584721	LAKE	None	Refer sql_for_run column for source table	HUB	None	corp_us_hub.txn_limits_cashcloud_glbl	Completed Normally	Databricks	"
Inside Data Integration
Master Query : select * from eds_us_lake_cdp.cdp_entity_mstr where app_id = TREASURY and entity_id = API_LIMITS_lake_to_hub
Layers Parsed Values from Jobname : 030-CDP-CASHCLOUD-API-LIMITS-LAKE-TO-HUB - Source_layer = LAKE, Target_Layer = HUB, allowed_values = [raw, lake, hub, mart]
Metadata : {""app_id"": ""TREASURY"", ""entity_id"": ""API_LIMITS_lake_to_hub"", ""batch_id"": ""195027"", ""job_id"": ""195302"", ""sns_topic_arn"": ""arn:aws:sns:us-east-1:263789222982:CASHCLOUD-DEV"", ""entity_name"": ""API_LIMITS_lake_to_hub"", ""base_url"": """", ""queryStringParams"": """", ""pagination_flag"": false, ""last_fetch_time"": null, ""api_limit"": null, ""secret_name"": """", ""aws_region"": ""us-east-1c"", ""iics_project_folder"": null, ""source_connector"": null, ""source_staging_loc"": null, ""s3_raw_file_location"": """", ""raw_file_type"": null, ""raw_file_name"": """", ""raw_file_header_flg"": false, ""raw_file_header_columns"": """", ""null_exception_list"": null, ""raw_file_delimiter"": """", ""raw_file_infer_schema_flg"": null, ""ingest_raw_excel_file_sheet_name"": null, ""raw_enclosure_character"": """", ""raw_escape_flag"": null, ""raw_escape_character"": null, ""raw_encoding_type"": """", ""raw_file_skip_rows"": """", ""load_type"": """", ""source_timestamp_column"": null, ""source_primarykey_columns"": """", ""source_CDC_columns"": null, ""archive_raw_file_flg"": null, ""source_table_schema"": ""corp_us_lake"", ""source_table_name"": ""cashcloud_limits"", ""source_pre_sql"": null, ""source_post_sql"": null, ""target_connector"": null, ""target_staging_loc"": null, ""s3_lake_file_location"": """", ""lake_file_name"": """", ""target_table_schema"": null, ""target_table_name"": null, ""dynamic_schema_flg"": null, ""target_pre_sql"": null, ""target_post_sql"": null, ""hse_kep_sql_bfr"": """", ""sql_for_run"": ""with w_limits_lake as (
  select
    *
  from
    (
      select
        row_number() over (
          Partition by Transaction_number,
          Report_date
          order by
            load_cdp_time desc
        ) as rn,
        Company,
        Counterparty,
        Intermediary,
        On_behalf_of,
        Transaction_type,
        Transaction_category,
        Transaction_number,
        Status,
        Transaction_currency,
        Transaction_Code,
        cast(replace(Transaction_amount,  , ) as Double) as Transaction_amount,
        cast(replace(Rate, ,) as Double) as Rate,
        Direction_2,
        Countervalue_currency,
        Cast(replace(Countervalue_amount,  , ) as Double) as Countervalue_amount,
        Cast(replace(Rate_2, ,) as Double) as Rate_2,
        To_date(Transaction_date, MM/dd/yyyy) as Transaction_date,
        To_date(Value_date, MM/dd/yyyy) as Value_date,
        cast(Year_start as INT) as Year_start,
        To_date(End_date, MM/dd/yyyy) as End_date,
        To_date(Fixing_date, MM/dd/yyyy) as Fixing_date,
        Portfolio,
        User_zone_1,
        User_zone_2,
        To_date(Report_date, MM/dd/yyyy) as Report_date,
        aud_batch_load_wid,
        aud_file_nm,
        aud_load_dts,
        aud_row_status_ind,
        aud_src_sys_id,
        aud_upd_dts,
        load_cdp_time
      from
        corp_us_lake.cashcloud_limits
    )
  where
    rn = 1
),
w_initial_col as (
  select
    l.*,
    cc_r.Currency_rate as DR,
    cast(1 / cc_r.Currency_rate as decimal(18, 7)) as IDR,
    rcc_r.Currency_rate as RCPR,
    Eur_cc_r.Currency_rate as EURJPY_Rate,
    Case
      when SA > PA then Y
      else N
    end as Condition_check
  from
    (
      select
        *,
        concat(Purchasing_Currency, Sales_Currency) as CP,
        Transaction_amount as TA,
        Rate as FR,
        case
          when Transaction_Code in (BFWD, NDFB,BNNF, BSPT, SFNS) then Transaction_amount
          else Countervalue_amount
        End as PA,
        case
          when Transaction_Code in (NDFS,SNNF, SFWD, SSPT, SFNF) then Transaction_amount
          else Countervalue_amount
        End as SA,
        case
          when Transaction_Code in (NDFS,SNNF, SFWD, SSPT, SFNF) and upper(Direction_2) =SELL then concat(Sales_Currency, Receive_Currency)
          else concat(Purchasing_Currency, Sales_Currency)
        end as RCP,
        Countervalue_amount as CV,
        rate_2 as CVR,
        Countervalue_currency as CC,
        Transaction_currency as TC
      from
        (
          select
            *,case
              when Transaction_Code in (BFWD, NDFB,BNNF, BSPT, SFNS) then Transaction_currency
              else Countervalue_currency
            End as Purchasing_Currency,
            case
              when Transaction_Code in (NDFS,SNNF, SFWD, SSPT, SFNF) then Transaction_currency
              else Countervalue_currency
            End as Sales_Currency,
            case
              when Transaction_Code in (NDFS,SNNF, SFWD, SSPT, SFNF) then Countervalue_currency
              else Transaction_currency
            End as Receive_Currency

          from
            w_limits_lake
        )
    ) as l
    left join corp_us_hub.txn_cross_currency_rate_cashcloud_glbl cc_r on l.Report_date = cc_r.date
    and l.CP = cc_r.Currency_pair
    left join corp_us_hub.txn_cross_currency_rate_cashcloud_glbl rcc_r on l.Report_date = rcc_r.date
    and l.RCP = rcc_r.Currency_pair
    left join corp_us_hub.txn_cross_currency_rate_cashcloud_glbl Eur_cc_r on l.Report_date = Eur_cc_r.date
    and Eur_cc_r.Currency_pair = EURJPY
),
w_add_new_col as (
  select *,MD5(
      concat(
        cast(a.Report_date as STRING),
        a.Transaction_number,
        COALESCE(cast(a.228_USD as STRING), ),
        COALESCE(cast(a.2780_JPY as STRING), ),
        COALESCE(cast(a.8000_EUR as STRING), ),
        COALESCE(cast(a.8000_JPY as STRING), )
      )
    ) as md5_key from (
  select
    *,
    (8000_EUR * EURJPY_Rate) as 8000_JPY
    
  from
    (
      select
        *,
        Case when Company = 28_IE_USD then Case
          when Transaction_Code = BFWD
          and CP = USDJPY
          and Condition_check = Y then (-(TA * FR) +(TA * DR))
          when Transaction_Code = BFWD
          and CP = AUDUSD
          and Condition_check = N then (-(TA * FR) +(TA * DR))
          when Transaction_Code = BFWD
          and CP in (CHDUSD, CNYUSD)
          and Condition_check = N then (-(TA / FR) +(TA / IDR))
          when Transaction_Code = SFWD
          and CP = GBPUSD
          and Condition_check = N then (-(TA * FR) +(PA * IDR))
          when Transaction_Code = SFWD
          and CP = USDAUD
          and Condition_check = N then (-(TA * FR) +(TA * DR))
          when Transaction_Code = SFWD
          and CP = USDNZD
          and Condition_check = N then (-(TA * FR) +(TA * DR))
          when Transaction_Code = SFWD
          and CP = USDGBP
          and Condition_check = N then (-(TA * FR) +(TA * RCPR))
          when Transaction_Code = SFWD
          and CP = USDEUR
          and Condition_check = Y then (-(TA * FR) +(TA * RCPR))
          when Transaction_Code = SFWD
          and CP = USDJPY
          and Condition_check = N then (-(TA / FR) +(TA / IDR))
          when Transaction_Code = BFWD
          and Condition_check = Y then (PA *((- FR) + DR))
          when Transaction_Code in (BFWD, SFWD, SSPT, BSPT, NDFS,SNNF)
          and Condition_check = N then (-(TA / FR) +(TA / IDR))
          when Transaction_Code = NDFB
          and Condition_check = N then (-(PA / FR) +(PA / IDR))
		  when Transaction_Code = BNNF
          and Condition_check = N then (-(PA / FR) +(PA / IDR))
          else 0
        end 
		else 0 end as 228_USD,
		
		
		case when company=2780_JP_JPY then
        Case
          when Transaction_Code = BFWD
          and CP = JPYUSD then ((CV / CVR) -(CV / IDR))
		  When Transaction_Code = SFWD then (-(TA * FR) +(TA * IDR))
		  when Transaction_Code = SSPT then (-(TA * FR) +(TA * IDR))
		  when Transaction_Code = SFNF then (-(TA) *(FR - IDR))		  
          When CP = JPYCNY then (-(TA * FR) +(TA * RCPR))          
          else (-(TA) *(FR - RCPR))
        end 
		else 0 end as 2780_JPY,
		
		
		case when company=8000_CH_EUR then
        Case
          when Transaction_Code = SSPT
          and CP = GBPEUR then (-(PA * FR) +(PA * IDR))
          when Transaction_Code = BFWD then (-(PA / FR) +(PA / IDR))
		  when Transaction_Code in (SFWD, NDFS,SNNF) then (-(TA / FR) +(TA / RCPR))
		  when Transaction_Code =SSPT then (-(PA / FR) + (PA / RCPR))
          when Transaction_Code in (NDFB,BNNF, BSPT) then (-(TA / FR) +(TA / IDR))
          else 0
        End
else 0 end	as 8000_EUR
      from
        w_initial_col)
    ) as a
) merge into corp_us_hub.txn_limits_cashcloud_glbl as hub using(
  select
    *
  from
    w_add_new_col
) as lake on hub.Transaction_number = lake.Transaction_number
and hub.Report_date = lake.Report_date
WHEN MATCHED
And hub.md5_key != lake.md5_Key THEN
UPDATE
SET
  hub.228_USD = lake.228_USD,
  hub.2780_JPY = lake.2780_JPY,
  hub.8000_EUR = lake.8000_EUR,
  hub.8000_JPY = lake.8000_JPY,
  hub.md5_key = lake.md5_key,
  hub.aud_batch_load_wid = lake.aud_batch_load_wid,
  hub.aud_file_nm = lake.aud_file_nm,
  hub.aud_load_dts = lake.aud_load_dts,
  hub.aud_row_status_ind = lake.aud_row_status_ind,
  hub.aud_src_sys_id = lake.aud_src_sys_id,
  hub.aud_upd_dts = lake.aud_upd_dts,
  hub.load_cdp_time = lake.load_cdp_time
  WHEN NOT MATCHED THEN
INSERT
  (
    Company,
    Counterparty,
    Intermediary,
    On_behalf_of,
    Transaction_typ,
    Transaction_category,
    Transaction_number,
    Status,
    Transaction_currency,
    Transaction_Code,
    Transaction_amount,
    Rate,
    Direction_2,
    Countervalue_currency,
    Countervalue_amount,
    Rate_2,
    Transaction_date,
    Value_date,
    Year_start,
    End_date,
    Fixing_date,
    Portfolio,
    User_zone_1,
    User_zone_2,
    Report_date,
    228_USD,
    2780_JPY,
    8000_EUR,
    8000_JPY,
    md5_key,
    aud_batch_load_wid,
    aud_file_nm,
    aud_load_dts,
    aud_row_status_ind,
    aud_src_sys_id,
    aud_upd_dts,
    load_cdp_time
  )
Values
  (
    lake.Company,
    lake.Counterparty,
    lake.Intermediary,
    lake.On_behalf_of,
    lake.Transaction_type,
    lake.Transaction_category,
    lake.Transaction_number,
    lake.Status,
    lake.Transaction_currency,
    lake.Transaction_Code,
    lake.Transaction_amount,
    lake.Rate,
    lake.Direction_2,
    lake.Countervalue_currency,
    lake.Countervalue_amount,
    lake.Rate_2,
    lake.Transaction_date,
    lake.Value_date,
    lake.Year_start,
    lake.End_date,
    lake.Fixing_date,
    lake.Portfolio,
    lake.User_zone_1,
    lake.User_zone_2,
    lake.Report_date,
    lake.228_USD,
    lake.2780_JPY,
    lake.8000_EUR,
    lake.8000_JPY,
    lake.md5_key,
    lake.aud_batch_load_wid,
    lake.aud_file_nm,
    lake.aud_load_dts,
    lake.aud_row_status_ind,
    lake.aud_src_sys_id,
    lake.aud_upd_dts,
    lake.load_cdp_time
  )"", ""hse_kep_sql_aft"": """", ""sql_for_source_count"": ""select count(*) from corp_us_lake.cashcloud_limits"", ""sql_for_target_count"": ""select count(*) from corp_us_hub.txn_limits_cashcloud_glbl where load_cdp_time=(select max(load_cdp_time) from corp_us_lake.cashcloud_limits)"", ""version_check"": false, ""version_check_src_tbl_nm"": """", ""Integration_file_configs"": """", ""Integration_archive_flg"": false, ""schedule_flg"": null, ""created_user"": ""vhb9972"", ""created_date_time"": ""2023-05-15 13:22:56.580000"", ""updated_user"": ""vhb9972"", ""updated_date_time"": ""2023-05-26 09:26:10.347000""}
Archive Enabled : False
Running Query : refresh table corp_us_lake.cashcloud_limits
Running Query : select count(*) from corp_us_lake.cashcloud_limits
Running Query : with w_limits_lake as (
  select
    *
  from
    (
      select
        row_number() over (
          Partition by Transaction_number,
          Report_date
          order by
            load_cdp_time desc
        ) as rn,
        Company,
        Counterparty,
        Intermediary,
        On_behalf_of,
        Transaction_type,
        Transaction_category,
        Transaction_number,
        Status,
        Transaction_currency,
        Transaction_Code,
        cast(replace(Transaction_amount,  , ) as Double) as Transaction_amount,
        cast(replace(Rate, ,) as Double) as Rate,
        Direction_2,
        Countervalue_currency,
        Cast(replace(Countervalue_amount,  , ) as Double) as Countervalue_amount,
        Cast(replace(Rate_2, ,) as Double) as Rate_2,
        To_date(Transaction_date, MM/dd/yyyy) as Transaction_date,
        To_date(Value_date, MM/dd/yyyy) as Value_date,
        cast(Year_start as INT) as Year_start,
        To_date(End_date, MM/dd/yyyy) as End_date,
        To_date(Fixing_date, MM/dd/yyyy) as Fixing_date,
        Portfolio,
        User_zone_1,
        User_zone_2,
        To_date(Report_date, MM/dd/yyyy) as Report_date,
        aud_batch_load_wid,
        aud_file_nm,
        aud_load_dts,
        aud_row_status_ind,
        aud_src_sys_id,
        aud_upd_dts,
        load_cdp_time
      from
        corp_us_lake.cashcloud_limits
    )
  where
    rn = 1
),
w_initial_col as (
  select
    l.*,
    cc_r.Currency_rate as DR,
    cast(1 / cc_r.Currency_rate as decimal(18, 7)) as IDR,
    rcc_r.Currency_rate as RCPR,
    Eur_cc_r.Currency_rate as EURJPY_Rate,
    Case
      when SA > PA then Y
      else N
    end as Condition_check
  from
    (
      select
        *,
        concat(Purchasing_Currency, Sales_Currency) as CP,
        Transaction_amount as TA,
        Rate as FR,
        case
          when Transaction_Code in (BFWD, NDFB,BNNF, BSPT, SFNS) then Transaction_amount
          else Countervalue_amount
        End as PA,
        case
          when Transaction_Code in (NDFS,SNNF, SFWD, SSPT, SFNF) then Transaction_amount
          else Countervalue_amount
        End as SA,
        case
          when Transaction_Code in (NDFS,SNNF, SFWD, SSPT, SFNF) and upper(Direction_2) =SELL then concat(Sales_Currency, Receive_Currency)
          else concat(Purchasing_Currency, Sales_Currency)
        end as RCP,
        Countervalue_amount as CV,
        rate_2 as CVR,
        Countervalue_currency as CC,
        Transaction_currency as TC
      from
        (
          select
            *,case
              when Transaction_Code in (BFWD, NDFB,BNNF, BSPT, SFNS) then Transaction_currency
              else Countervalue_currency
            End as Purchasing_Currency,
            case
              when Transaction_Code in (NDFS,SNNF, SFWD, SSPT, SFNF) then Transaction_currency
              else Countervalue_currency
            End as Sales_Currency,
            case
              when Transaction_Code in (NDFS,SNNF, SFWD, SSPT, SFNF) then Countervalue_currency
              else Transaction_currency
            End as Receive_Currency

          from
            w_limits_lake
        )
    ) as l
    left join corp_us_hub.txn_cross_currency_rate_cashcloud_glbl cc_r on l.Report_date = cc_r.date
    and l.CP = cc_r.Currency_pair
    left join corp_us_hub.txn_cross_currency_rate_cashcloud_glbl rcc_r on l.Report_date = rcc_r.date
    and l.RCP = rcc_r.Currency_pair
    left join corp_us_hub.txn_cross_currency_rate_cashcloud_glbl Eur_cc_r on l.Report_date = Eur_cc_r.date
    and Eur_cc_r.Currency_pair = EURJPY
),
w_add_new_col as (
  select *,MD5(
      concat(
        cast(a.Report_date as STRING),
        a.Transaction_number,
        COALESCE(cast(a.228_USD as STRING), ),
        COALESCE(cast(a.2780_JPY as STRING), ),
        COALESCE(cast(a.8000_EUR as STRING), ),
        COALESCE(cast(a.8000_JPY as STRING), )
      )
    ) as md5_key from (
  select
    *,
    (8000_EUR * EURJPY_Rate) as 8000_JPY
    
  from
    (
      select
        *,
        Case when Company = 28_IE_USD then Case
          when Transaction_Code = BFWD
          and CP = USDJPY
          and Condition_check = Y then (-(TA * FR) +(TA * DR))
          when Transaction_Code = BFWD
          and CP = AUDUSD
          and Condition_check = N then (-(TA * FR) +(TA * DR))
          when Transaction_Code = BFWD
          and CP in (CHDUSD, CNYUSD)
          and Condition_check = N then (-(TA / FR) +(TA / IDR))
          when Transaction_Code = SFWD
          and CP = GBPUSD
          and Condition_check = N then (-(TA * FR) +(PA * IDR))
          when Transaction_Code = SFWD
          and CP = USDAUD
          and Condition_check = N then (-(TA * FR) +(TA * DR))
          when Transaction_Code = SFWD
          and CP = USDNZD
          and Condition_check = N then (-(TA * FR) +(TA * DR))
          when Transaction_Code = SFWD
          and CP = USDGBP
          and Condition_check = N then (-(TA * FR) +(TA * RCPR))
          when Transaction_Code = SFWD
          and CP = USDEUR
          and Condition_check = Y then (-(TA * FR) +(TA * RCPR))
          when Transaction_Code = SFWD
          and CP = USDJPY
          and Condition_check = N then (-(TA / FR) +(TA / IDR))
          when Transaction_Code = BFWD
          and Condition_check = Y then (PA *((- FR) + DR))
          when Transaction_Code in (BFWD, SFWD, SSPT, BSPT, NDFS,SNNF)
          and Condition_check = N then (-(TA / FR) +(TA / IDR))
          when Transaction_Code = NDFB
          and Condition_check = N then (-(PA / FR) +(PA / IDR))
		  when Transaction_Code = BNNF
          and Condition_check = N then (-(PA / FR) +(PA / IDR))
          else 0
        end 
		else 0 end as 228_USD,
		
		
		case when company=2780_JP_JPY then
        Case
          when Transaction_Code = BFWD
          and CP = JPYUSD then ((CV / CVR) -(CV / IDR))
		  When Transaction_Code = SFWD then (-(TA * FR) +(TA * IDR))
		  when Transaction_Code = SSPT then (-(TA * FR) +(TA * IDR))
		  when Transaction_Code = SFNF then (-(TA) *(FR - IDR))		  
          When CP = JPYCNY then (-(TA * FR) +(TA * RCPR))          
          else (-(TA) *(FR - RCPR))
        end 
		else 0 end as 2780_JPY,
		
		
		case when company=8000_CH_EUR then
        Case
          when Transaction_Code = SSPT
          and CP = GBPEUR then (-(PA * FR) +(PA * IDR))
          when Transaction_Code = BFWD then (-(PA / FR) +(PA / IDR))
		  when Transaction_Code in (SFWD, NDFS,SNNF) then (-(TA / FR) +(TA / RCPR))
		  when Transaction_Code =SSPT then (-(PA / FR) + (PA / RCPR))
          when Transaction_Code in (NDFB,BNNF, BSPT) then (-(TA / FR) +(TA / IDR))
          else 0
        End
else 0 end	as 8000_EUR
      from
        w_initial_col)
    ) as a
) merge into corp_us_hub.txn_limits_cashcloud_glbl as hub using(
  select
    *
  from
    w_add_new_col
) as lake on hub.Transaction_number = lake.Transaction_number
and hub.Report_date = lake.Report_date
WHEN MATCHED
And hub.md5_key != lake.md5_Key THEN
UPDATE
SET
  hub.228_USD = lake.228_USD,
  hub.2780_JPY = lake.2780_JPY,
  hub.8000_EUR = lake.8000_EUR,
  hub.8000_JPY = lake.8000_JPY,
  hub.md5_key = lake.md5_key,
  hub.aud_batch_load_wid = lake.aud_batch_load_wid,
  hub.aud_file_nm = lake.aud_file_nm,
  hub.aud_load_dts = lake.aud_load_dts,
  hub.aud_row_status_ind = lake.aud_row_status_ind,
  hub.aud_src_sys_id = lake.aud_src_sys_id,
  hub.aud_upd_dts = lake.aud_upd_dts,
  hub.load_cdp_time = lake.load_cdp_time
  WHEN NOT MATCHED THEN
INSERT
  (
    Company,
    Counterparty,
    Intermediary,
    On_behalf_of,
    Transaction_typ,
    Transaction_category,
    Transaction_number,
    Status,
    Transaction_currency,
    Transaction_Code,
    Transaction_amount,
    Rate,
    Direction_2,
    Countervalue_currency,
    Countervalue_amount,
    Rate_2,
    Transaction_date,
    Value_date,
    Year_start,
    End_date,
    Fixing_date,
    Portfolio,
    User_zone_1,
    User_zone_2,
    Report_date,
    228_USD,
    2780_JPY,
    8000_EUR,
    8000_JPY,
    md5_key,
    aud_batch_load_wid,
    aud_file_nm,
    aud_load_dts,
    aud_row_status_ind,
    aud_src_sys_id,
    aud_upd_dts,
    load_cdp_time
  )
Values
  (
    lake.Company,
    lake.Counterparty,
    lake.Intermediary,
    lake.On_behalf_of,
    lake.Transaction_type,
    lake.Transaction_category,
    lake.Transaction_number,
    lake.Status,
    lake.Transaction_currency,
    lake.Transaction_Code,
    lake.Transaction_amount,
    lake.Rate,
    lake.Direction_2,
    lake.Countervalue_currency,
    lake.Countervalue_amount,
    lake.Rate_2,
    lake.Transaction_date,
    lake.Value_date,
    lake.Year_start,
    lake.End_date,
    lake.Fixing_date,
    lake.Portfolio,
    lake.User_zone_1,
    lake.User_zone_2,
    lake.Report_date,
    lake.228_USD,
    lake.2780_JPY,
    lake.8000_EUR,
    lake.8000_JPY,
    lake.md5_key,
    lake.aud_batch_load_wid,
    lake.aud_file_nm,
    lake.aud_load_dts,
    lake.aud_row_status_ind,
    lake.aud_src_sys_id,
    lake.aud_upd_dts,
    lake.load_cdp_time
  )
The Query consists of Merge Into
Target table : corp_us_hub.txn_limits_cashcloud_glbl
Running Query : select count(*) from corp_us_hub.txn_limits_cashcloud_glbl where load_cdp_time=(select max(load_cdp_time) from corp_us_lake.cashcloud_limits)"	2024-05-27T11:41:34.000+00:00	2024-05-27T12:01:50.000+00:00	2024-05-27T12:08:02.000+00:00	No Error	82	82		seb4324	2024-05-27T12:06:00.000+00:00			null	null						batch	-
b42d2dca-3806-435c-b7f3-fe5bf9407dc0|230410	230410	7b69a068-0956-457c-9d12-61402edc4771|228528	23730495	None	None	Refer sql_for_run column for source table	None	None	com_us_lake.stg_google_ads_ad_final	Completed Normally	Databricks	"
Inside Data Integration
Master Query : select * from eds_us_lake_cdp.cdp_entity_mstr where app_id = APMS-92110|Panorama_MDI_US and entity_id = GOOGLE_ADS_AD_LL
Cannot Parse Job Name to get Source and Target Layers from the Job Name = 040-CDP-PANORAMA-GOOGLE_ADS_AD_LL-LAKE-TO-LAKE
Layers Parsed Values from Jobname : 040-CDP-PANORAMA-GOOGLE_ADS_AD_LL-LAKE-TO-LAKE - Source_layer = None, Target_Layer = None, allowed_values = [raw, lake, hub, mart]
Metadata : {""app_id"": ""APMS-92110|Panorama_MDI_US"", ""entity_id"": ""GOOGLE_ADS_AD_LL"", ""batch_id"": ""228528"", ""job_id"": ""230410"", ""sns_topic_arn"": ""arn:aws:sns:us-east-1:263789222982:panorama_topic"", ""entity_name"": ""TAKEDA_GOOGLE_ADS_AD_LAKE_TO_LAKE"", ""base_url"": null, ""queryStringParams"": null, ""pagination_flag"": null, ""last_fetch_time"": null, ""api_limit"": null, ""secret_name"": null, ""aws_region"": ""us-east-1"", ""iics_project_folder"": null, ""source_connector"": null, ""source_staging_loc"": null, ""s3_raw_file_location"": null, ""raw_file_type"": null, ""raw_file_name"": null, ""raw_file_header_flg"": null, ""raw_file_header_columns"": null, ""raw_file_delimiter"": null, ""raw_file_infer_schema_flg"": null, ""ingest_raw_excel_file_sheet_name"": null, ""raw_enclosure_character"": null, ""raw_escape_flag"": null, ""raw_escape_character"": null, ""raw_encoding_type"": null, ""raw_file_skip_rows"": null, ""load_type"": ""TRUNCATE"", ""source_timestamp_column"": null, ""source_primarykey_columns"": null, ""source_CDC_columns"": null, ""archive_raw_file_flg"": false, ""source_table_schema"": ""com_us_lake"", ""source_table_name"": ""stg_google_ads_ad"", ""source_pre_sql"": null, ""source_post_sql"": null, ""target_connector"": null, ""target_staging_loc"": null, ""s3_lake_file_location"": null, ""lake_file_name"": null, ""target_table_schema"": null, ""target_table_name"": null, ""dynamic_schema_flg"": null, ""target_pre_sql"": null, ""target_post_sql"": null, ""hse_kep_sql_bfr"": ""delete from com_us_lake.stg_google_ads_ad_final 
where date >= (select min(to_date(date,yyyy-MM-dd)) from com_us_lake.stg_google_ads_ad) and bu_name = RDBU"", ""sql_for_run"": ""insert into com_us_lake.stg_google_ads_ad_final 
( 
select 
ADGROUP_ID,
ADGROUP_NAME,
ADGROUP_RESOURCENAME,
ADGROUP_TYPE,
ADGROUPAD_AD_DISPLAYURL,
ADGROUPAD_AD_EXPANDED_DYNAMIC_SEARCH_AD_DESCRIPTION,
ADGROUPAD_AD_EXPANDED_DYNAMIC_SEARCH_AD_DESCRIPTION2,
ADGROUPAD_AD_EXPANDED_TEXT_AD_DESCRIPTION,
ADGROUPAD_AD_EXPANDED_TEXT_AD_DESCRIPTION2,
ADGROUPAD_AD_EXPANDED_TEXT_AD_HEADLINEPART1,
ADGROUPAD_AD_EXPANDED_TEXT_AD_HEADLINEPART2,
ADGROUPAD_AD_EXPANDED_TEXT_AD_HEADLINEPART3,
ADGROUPAD_AD_EXPANDED_TEXT_AD_PATH1,
ADGROUPAD_AD_EXPANDED_TEXT_AD_PATH2,
ADGROUPAD_AD_FINALURLS,
ADGROUPAD_AD_ID,
ADGROUPAD_AD_IMAGE_AD_IMAGEURL,
ADGROUPAD_AD_IMAGE_AD_MIMETYPE,
ADGROUPAD_AD_IMAGE_AD_NAME,
ADGROUPAD_AD_IMAGE_AD_PREVIEWIMAGEURL,
ADGROUPAD_AD_NAME,
ADGROUPAD_AD_RESOURCENAME,
ADGROUPAD_AD_RESPONSIVE_SEARCH_AD_DESCRIPTIONS,
ADGROUPAD_AD_RESPONSIVE_SEARCH_AD_HEADLINES,
ADGROUPAD_AD_TEXT_AD_DESCRIPTION1,
ADGROUPAD_AD_TEXT_AD_DESCRIPTION2,
ADGROUPAD_AD_TEXT_AD_HEADLINE,
ADGROUPAD_AD_TYPE,
ADGROUPAD_AD_STRENGTH,
ADGROUPAD_POLICY_SUMMARY_APPROVAL_STATUS,
ADGROUPAD_RESOURCENAME,
ADGROUPAD_STATUS,
CAMPAIGN_ADVERTISING_CHANNEL_TYPE,
TO_DATE(CAMPAIGN_END_DATE, yyyy-MM-dd),
CAMPAIGN_ID,
CAMPAIGN_NAME,
CAST(CAMPAIGN_OPTIMIZATION_SCORE as INT),
CAMPAIGN_PAYMENT_MODE,
CAMPAIGN_RESOURCENAME,
TO_DATE(CAMPAIGN_START_DATE, yyyy-MM-dd),
CAMPAIGN_STATUS,
CUSTOMER_DESCRIPTIVE_NAME,
CUSTOMER_ID,
CUSTOMER_RESOURCE_NAME,
CUSTOMER_TIMEZONE,
CAST(ABSOLUTE_TOP_IMPRESSION_PERCENTAGE as FLOAT),
CAST(ACTIVE_VIEW_CPM as INT),
CAST(ACTIVE_VIEW_CPE as INT),
CAST(ACTIVE_VIEW_IMPRESSIONS as INT),
CAST(ACTIVE_VIEW_MEASURABILITY as INT),
CAST(ACTIVE_VIEW_MEASURABLE_IMPRESSIONS as INT),
ACTIVE_VIEWABILITY,
CAST(ALL_CONVERSIONS as INT),
CAST(ALL_CONVERSIONS_BY_CONVERSION_DATE as INT),
CAST(ALL_CONVERSIONS_FROM_INTERACTIONS_RATE as INT),
CAST(ALL_CONVERSIONS_VALUE as INT),
CAST(AVERAGE_COST as FLOAT),
CAST(AVERAGE_CPC as FLOAT),
CAST(AVERAGE_CPE as FLOAT),
CAST(AVERAGE_CPM as FLOAT),
CAST(AVERAGE_CPV as FLOAT),
CAST(CLICKS as INT),
CAST(CONVERSIONS as INT),
CAST(COST_MICROS as INT),
CAST(COST_PER_ALL_CONVERSIONS as INT),
CAST(CTR as FLOAT),
CAST(ENGAGEMENT_RATE as FLOAT),
CAST(ENGAGEMENTS as INT),
CAST(IMPRESSIONS as INT),
CAST(INTERACTION_RATE as FLOAT),
CAST(INTERACTIONS as INT),
CAST(TOP_IMPRESSION_PERCENTAGE as FLOAT),
CAST(VIEW_THROUGH_CONVERSIONS as INT),
TO_DATE(DATE, yyyy-MM-dd),
DEVICE,
BU_NAME,
AUD_BATCH_LOAD_WID,
AUD_FILE_NM,
TO_TIMESTAMP(AUD_LOAD_DTS,dd/MM/yyyy HH:mm),
AUD_ROW_STATUS_IND,
AUD_SRC_SYS_ID,
CURRENT_TIMESTAMP()
from com_us_lake.stg_google_ads_ad ) 
  "", ""hse_kep_sql_aft"": ""
  insert into com_us_lake.stg_google_ads_ad_hist(
select	
ADGROUP_ID,
ADGROUP_NAME,
ADGROUP_RESOURCENAME,
ADGROUP_TYPE,
ADGROUPAD_AD_DISPLAYURL,
ADGROUPAD_AD_EXPANDED_DYNAMIC_SEARCH_AD_DESCRIPTION,
ADGROUPAD_AD_EXPANDED_DYNAMIC_SEARCH_AD_DESCRIPTION2,
ADGROUPAD_AD_EXPANDED_TEXT_AD_DESCRIPTION,
ADGROUPAD_AD_EXPANDED_TEXT_AD_DESCRIPTION2,
ADGROUPAD_AD_EXPANDED_TEXT_AD_HEADLINEPART1,
ADGROUPAD_AD_EXPANDED_TEXT_AD_HEADLINEPART2,
ADGROUPAD_AD_EXPANDED_TEXT_AD_HEADLINEPART3,
ADGROUPAD_AD_EXPANDED_TEXT_AD_PATH1,
ADGROUPAD_AD_EXPANDED_TEXT_AD_PATH2,
ADGROUPAD_AD_FINALURLS,
ADGROUPAD_AD_ID,
ADGROUPAD_AD_IMAGE_AD_IMAGEURL,
ADGROUPAD_AD_IMAGE_AD_MIMETYPE,
ADGROUPAD_AD_IMAGE_AD_NAME,
ADGROUPAD_AD_IMAGE_AD_PREVIEWIMAGEURL,
ADGROUPAD_AD_NAME,
ADGROUPAD_AD_RESOURCENAME,
ADGROUPAD_AD_RESPONSIVE_SEARCH_AD_DESCRIPTIONS,
ADGROUPAD_AD_RESPONSIVE_SEARCH_AD_HEADLINES,
ADGROUPAD_AD_TEXT_AD_DESCRIPTION1,
ADGROUPAD_AD_TEXT_AD_DESCRIPTION2,
ADGROUPAD_AD_TEXT_AD_HEADLINE,
ADGROUPAD_AD_TYPE,
ADGROUPAD_AD_STRENGTH,
ADGROUPAD_POLICY_SUMMARY_APPROVAL_STATUS,
ADGROUPAD_RESOURCENAME,
ADGROUPAD_STATUS,
CAMPAIGN_ADVERTISING_CHANNEL_TYPE,
CAMPAIGN_END_DATE,
CAMPAIGN_ID,
CAMPAIGN_NAME,
CAMPAIGN_OPTIMIZATION_SCORE,
CAMPAIGN_PAYMENT_MODE,
CAMPAIGN_RESOURCENAME,
CAMPAIGN_START_DATE,
CAMPAIGN_STATUS,
CUSTOMER_DESCRIPTIVE_NAME,
CUSTOMER_ID,
CUSTOMER_RESOURCE_NAME,
CUSTOMER_TIMEZONE,
ABSOLUTE_TOP_IMPRESSION_PERCENTAGE,
ACTIVE_VIEW_CPM,
ACTIVE_VIEW_CPE,
ACTIVE_VIEW_IMPRESSIONS,
ACTIVE_VIEW_MEASURABILITY,
ACTIVE_VIEW_MEASURABLE_IMPRESSIONS,
ACTIVE_VIEWABILITY,
ALL_CONVERSIONS,
ALL_CONVERSIONS_BY_CONVERSION_DATE,
ALL_CONVERSIONS_FROM_INTERACTIONS_RATE,
ALL_CONVERSIONS_VALUE,
AVERAGE_COST,
AVERAGE_CPC,
AVERAGE_CPE,
AVERAGE_CPM,
AVERAGE_CPV,
CLICKS,
CONVERSIONS,
COST_MICROS,
COST_PER_ALL_CONVERSIONS,
CTR,
ENGAGEMENT_RATE,
ENGAGEMENTS,
IMPRESSIONS,
INTERACTION_RATE,
INTERACTIONS,
TOP_IMPRESSION_PERCENTAGE,
VIEW_THROUGH_CONVERSIONS,
DATE,
DEVICE,
BU_NAME,
AUD_BATCH_LOAD_WID,
AUD_FILE_NM,
AUD_LOAD_DTS,
AUD_ROW_STATUS_IND,
AUD_SRC_SYS_ID,
CURRENT_TIMESTAMP()
from com_us_lake.stg_google_ads_ad
)
  "", ""sql_for_source_count"": """", ""sql_for_target_count"": """", ""version_check"": null, ""version_check_src_tbl_nm"": null, ""Integration_file_configs"": null, ""Integration_archive_flg"": false, ""schedule_flg"": true, ""created_user"": ""toa0954"", ""created_date_time"": ""2024-03-13 14:53:11.802000"", ""updated_user"": ""toa0954"", ""updated_date_time"": ""2024-03-13 14:53:11.802000""}
Archive Enabled : False
Running Query : refresh table com_us_lake.stg_google_ads_ad
Running Query : delete from com_us_lake.stg_google_ads_ad_final 
where date >= (select min(to_date(date,yyyy-MM-dd)) from com_us_lake.stg_google_ads_ad) and bu_name = RDBU
Running Query : insert into com_us_lake.stg_google_ads_ad_final 
( 
select 
ADGROUP_ID,
ADGROUP_NAME,
ADGROUP_RESOURCENAME,
ADGROUP_TYPE,
ADGROUPAD_AD_DISPLAYURL,
ADGROUPAD_AD_EXPANDED_DYNAMIC_SEARCH_AD_DESCRIPTION,
ADGROUPAD_AD_EXPANDED_DYNAMIC_SEARCH_AD_DESCRIPTION2,
ADGROUPAD_AD_EXPANDED_TEXT_AD_DESCRIPTION,
ADGROUPAD_AD_EXPANDED_TEXT_AD_DESCRIPTION2,
ADGROUPAD_AD_EXPANDED_TEXT_AD_HEADLINEPART1,
ADGROUPAD_AD_EXPANDED_TEXT_AD_HEADLINEPART2,
ADGROUPAD_AD_EXPANDED_TEXT_AD_HEADLINEPART3,
ADGROUPAD_AD_EXPANDED_TEXT_AD_PATH1,
ADGROUPAD_AD_EXPANDED_TEXT_AD_PATH2,
ADGROUPAD_AD_FINALURLS,
ADGROUPAD_AD_ID,
ADGROUPAD_AD_IMAGE_AD_IMAGEURL,
ADGROUPAD_AD_IMAGE_AD_MIMETYPE,
ADGROUPAD_AD_IMAGE_AD_NAME,
ADGROUPAD_AD_IMAGE_AD_PREVIEWIMAGEURL,
ADGROUPAD_AD_NAME,
ADGROUPAD_AD_RESOURCENAME,
ADGROUPAD_AD_RESPONSIVE_SEARCH_AD_DESCRIPTIONS,
ADGROUPAD_AD_RESPONSIVE_SEARCH_AD_HEADLINES,
ADGROUPAD_AD_TEXT_AD_DESCRIPTION1,
ADGROUPAD_AD_TEXT_AD_DESCRIPTION2,
ADGROUPAD_AD_TEXT_AD_HEADLINE,
ADGROUPAD_AD_TYPE,
ADGROUPAD_AD_STRENGTH,
ADGROUPAD_POLICY_SUMMARY_APPROVAL_STATUS,
ADGROUPAD_RESOURCENAME,
ADGROUPAD_STATUS,
CAMPAIGN_ADVERTISING_CHANNEL_TYPE,
TO_DATE(CAMPAIGN_END_DATE, yyyy-MM-dd),
CAMPAIGN_ID,
CAMPAIGN_NAME,
CAST(CAMPAIGN_OPTIMIZATION_SCORE as INT),
CAMPAIGN_PAYMENT_MODE,
CAMPAIGN_RESOURCENAME,
TO_DATE(CAMPAIGN_START_DATE, yyyy-MM-dd),
CAMPAIGN_STATUS,
CUSTOMER_DESCRIPTIVE_NAME,
CUSTOMER_ID,
CUSTOMER_RESOURCE_NAME,
CUSTOMER_TIMEZONE,
CAST(ABSOLUTE_TOP_IMPRESSION_PERCENTAGE as FLOAT),
CAST(ACTIVE_VIEW_CPM as INT),
CAST(ACTIVE_VIEW_CPE as INT),
CAST(ACTIVE_VIEW_IMPRESSIONS as INT),
CAST(ACTIVE_VIEW_MEASURABILITY as INT),
CAST(ACTIVE_VIEW_MEASURABLE_IMPRESSIONS as INT),
ACTIVE_VIEWABILITY,
CAST(ALL_CONVERSIONS as INT),
CAST(ALL_CONVERSIONS_BY_CONVERSION_DATE as INT),
CAST(ALL_CONVERSIONS_FROM_INTERACTIONS_RATE as INT),
CAST(ALL_CONVERSIONS_VALUE as INT),
CAST(AVERAGE_COST as FLOAT),
CAST(AVERAGE_CPC as FLOAT),
CAST(AVERAGE_CPE as FLOAT),
CAST(AVERAGE_CPM as FLOAT),
CAST(AVERAGE_CPV as FLOAT),
CAST(CLICKS as INT),
CAST(CONVERSIONS as INT),
CAST(COST_MICROS as INT),
CAST(COST_PER_ALL_CONVERSIONS as INT),
CAST(CTR as FLOAT),
CAST(ENGAGEMENT_RATE as FLOAT),
CAST(ENGAGEMENTS as INT),
CAST(IMPRESSIONS as INT),
CAST(INTERACTION_RATE as FLOAT),
CAST(INTERACTIONS as INT),
CAST(TOP_IMPRESSION_PERCENTAGE as FLOAT),
CAST(VIEW_THROUGH_CONVERSIONS as INT),
TO_DATE(DATE, yyyy-MM-dd),
DEVICE,
BU_NAME,
AUD_BATCH_LOAD_WID,
AUD_FILE_NM,
TO_TIMESTAMP(AUD_LOAD_DTS,dd/MM/yyyy HH:mm),
AUD_ROW_STATUS_IND,
AUD_SRC_SYS_ID,
CURRENT_TIMESTAMP()
from com_us_lake.stg_google_ads_ad ) 
  
The Query consists of Insert Into
Target table : com_us_lake.stg_google_ads_ad_final
Running Query : 
  insert into com_us_lake.stg_google_ads_ad_hist(
select	
ADGROUP_ID,
ADGROUP_NAME,
ADGROUP_RESOURCENAME,
ADGROUP_TYPE,
ADGROUPAD_AD_DISPLAYURL,
ADGROUPAD_AD_EXPANDED_DYNAMIC_SEARCH_AD_DESCRIPTION,
ADGROUPAD_AD_EXPANDED_DYNAMIC_SEARCH_AD_DESCRIPTION2,
ADGROUPAD_AD_EXPANDED_TEXT_AD_DESCRIPTION,
ADGROUPAD_AD_EXPANDED_TEXT_AD_DESCRIPTION2,
ADGROUPAD_AD_EXPANDED_TEXT_AD_HEADLINEPART1,
ADGROUPAD_AD_EXPANDED_TEXT_AD_HEADLINEPART2,
ADGROUPAD_AD_EXPANDED_TEXT_AD_HEADLINEPART3,
ADGROUPAD_AD_EXPANDED_TEXT_AD_PATH1,
ADGROUPAD_AD_EXPANDED_TEXT_AD_PATH2,
ADGROUPAD_AD_FINALURLS,
ADGROUPAD_AD_ID,
ADGROUPAD_AD_IMAGE_AD_IMAGEURL,
ADGROUPAD_AD_IMAGE_AD_MIMETYPE,
ADGROUPAD_AD_IMAGE_AD_NAME,
ADGROUPAD_AD_IMAGE_AD_PREVIEWIMAGEURL,
ADGROUPAD_AD_NAME,
ADGROUPAD_AD_RESOURCENAME,
ADGROUPAD_AD_RESPONSIVE_SEARCH_AD_DESCRIPTIONS,
ADGROUPAD_AD_RESPONSIVE_SEARCH_AD_HEADLINES,
ADGROUPAD_AD_TEXT_AD_DESCRIPTION1,
ADGROUPAD_AD_TEXT_AD_DESCRIPTION2,
ADGROUPAD_AD_TEXT_AD_HEADLINE,
ADGROUPAD_AD_TYPE,
ADGROUPAD_AD_STRENGTH,
ADGROUPAD_POLICY_SUMMARY_APPROVAL_STATUS,
ADGROUPAD_RESOURCENAME,
ADGROUPAD_STATUS,
CAMPAIGN_ADVERTISING_CHANNEL_TYPE,
CAMPAIGN_END_DATE,
CAMPAIGN_ID,
CAMPAIGN_NAME,
CAMPAIGN_OPTIMIZATION_SCORE,
CAMPAIGN_PAYMENT_MODE,
CAMPAIGN_RESOURCENAME,
CAMPAIGN_START_DATE,
CAMPAIGN_STATUS,
CUSTOMER_DESCRIPTIVE_NAME,
CUSTOMER_ID,
CUSTOMER_RESOURCE_NAME,
CUSTOMER_TIMEZONE,
ABSOLUTE_TOP_IMPRESSION_PERCENTAGE,
ACTIVE_VIEW_CPM,
ACTIVE_VIEW_CPE,
ACTIVE_VIEW_IMPRESSIONS,
ACTIVE_VIEW_MEASURABILITY,
ACTIVE_VIEW_MEASURABLE_IMPRESSIONS,
ACTIVE_VIEWABILITY,
ALL_CONVERSIONS,
ALL_CONVERSIONS_BY_CONVERSION_DATE,
ALL_CONVERSIONS_FROM_INTERACTIONS_RATE,
ALL_CONVERSIONS_VALUE,
AVERAGE_COST,
AVERAGE_CPC,
AVERAGE_CPE,
AVERAGE_CPM,
AVERAGE_CPV,
CLICKS,
CONVERSIONS,
COST_MICROS,
COST_PER_ALL_CONVERSIONS,
CTR,
ENGAGEMENT_RATE,
ENGAGEMENTS,
IMPRESSIONS,
INTERACTION_RATE,
INTERACTIONS,
TOP_IMPRESSION_PERCENTAGE,
VIEW_THROUGH_CONVERSIONS,
DATE,
DEVICE,
BU_NAME,
AUD_BATCH_LOAD_WID,
AUD_FILE_NM,
AUD_LOAD_DTS,
AUD_ROW_STATUS_IND,
AUD_SRC_SYS_ID,
CURRENT_TIMESTAMP()
from com_us_lake.stg_google_ads_ad
)
  "	2024-03-20T16:15:23.000+00:00	2024-03-20T16:16:36.000+00:00	2024-03-20T16:22:34.000+00:00	No Error	0	0		toa0954	2024-03-20T16:21:43.000+00:00			null	null						batch	-
8d96ac1f-3447-49d3-84b7-42d465d7fe5f|231278	231278	25505d8c-de85-447a-a56a-6f78fd23d9c6|231274	26327338	Raw	None	None	Lake			Completed Abnormally	Databricks	"
Inside_data_Ingestion
Master Query : select * from eds_us_lake_cdp.cdp_entity_mstr where app_id = COM_US_DA_OMNI_NPI_EXCEPTIONS and entity_id = OMNI_NPI_EXCEPTIONS_RAW_TO_LAKE
Reading the file(s)
Started Reading XLSX File In The Location = s3://tpc-aws-ted-dev-edpp-raw-com-us-east-1/com_us_raw/CDP/applications/usbu_gi/inbound_edb_omni_npi_exceptions_*.xlsx

No files to read in location : tpc-aws-ted-dev-edpp-raw-com-us-east-1/com_us_raw/CDP/applications/usbu_gi with wildcard : inbound_edb_omni_npi_exceptions_*.xlsx
No files to read in location : tpc-aws-ted-dev-edpp-raw-com-us-east-1/com_us_raw/CDP/applications/usbu_gi with wildcard : inbound_edb_omni_npi_exceptions_*.xlsx
No files to read in location : tpc-aws-ted-dev-edpp-raw-com-us-east-1/com_us_raw/CDP/applications/usbu_gi with wildcard : inbound_edb_omni_npi_exceptions_*.xlsx"	2024-06-28T04:08:28.000+00:00	2024-06-28T04:21:40.000+00:00	2024-06-28T04:26:00.000+00:00	No files to read in location : tpc-aws-ted-dev-edpp-raw-com-us-east-1/com_us_raw/CDP/applications/usbu_gi with wildcard : inbound_edb_omni_npi_exceptions_*.xlsx				hemal.jain@takeda.com	2024-06-28T04:25:26.000+00:00			null	null						batch	-




CREATE TABLE hive_metastore.com_us_mart_rdm01_outbound.nsbu_ascend_outbound_log (
  config_id INT,
  vndr STRING,
  sub_area STRING,
  frqncy STRING,
  out_file_nm STRING,
  record_count STRING,
  control_file_nm STRING,
  status STRING,
  msg STRING,
  job_id STRING COMMENT 'Static JobId generated by databricks during job creation',
  root_run_id STRING COMMENT 'Run Id for schema',
  current_run_id STRING COMMENT 'Rund Id for table',
  aud_load_dts TIMESTAMP,
  edb_batch_id STRING COMMENT 'concatenate root_run_id and current_date')
USING delta
LOCATION 's3://tpc-aws-ted-prd-edpp-mart-com-us-east-1/com_us_mart_rdm01_outbound.db/nsbu_ascend_outbound_log'
TBLPROPERTIES (
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2')
  
 Sample:
 
 config_id	vndr	sub_area	frqncy	out_file_nm	record_count	control_file_nm	status	msg	job_id	root_run_id	current_run_id	aud_load_dts	edb_batch_id
33	axtria	sales_orgnization	MONTHLY	axtria_takeda_sales_organization_20240630.txt.gz 		axtria_takeda_sales_organization_20240630.ctl.gz 	completed	ADX file transfer is complete	452759467282946	424584638248929	145424091629853	2024-06-30T09:08:30.000	42458463824892920240630
37	axtria	xponent	MONTHLY	axtria_takeda_xponent_monthly_20240630.txt.gz	632990440	axtria_takeda_xponent_monthly_20240630.ctl.gz	completed	Outbound file is created Succesfully	278397496550271	424584638248929	4964659812314	2024-06-30T11:23:18.000	42458463824892920240630


-----------------------------------

CREATE TABLE hive_metastore.com_us_mart_rdm01_outbound.config_nsbu_ascend_outbound (
  id INT,
  vndr STRING,
  sub_area STRING,
  frqncy STRING,
  sql STRING,
  out_file_dlmtr STRING,
  out_file_frmt STRING,
  out_file_nm STRING,
  out_is_zip STRING,
  out_has_ctrl STRING,
  out_file_path STRING,
  out_arch_path STRING,
  ft_mchnsm STRING,
  adx_path STRING,
  ftp_server STRING,
  ftp_user STRING,
  ftp_pswd STRING,
  email_sns STRING,
  active_flag STRING,
  databricks_job_id STRING,
  last_triggered_dt DATE,
  insrt_dt DATE,
  upd_dt DATE,
  vndr_email_sns STRING,
  gen_done_file STRING)
USING delta
LOCATION 's3://tpc-aws-ted-prd-edpp-mart-com-us-east-1/com_us_mart_rdm01_outbound.db/config_nsbu_ascend_outbound'
TBLPROPERTIES (
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2')


Sample:
id	vndr	sub_area	frqncy	sql	out_file_dlmtr	out_file_frmt	out_file_nm	out_is_zip	out_has_ctrl	out_file_path	out_arch_path	ft_mchnsm	adx_path	ftp_server	ftp_user	ftp_pswd	email_sns	active_flag	databricks_job_id	last_triggered_dt	insrt_dt	upd_dt	vndr_email_sns	gen_done_file
130	knipper	zip_terr	Monthly	select reporting_sales_org_id,sales_force_code,terr_code,zip_terr_align_period_key,zip_terr_eff_date,zip_terr_end_date,curr_ind,zip_code,latitude,longitude from com_us_mart_rdm01_outbound.vw_zip_terr where curr_ind ='A' and upper(sales_force_code) in ('NSF','GATTEX')	|	TXT	knipper_takeda_zip_terr	N	Y	s3://tpc-aws-ted-prd-edpp-lake-com-us-east-1/com_us_lake/epsilon_rdm01_outbound/outbound/knipper/	s3://tpc-aws-ted-prd-edpp-lake-com-us-east-1/com_us_lake/epsilon_rdm01_outbound/archive/knipper/	SFTP	/Outbound/Knipper/	usprd.eft.onetakeda.com	arn:aws:secretsmanager:us-east-1:432372222409:secret:svc_knipper_baikal_prod-zO1kRw		arn:aws:sns:us-east-1:432372222409:EDB-Baikal-Outbound-notification	Y		-	2024-04-03	-	arn:aws:sns:us-east-1:432372222409:EDB-Baikal-Outbound-notification	N
65	klick	product_market_definitions	Weekly	select product_id,product_code,product_desc,corp_market_desc,corp_market_code,corp_market_product,corp_product_code,corp_product_desc,corp_product_type,hierarchy_code,hierarchy_desc,market_code,market_desc,submarket_code,submarket_desc,brand_code,brand_desc,subbrand_code,subbrand_desc,class_code,class_desc,subclass_code,subclass_desc,apld_code,apld_desc,corp_formulary_product_id,corp_formulary_product_code,sales_rpt_ind,commercial_rpt_ind  from com_us_mart_rdm01_outbound.vw_product_market_definition	|	TXT	klick_takeda_product_market_definition	Y	Y	s3://tpc-aws-ted-prd-edpp-lake-com-us-east-1/com_us_lake/epsilon_rdm01_outbound/outbound/klick/	s3://tpc-aws-ted-prd-edpp-lake-com-us-east-1/com_us_lake/epsilon_rdm01_outbound/archive/klick/	ADX	s3://tec-prd-usvga-92113-nsbu-00/outbound/klick/				arn:aws:sns:us-east-1:432372222409:EDB-Baikal-Outbound-notification	Y		-	2024-01-23	-	arn:aws:sns:us-east-1:432372222409:EDB-Baikal-Outbound-notification	Y
66	klick	takeda_payer_formulary	Monthly	select  cal_month_date,cal_month_date_id,payer_id,payer_desc,product_id,product_code,product_desc,universal_status,universal_status_rollup,step_status,step_therapy_ind,prior_auth_ind,quantity_limit_ind,product_access_score,coverage_type,indication_name,indication_key,tier_value,tier_desc,tier_short_desc,src_vendor_code from COM_US_MART_RDM01_OUTBOUND.vw_payer_formulary	|	TXT	klick_takeda_payer_formulary	Y	Y	s3://tpc-aws-ted-prd-edpp-lake-com-us-east-1/com_us_lake/epsilon_rdm01_outbound/outbound/klick/	s3://tpc-aws-ted-prd-edpp-lake-com-us-east-1/com_us_lake/epsilon_rdm01_outbound/archive/klick/	ADX	s3://tec-prd-usvga-92113-nsbu-00/outbound/klick/				arn:aws:sns:us-east-1:432372222409:EDB-Baikal-Outbound-notification	Y		-	2024-01-23	-	arn:aws:sns:us-east-1:432372222409:EDB-Baikal-Outbound-notification	Y



-------------------GIBU:


CREATE TABLE hive_metastore.com_us_audit_gibu.batch_run (
  batch_uuid STRING NOT NULL,
  batch_job_id BIGINT,
  batch_job_name STRING,
  batch_job_run_id BIGINT,
  batch_job_start_date DATE,
  batch_job_start_time STRING,
  batch_job_end_time STRING,
  batch_job_status STRING,
  batch_job_rerun BIGINT,
  batch_job_output STRING,
  batch_job_error_message STRING,
  rcd_created_timestamp TIMESTAMP,
  rcd_updated_timestamp TIMESTAMP)
USING delta
TBLPROPERTIES (
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2')
  
  
  batch_uuid	batch_job_id	batch_job_name	batch_job_run_id	batch_job_start_date	batch_job_start_time	batch_job_end_time	batch_job_status	batch_job_rerun	batch_job_output	batch_job_error_message	rcd_created_timestamp	rcd_updated_timestamp
	84622	CDP-AXTRIA-SALES-WEEKLY-BATCH-PRD	22512131	2023-04-13	02:46:51	02:46:51	Active	0			2023-04-13T06:48:06.167+00:00	-
	84622	CDP-AXTRIA-SALES-WEEKLY-BATCH-PRD	22512131	2023-04-13	02:46:51	02:47:51	Waiting On Children	0			2023-04-13T06:48:07.704+00:00	-
	84622	CDP-AXTRIA-SALES-WEEKLY-BATCH-PRD	22512131	2023-04-13	02:46:51	02:46:51	Waiting On Children	0			2023-04-13T06:48:04.137+00:00	-
	
	
	
CREATE TABLE hive_metastore.com_us_audit_gibu.batch_run_event (
  batch_uuid STRING NOT NULL,
  batch_job_id BIGINT,
  batch_job_run_id BIGINT,
  job_id BIGINT,
  job_name STRING,
  job_run_id BIGINT,
  job_start_date DATE,
  job_start_time STRING,
  job_end_time STRING,
  job_status STRING,
  job_rerun BIGINT,
  job_output STRING,
  job_error_message STRING,
  rcd_created_timestamp TIMESTAMP)
USING delta
TBLPROPERTIES (
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2')



batch_uuid	batch_job_id	batch_job_run_id	job_id	job_name	job_run_id	job_start_date	job_start_time	job_end_time	job_status	job_rerun	job_output	job_error_message	rcd_created_timestamp
ab64bf85-a9d5-4699-a667-ba1fb5969127	84622	22512131	84623	010-CDP-AXTRIA-VLC_SPPRD_EDI_ORCH-BATCH-CONTROL-START	22512134	2023-04-13	02:46:56	02:47:58	Completed Abnormally	0			2023-04-13T06:48:05.469+00:00
ab64bf85-a9d5-4699-a667-ba1fb5969127	84622	22513172	84623	010-CDP-AXTRIA-VLC_SPPRD_EDI_ORCH-BATCH-CONTROL-START	22513176	2023-04-13	04:18:28	04:23:24	Completed Abnormally	0			2023-04-13T08:23:32.977+00:00
ab64bf85-a9d5-4699-a667-ba1fb5969127	84622	22514222	84623	010-CDP-AXTRIA-VLC_SPPRD_EDI_ORCH-BATCH-CONTROL-START	22514224	2023-04-13	05:26:10	05:32:41	Completed Abnormally	0			2023-04-13T09:32:50.451+00:00


CREATE TABLE hive_metastore.com_us_audit_gibu.job_run_control_file (
  job_uuid STRING,
  job_config_batch_id STRING,
  job_run_id STRING,
  batch_run_id STRING,
  EXPORT_FILE_NAME STRING,
  EXPORT_FILE_RECORD_COUNT STRING,
  EXPORT_TYPE STRING,
  audit_datetime TIMESTAMP)
USING delta
TBLPROPERTIES (
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2')
  
  job_uuid	job_config_batch_id	job_run_id	batch_run_id	EXPORT_FILE_NAME	EXPORT_FILE_RECORD_COUNT	EXPORT_TYPE	audit_datetime
11231501432c-5f3c-4ad3-a54e-462913de8f3b	1123de9065e5-89d6-47ba-9bb6-ca9babcb6654	6a7b213c-e380-11ed-8602-0e7f29aa6235	1123de9065e5-89d6-47ba-9bb6-ca9babcb6654	SQL_T_SALES_ORG_RPT_IC_SALES_20230425185102.txt.gz	214	Data Table	2023-04-25T18:51:06.052+00:00
11231501432c-5f3c-4ad3-a54e-462913de8f3b	1123de9065e5-89d6-47ba-9bb6-ca9babcb6654	6cfaf962-e3a0-11ed-ae7c-0e7f29aa6235	1123de9065e5-89d6-47ba-9bb6-ca9babcb6654	SQL_T_SALES_ORG_RPT_IC_SALES_20230425193913.txt.gz	214	Data Table	2023-04-25T19:39:57.533+00:00
11231501432c-5f3c-4ad3-a54e-462913de8f3b	1123de9065e5-89d6-47ba-9bb6-ca9babcb6654	0de216f6-e3ee-11ed-aaba-0e7f29aa6235	1123de9065e5-89d6-47ba-9bb6-ca9babcb6654	SQL_T_SALES_ORG_RPT_IC_SALES_20230426045500.txt.gz	214	Data Table	2023-04-26T04:55:42.088+00:00




CREATE TABLE hive_metastore.com_us_audit_gibu.job_run_stat (
  job_id STRING,
  job_run_id STRING,
  total_rows STRING,
  error_records STRING,
  severity STRING,
  total_rules STRING,
  rules_passed STRING,
  rules_failed STRING,
  common_failed STRING)
USING delta
TBLPROPERTIES (
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2')
  
  job_id	job_run_id	total_rows	error_records	severity	total_rules	rules_passed	rules_failed	common_failed
346	4cae13ee-e998-11ed-b5b6-0e7f29aa6235	1081	0	c	0	0	0	0
346	4cae13ee-e998-11ed-b5b6-0e7f29aa6235	1081	0	i	2	2	0	0
275	63d8d0fe-e998-11ed-b501-0e7f29aa6235	149027	0	c	1	1	0	0


CREATE TABLE hive_metastore.com_us_audit_gibu.edb_table_count_temp (
  SUBJECT_AREA STRING,
  TABLE_NAME STRING,
  PREV_CNT2 STRING,
  PREV_CNT1 STRING,
  CURR_CNT STRING,
  PERCENT_CHANGE STRING,
  RECORD_COUNT_DROP STRING)
USING delta
TBLPROPERTIES (
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2')

SUBJECT_AREA	TABLE_NAME	PREV_CNT2	PREV_CNT1	CURR_CNT	PERCENT_CHANGE	RECORD_COUNT_DROP
Customer	com_us_hub.ref_cust_acct_hier_all	435114	435097	435098	2.2983380717403243E-4	False
Customer	com_us_hub.ref_cust_acct_hier_intrm	248537	248527	248527	0.0	False
Customer	com_us_hub.ref_customer_src_dim	28579111	28582864	28616226	0.11672028387358242	False
Customer	com_us_hub.ref_cust_account	6015561	6019444	6019636	0.0031896633642575626	False



CREATE TABLE hive_metastore.com_us_lake.job_param (
  job_id INT NOT NULL,
  prm_nm VARCHAR(200) NOT NULL,
  prm_grp VARCHAR(200) NOT NULL,
  prm_val VARCHAR(500),
  is_dynamic VARCHAR(10),
  rcd_created_on TIMESTAMP,
  rcd_created_by VARCHAR(100),
  rcd_modified_on TIMESTAMP,
  rcd_modified_by VARCHAR(100),
  rcd_config_ins_batch_id VARCHAR(500) NOT NULL,
  rcd_config_upd_batch_id VARCHAR(500) NOT NULL,
  rcd_is_active BOOLEAN,
  job_uuid VARCHAR(200))
USING delta
TBLPROPERTIES (
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2')


job_id	prm_nm	prm_grp	prm_val	is_dynamic	rcd_created_on	rcd_created_by	rcd_modified_on	rcd_modified_by	rcd_config_ins_batch_id	rcd_config_upd_batch_id	rcd_is_active	job_uuid
1237	src_file_path	file_ungzip	com_us_raw/external/GIBU_NON_TRIGGER/HCP_Specialty_Exclusions_*.txt.gz	false	2023-09-06T15:57:12.458	svc-1305366-01	2023-09-06T15:57:12.458	svc-1305366-01	08d94aa0-4cce-11ee-a7d7-0e7f29aa6235	08d94aa0-4cce-11ee-a7d7-0e7f29aa6235	true	fddf6f4f-9c91-4e52-b3be-f62be7fdc1fa
1238	tgt_dobj	default	vw_pfv_primary_affiliation	false	2023-09-18T08:37:28.995	svc-1305366-01	2023-09-25T08:43:45.858	svc-1305366-01	96aba3c6-55fe-11ee-b9e4-0e7f29aa6235	a24bd508-5b7f-11ee-ba14-0e7f29aa6235	false	e4dca9a9-ea0f-410a-a938-dcb42f3ea15e
1238	file_extension	default	txt	false	2023-09-18T08:37:28.995	svc-1305366-01	2023-09-25T08:43:45.858	svc-1305366-01	96aba3c6-55fe-11ee-b9e4-0e7f29aa6235	a24bd508-5b7f-11ee-ba14-0e7f29aa6235	false	e4dca9a9-ea0f-410a-a938-dcb42f3ea15e



CREATE TABLE hive_metastore.com_us_hub.ref_ps_ctrl_file (
  file_name STRING,
  file_count STRING,
  table_count STRING,
  count_check_flag STRING,
  comment STRING,
  aud_load_dt DATE)
USING delta
TBLPROPERTIES (
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2')
  
  
  file_name	file_count	table_count	count_check_flag	comment	aud_load_dt
lh_entyvio_crxphrmclm	163444	163444	True	Count matches	2024-06-04
lh_entyvio_crxenrl	87511	87511	True	Count matches	2024-06-04
lh_entyvio_crxmedclm	668706	668706	True	Count matches	2024-06-04



CREATE TABLE hive_metastore.com_us_mart_baikal.config_baikal_rpln (
  schma STRING,
  dbse STRING,
  dlta_ltn STRING,
  bkt STRING,
  landing_path STRING,
  schma_alias STRING,
  full_path STRING,
  archive_path STRING,
  email_sns STRING,
  active_flag STRING,
  m_filter STRING,
  p_filter STRING,
  d_filter STRING,
  databricks_job_id STRING,
  last_run_dt DATE)
USING delta
LOCATION 's3://tpc-aws-ted-prd-edpp-mart-com-us-east-1/com_us_mart_baikal.db/config_baikal_rpln'
TBLPROPERTIES (
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2')



schma	dbse	dlta_ltn	bkt	landing_path	schma_alias	full_path	archive_path	email_sns	active_flag	m_filter	p_filter	d_filter	databricks_job_id	last_run_dt
rdm01_outbound	com_us_mart_rdm01_outbound	s3://tpc-aws-ted-prd-edpp-mart-com-us-east-1/com_us_mart_rdm01_outbound.db/	tpc-aws-ted-prd-edpp-lake-com-us-east-1	com_us_lake/epsilon_rdm01_outbound/	rdm01_outbound	s3://tpc-aws-ted-prd-edpp-lake-com-us-east-1/com_us_lake/epsilon_rdm01_outbound/	s3://tpc-aws-ted-prd-edpp-lake-com-us-east-1/com_us_lake/epsilon_rdm01_outbound/archive/	arn:aws:sns:us-east-1:432372222409:EDB-Baikal-Data-Refresh	Y	manifest	parquet	done000	null	-
rdm01_reports	com_us_mart_rdm01_reports	s3://tpc-aws-ted-prd-edpp-mart-com-us-east-1/com_us_mart_rdm01_reports.db/	tpc-aws-ted-prd-edpp-lake-com-us-east-1	com_us_lake/epsilon_rdm01_reports/	rdm01_reports	s3://tpc-aws-ted-prd-edpp-lake-com-us-east-1/com_us_lake/epsilon_rdm01_reports/	s3://tpc-aws-ted-prd-edpp-lake-com-us-east-1/com_us_lake/epsilon_rdm01_reports/archive/	arn:aws:sns:us-east-1:432372222409:EDB-Baikal-Data-Refresh	N	manifest	parquet	done000	null	-

CREATE TABLE hive_metastore.com_us_mart_baikal.rpln_error_tbl (
  schma_name STRING,
  edb_tbl_name STRING,
  parquet_file_name STRING,
  error_message STRING,
  edb_batch_id STRING)
USING delta
LOCATION 's3://tpc-aws-ted-prd-edpp-mart-com-us-east-1/com_us_mart_baikal.db/rpln_error_tbl'
TBLPROPERTIES (
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2')

schma_name	edb_tbl_name	parquet_file_name	error_message	edb_batch_id
rdm01_gi	commercial_dashboard_hcp	rdm01_gi_commercial_dashboard_hcp_20230918_0014_part_00.parquet	"An error occurred while calling o883.save.

"	23649627758400220230918
rdm01_gi	cicfpp	rdm01_gi_cicfpp_20230918_0010_part_00.parquet	"An error occurred while calling o701.parquet.

"	23649627758400220230918
rdm01_outbound	vw_savings_card_type_map	rdm01_outbound_vw_savings_card_type_map_20240121_0006_part_00.parquet	Found duplicate column(s) in the data schema: `sls_mapped_chnl`	38296527949202420240122




CREATE TABLE hive_metastore.com_us_mart_baikal.meta_baikal_load_status (
  schma STRING,
  table_name STRING,
  status STRING,
  start_time STRING,
  end_time STRING,
  duration_in_seconds STRING,
  job_id STRING COMMENT 'Static JobId generated by databricks during job creation',
  root_run_id STRING COMMENT 'Run Id for schema',
  current_run_id STRING COMMENT 'Rund Id for table',
  error_msg STRING,
  edb_rec_cnt STRING,
  parquet_rec_cnt STRING,
  manifest_rec_cnt STRING,
  file_size_in_bytes STRING,
  aud_load_dts TIMESTAMP,
  edb_batch_id STRING COMMENT 'concatenate root_run_id and current_date')
USING delta
LOCATION 's3://tpc-aws-ted-prd-edpp-mart-com-us-east-1/com_us_mart_baikal.db/meta_baikal_load_status'
TBLPROPERTIES (
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2')
  
  
  schma	table_name	status	start_time	end_time	duration_in_seconds	job_id	root_run_id	current_run_id	error_msg	edb_rec_cnt	parquet_rec_cnt	manifest_rec_cnt	file_size_in_bytes	aud_load_dts	edb_batch_id
rdm01_sa	com_us_mart_rdm01_sa.wellbutrin_analysis_naive_cohort_post_covid_1	success	2024-06-30 12:49:39	2024-06-30 12:50:32	53	55793331527211	802792455651609	615799675591903		2785296	2785296	2785296	28514377	2024-06-30T16:50:32.508	80279245565160920240630
rdm01_sa	com_us_mart_rdm01_sa.vyvn_segment_temp2	success	2024-06-30 12:49:34	2024-06-30 12:50:21	47	55793331527211	802792455651609	997443797053012		189	189	189	14371	2024-06-30T16:50:21.968	80279245565160920240630
rdm01_sa	com_us_mart_rdm01_sa.wellbutrin_analysis_naive_cohort_covid	success	2024-06-30 12:49:36	2024-06-30 12:50:19	43	55793331527211	802792455651609	750924884687774		2525982	2525982	2525982	26232455	2024-06-30T16:50:19.668	80279245565160920240630



---------------MDM----------

CREATE TABLE hive_metastore.mdm_us_prsd.delta_process_run_info (
  process_name STRING,
  sub_process_name STRING,
  timeperiod STRING,
  current_run_date TIMESTAMP,
  last_run_date TIMESTAMP,
  status STRING)
USING delta
PARTITIONED BY (process_name, sub_process_name, timeperiod)
LOCATION 's3://tpc-aws-ted-prd-edpp-bdm-mount-us-east-1/IICS/omni_mdm/TgtFiles/Reltio/databricks_tmp/delta/delta_process/delta_process_run_info'
TBLPROPERTIES (
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2')
  
  process_name	sub_process_name	timeperiod	current_run_date	last_run_date	status
canonical	hcpmerge	Daily	2024-07-03T19:22:02.000+00:00	2024-07-03T04:22:13.000+00:00	closed
omni	hcpmerge	Weekly	2024-06-28T04:18:51.000+00:00	2024-06-21T04:35:58.000+00:00	closed
canonical	hcpunmerge	Daily	2024-06-28T20:41:27.000+00:00	2024-06-28T20:41:27.000+00:00	closed
omni	Affiliation	Daily	2024-07-04T04:07:13.286+00:00	2024-07-03T04:29:49.206+00:00	closed
omni	Affiliation	Weekly	2024-06-28T04:33:15.215+00:00	2024-06-21T04:53:55.985+00:00	closed