-- Databricks notebook source
-- MAGIC %md
-- MAGIC ### Checking data availability

-- COMMAND ----------

select workspace_id,min(event_date) as minTime,max(event_date) from system.access.audit where
 event_date between "2023-03-01" and "2024-01-01" and 
 workspace_id in ('2186391591496286','2033331146719248','845586985866129') 
 AND action_name IN ('requestPermissions','commandSubmit','runCommand') group by 1

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Getting Table ACL requestPermissions audit events
-- MAGIC
-- MAGIC -- Filtering successful access events and parse catalog + table information.
-- MAGIC -- Change date filter as needed

-- COMMAND ----------

select *
from system.access.audit where 
workspace_id in (2186391591496286,2033331146719248,845586985866129)
and event_date between '2024-03-01' and '2024-03-01'
and action_name = 'requestPermissions'
and response.status_code = 200

-- COMMAND ----------

select workspace_id,event_time,action_name,email,regexp_extract(object,"DATABASE/`([^`]*)`") as database,regexp_extract(object,"TABLE/`([^`]*)`") as table,object from (
select workspace_id,event_time,action_name,email,event[0].name as object,event[1].name as permision from (select workspace_id,event_time,action_name,user_identity.email,
explode(from_json(response.result, "ARRAY<ARRAY<STRUCT<name: STRING>>>")) as event
from system.access.audit where 
workspace_id in (2186391591496286,2033331146719248,845586985866129)
and event_date >'2024-01-01' 
--between '2024-03-01' and '2024-03-01'
and action_name = 'requestPermissions'
and response.status_code = 200 ))

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Filtering unauthorized events.
-- MAGIC
-- MAGIC Requires a view/table with email ids of unauthorized users and filter successful events for these users.  
-- MAGIC Add database or table filter of interest.
-- MAGIC

-- COMMAND ----------

select *
from system.access.audit where 
workspace_id in (2186391591496286,2033331146719248,845586985866129)
and event_date between '2024-03-01' and '2024-03-01'
and action_name = 'requestPermissions'
-- and database in ("")

-- COMMAND ----------

select
  workspace_id,
  email,
  event_time,
    regexp_extract(object, "DATABASE/`([^`]*)`") as database,
  regexp_extract(object, "TABLE/`([^`]*)`") as table,
  object,
  permision,
  --action_name,
   -- permision,
  status_code
from
  (
    select
      workspace_id,
      event_time,
      action_name,
      email,
      event [0].name as object,
      event [1].name as permision,
      status_code
    from
      (
        select
          workspace_id,
          event_time,
          action_name,
          user_identity.email,
          explode(
            from_json(
              response.result,
              "ARRAY<ARRAY<STRUCT<name: STRING>>>"
            )
          ) as event,
          response.status_code
        from
          system.access.audit
        where
          workspace_id in (
           -- 2186391591496286,
            -- 2033331146719248,
            845586985866129
          )
          and event_date > '2024-01-01' --event_date between '2024-03-01' and '2024-03-01'
          and action_name = 'requestPermissions'
      )
  ) --where email in (select email from unauthorized_emails)
  -- and database in ("")

-- COMMAND ----------

-- SD --
select
  workspace_id,
  email,
  event_time,
  regexp_extract(object, "DATABASE/`([^`]*)`") as database,
  regexp_extract(object, "TABLE/`([^`]*)`") as table,
  --object,
  permision,
  --action_name,
   -- permision,
  status_code
from
  (
    select
      workspace_id,
      event_time,
      action_name,
      email,
      event [0].name as object,
      event [1].name as permision,
      status_code
    from
      (
        select
          workspace_id,
          event_time,
          action_name,
          user_identity.email,
          explode(
            from_json(
              response.result,
              "ARRAY<ARRAY<STRUCT<name: STRING>>>"
            )
          ) as event,
          response.status_code
        from
          system.access.audit
        where
          workspace_id in (
           2186391591496286,
           2033331146719248,
            845586985866129
          )
          and event_date > '2024-03-15' --event_date between '2024-03-01' and '2024-03-01'
          and action_name = 'requestPermissions'
      )
  ) --where email in (select email from unauthorized_emails)
  -- and database in ("")

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Checking command text for notebook + DBSQL run commands
-- MAGIC
-- MAGIC

-- COMMAND ----------

select workspace_id,event_time,action_name,user_identity.email,request_params.notebookId,request_params.clusterId,request_params.warehouseId,request_params.status,request_params.commandText
from system.access.audit where 
workspace_id in (2186391591496286,2033331146719248,845586985866129)
and action_name in  ('commandSubmit','runCommand')
and event_date between '2024-03-01' and '2024-03-01'

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Checking command text for notebook + DBSQL run commands for unauthorized users for command text of interest.
-- MAGIC
-- MAGIC Sample query search for command text containing catalog names of interest.

-- COMMAND ----------

select * from (
select workspace_id,event_time,action_name,user_identity.email,request_params.notebookId,request_params.clusterId,request_params.warehouseId,request_params.status,request_params.commandText
from system.access.audit where 
workspace_id in (2186391591496286,2033331146719248,845586985866129)
and action_name in  ('commandSubmit','runCommand')
and event_date between '2024-03-01' and '2024-03-25'
) where   ( 
  lower(commandText) like '%corp_de_raw%' or lower(commandText) like '%corp_de_lake%'  or lower(commandText) like '%corp_de_hub%' 
)
-- and email in (select email from unauthorized_emails)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### List of clusters and it's iam role mappings
-- MAGIC

-- COMMAND ----------

select event_time,workspace_id,user_identity.email,request_params.cluster_name,
regexp_extract(request_params.aws_attributes,'instance_profile_arn":"([^"]*)') as iam_role,regexp_extract(response.result,'cluster_id":"([^"]*)"') as cluster_id
from system.access.audit where 
workspace_id in (2186391591496286,2033331146719248,845586985866129)
and action_name in  ('create','edit') 
and service_name = 'clusters'
and event_date between '2024-03-01' and '2024-03-01'
