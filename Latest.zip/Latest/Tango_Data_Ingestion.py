# Databricks notebook source
# MAGIC %sh
# MAGIC pip install pymssql

# COMMAND ----------

#Maintains The Each Step Of The Main Pipeline Execution Used For Logging (Optional)
import json
message=''
def step_control_log(log):
  global message
  message+= "\n" +log.replace("'","")

#Default Dictionary To Be Returned To The CDP Wrapper Notebook
return_dict = {
              "source_layer": "Database",
              "target_layer": "Raw",
              "source_object_location":"",
              "source_object_name":"",
              "target_object_location":"",
              "target_object_name":"",
              "source_count":0,
              "target_count":0,
              "error_msg":"No Error",
              "message":""
            }

# COMMAND ----------

import pymssql
from pyspark.sql.functions import *
from datetime import *
import boto3,botocore
from botocore.exceptions import ClientError

# COMMAND ----------

#Declaration of variables
env = dbutils.widgets.get("env")
current_timestamp = datetime.now()
config_path = "s3://tpc-aws-ted-{}-edpp-raw-corp-us-east-1/TANGO/Config_Files/Config_Tango.json".format(env)
table_name = dbutils.widgets.get("table_name") 
# raw_bucket = "tpc-aws-ted-{}-edpp-raw-corp-us-east-1".format(env)
# raw_path = "{0}/{1}/{1}_{2}.csv"

if str(table_name) in ["DM_DEPARTMENT_METRICS","F_LEASE_FINANCIALS","DM_SPACE_AREA"]:
    tbl_name = str(table_name) +'_MSTR'  
    raw_bucket = "tpc-aws-ted-{}-edpp-raw-corp-us-east-1".format(env)
    raw_path = "{0}/{1}/{1}_{2}.csv"
else:
    tbl_name =  table_name
    raw_bucket = "tpc-aws-ted-{}-edpp-raw-corp-us-east-1".format(env)
    raw_path = "{0}/{1}/{1}_{2}.csv"


# COMMAND ----------

#get credentials from secret manager
def get_credentials(p_secret_name,p_region_name):
  secret_name = p_secret_name
  region_name = p_region_name

  # Create a Secrets Manager client
  session = boto3.session.Session()
  client = session.client(
      service_name='secretsmanager',
      region_name=region_name
  )

  try:
      get_secret_value_response = client.get_secret_value(
          SecretId=secret_name
      )

  except ClientError as e:
      if e.response['Error']['Code'] == 'DecryptionFailureException':
          # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
          # Deal with the exception here, and/or rethrow at your discretion.
          raise e
      elif e.response['Error']['Code'] == 'InternalServiceErrorException':
          # An error occurred on the server side.
          # Deal with the exception here, and/or rethrow at your discretion.
          raise e
      elif e.response['Error']['Code'] == 'InvalidParameterException':
          # You provided an invalid value for a parameter.
          # Deal with the exception here, and/or rethrow at your discretion.
          raise e
      elif e.response['Error']['Code'] == 'InvalidRequestException':
          # You provided a parameter value that is not valid for the current state of the resource.
          # Deal with the exception here, and/or rethrow at your discretion.
          raise e
      elif e.response['Error']['Code'] == 'ResourceNotFoundException':
          # We can't find the resource that you asked for.
          # Deal with the exception here, and/or rethrow at your discretion.
          raise e
      else:
          raise e
  else:
      # Decrypts secret using the associated KMS CMK.
      # Depending on whether the secret is a string or binary, one of these fields will be populated.
      if 'SecretString' in get_secret_value_response:
          secret = get_secret_value_response['SecretString']
      else:
          secret = base64.b64decode(get_secret_value_response['SecretBinary'])
  credentials = json.loads(secret)
  
  # application code .
  return credentials

# COMMAND ----------

db_cred = get_credentials('arn:aws:secretsmanager:us-east-1:432372222409:secret:CORP_TANGO_SQL_SERVER_CONFIG-b25vD5','us-east-1')

# COMMAND ----------

def read_config():
    try:
        step_control_log("Reading Config file from the path {}".format(config_path))
        config_df = spark.read.format("json").option("multiline","true").load(config_path).where(col("table_name")==table_name)
        step_control_log("Config file Read Completed".format(config_path))
        return [row.asDict() for row in config_df.collect()][0]
    except Exception as e:
        raise e

# COMMAND ----------

def setup_connection(secret_name):
    try:
        step_control_log("Reading Connection Configs from Secret {} ".format(secret_name))
        connection_dict = "" #Need to create a Secret in the AWS Secret Manager and retrieve it as dictionary
        step_control_log("Secret Read Completed")
        step_control_log("Connecting to Tango SQL Server")
        conn = pymssql.connect(
            server= db_cred['server'],
            user=  db_cred['username'],
            password= db_cred['password'],
            database= db_cred['database'],
            as_dict=True
        )  
        step_control_log("Connection Successful")
        return conn
    except Exception as e:
        raise e

# COMMAND ----------

def read_data(conn,table_name,col_list,primary_key):
    try:
        if primary_key != "" and len(str(primary_key)) > 0:
            step_control_log("Executing Query : SELECT {} from {} WHERE {} <> -1".format(col_list,table_name,primary_key))
            print("Executing Query : SELECT {} from {} WHERE {} <> -1".format(col_list,table_name,primary_key))
            SQL_Query = "SELECT {} from {} WHERE {} <> -1".format(col_list,table_name,primary_key) 
            step_control_log("Query Execution Successful")
            cursor = conn.cursor()
            step_control_log("Fetching Records")
            cursor.execute(SQL_Query)
            records = cursor.fetchall()
            step_control_log("Record Fetching Completed")
            final_df = spark.createDataFrame(pd.DataFrame(records).astype(str).replace({'"':''},regex=True)).replace("NaN",None).replace("NaT",None).replace("None",None).toPandas()
            step_control_log("Converted Dictionary of records to Pandas Dataframe")
            return final_df
        else:
            step_control_log("Executing Query : SELECT {} from {} ".format(col_list,table_name))
            print("Executing Query : SELECT {} from {} ".format(col_list,table_name))
            SQL_Query = "SELECT {} from {} ".format(col_list,table_name) 
            step_control_log("Query Execution Successful")
            cursor = conn.cursor()
            step_control_log("Fetching Records")
            cursor.execute(SQL_Query)
            records = cursor.fetchall()
            step_control_log("Record Fetching Completed")
            final_df = spark.createDataFrame(pd.DataFrame(records).astype(str).replace({'"':''},regex=True)).replace("NaN",None).replace("NaT",None).replace("None",None).toPandas()
            step_control_log("Converted Dictionary of records to Pandas Dataframe")
            return final_df
    except Exception as e:
        raise e

# COMMAND ----------

def read_data_count(conn,table_name,col_list,primary_key):
    try:
        if primary_key != "" and len(str(primary_key)) > 0:
            step_control_log("Executing Query : SELECT COUNT(*) as cnt from {} WHERE {} <> -1".format(table_name,primary_key))
            print("Executing Query : SELECT COUNT(*) as cnt from {} WHERE {} <> -1".format(table_name,primary_key))
            SQL_Count_Query = "SELECT COUNT(*) as cnt from {} WHERE {} <> -1".format(table_name,primary_key) 
            step_control_log("Query Execution Successful")
            cursor = conn.cursor()
            step_control_log("Fetching Records Count")
            cursor.execute(SQL_Count_Query)
            records_count = cursor.fetchall()
            step_control_log("Record Fetching Completed")
            return records_count
        else:
            step_control_log("Executing Query : SELECT COUNT(*) as cnt from {}".format(table_name))
            print("Executing Query : SELECT COUNT(*) as cnt from {}".format(table_name))
            SQL_Count_Query = "SELECT COUNT(*) as cnt from {} ".format(table_name) 
            step_control_log("Query Execution Successful")
            cursor = conn.cursor()
            step_control_log("Fetching Records Count")
            cursor.execute(SQL_Count_Query)
            records_count = cursor.fetchall()
            step_control_log("Record Fetching Completed")
            return records_count
    except Exception as e:
        raise e

# COMMAND ----------

from io import BytesIO, StringIO
def write_as_csv(dataframe,raw_folder):
    try:
        s3_resource = boto3.resource('s3')
        dest_path = raw_path.format(raw_folder,tbl_name,current_timestamp.strftime('%Y%m%d%H%M%S'))
        output_csv_buffer = StringIO()
        dataframe.to_csv(output_csv_buffer,index=False)
        step_control_log("Writing Data to Path : s3://{}/{}".format(raw_bucket,dest_path))
        s3_resource.Object(raw_bucket, dest_path).put(Body=output_csv_buffer.getvalue())
    except Exception as e:
        raise e

# COMMAND ----------

import pandas as pd
import boto3
def wrapper():
    try:
        config = read_config()
        col_list = ",".join(config["col_list"])
        primary_key = "".join(config["primary_key"])
        secret_name = ""
        conn = setup_connection(secret_name)
        final_df = read_data(conn,table_name,col_list,primary_key)
        final_df_count = read_data_count(conn,table_name,col_list,primary_key)
        return_dict.update({"source_count": int(final_df_count[0]['cnt'])})
        return_dict.update({"target_count": int(len(final_df))})
        write_as_csv(final_df,config["raw_path"])
    except Exception as e:
        raise e

# COMMAND ----------

#Try/except block is used for handling exceptions in the user's code
try:
    wrapper()
except Exception as e:
  return_dict.update({"error_msg":str(e)})
finally:
  return_dict.update({"message":message})
  dbutils.notebook.exit(json.dumps(return_dict))

# COMMAND ----------


