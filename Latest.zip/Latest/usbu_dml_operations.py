# Databricks notebook source

backup_query = dbutils.widgets.get('backup_query').strip()
update_query = dbutils.widgets.get('update_query').strip()
delete_query = dbutils.widgets.get('delete_query').strip()

# COMMAND ----------

# taking the table backup
if backup_query:
    try:
        if backup_query.lower().startswith("create"):
            backup_query = """{}""".format(backup_query)
            print("Backup and query: {}".format(backup_query))
            spark.sql(backup_query)
            print("Backup completed successfully")
        else:
            raise ValueError("Backup table statement entire wrogly or used the wrong parameter to pass the statement, please correct it and re execute")         
    except Exception as err:
        errr =str(err)
        errr =errr[:300]
        raise ValueError("Error: {}".format(errr))

# COMMAND ----------

# updating the table
if update_query:
    try:
        if update_query.lower().startswith("update"):
            update_query = """{}""".format(update_query)
            print("table update and query: {}".format(update_query))
            spark.sql(update_query)
            print("Updated completed successfully")
        else:
            raise ValueError("Update table statement entire wrogly or used the wrong parameter to pass the statement, please correct it and re execute") 
    except Exception as err:
        errr =str(err)
        errr =errr[:300]
        raise ValueError("Error: {}".format(errr))

# COMMAND ----------



# COMMAND ----------

# ---Delete records from the Table ---
if delete_query:
    try:
        if delete_query.lower().startswith("delete"):
            delete_query = """{}""".format(delete_query)
            print("Delete records from the Table and query: {}".format(delete_query))
            spark.sql(delete_query)
            print("Daleted completed successfully")
        else:
            raise ValueError("Delete table statement entire wrogly or used the wrong parameter to pass the statement , please correct it and re execute") 
    except Exception as err:
        errr =str(err)
        errr =errr[:300]
        raise ValueError("Error: {}".format(errr))
