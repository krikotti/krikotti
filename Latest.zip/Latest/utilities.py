# Databricks notebook source
from pyspark.sql import functions as f
from pyspark.sql import types as t

# COMMAND ----------

import json

# COMMAND ----------

def get_bucket():
  return "s3://tpc-aws-ted-prd-edpp-bdm-mount-us-east-1"

def get_raw_bucket():
  return "s3://tpc-aws-ted-prd-edpp-raw-mdm-us-east-1"

def get_processed_bucket():
  return "s3://tpc-aws-ted-prd-edpp-processed-mdm-us-east-1"
  
def get_prefix():
  return "IICS/omni_mdm/SIT/TgtFiles/Reltio"
  
def get_key():
  return "bdm/com_da/paramfile/outbound_config_gattex_leads.json"

def get_delta_table_path(data_type, table_name):
  return "{bucket}/{prefix}/databricks_tmp/delta/{data_type}/{table_name}/".format(
    bucket=get_bucket(), 
    prefix=get_prefix(), 
    data_type=data_type,
    table_name=table_name
  )

def get_tmp_csv_path(table_name):
  return "{bucket}/{prefix}/databricks_tmp/canonical/tmp_csv_folders/{table_name}/".format(
    bucket=get_bucket(), 
    prefix=get_prefix(), 
    table_name=table_name
  )

def get_output_csv_path(data_type):
  return "{bucket}/{prefix}/databricks_tmp/canonical/{data_type}/".format(
    bucket=get_bucket(), 
    prefix=get_prefix(), 
    data_type=data_type
  )

