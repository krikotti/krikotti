# Databricks notebook source
import time
from pyspark.sql.types import (StructField, StringType, StructType, IntegerType)

start_time = time.time()
dbs = spark.sql("show databases").collect()
time_in_seconds = (time.time() - start_time)
print(f"{round(time_in_seconds,2)} seconds for database listing.")
run_stats = []
for db in dbs:
  start_time = time.time()
  tables_count = spark.sql(f"show tables in `{db.databaseName}`").count()
  time_in_seconds = (time.time() - start_time)
  run_stats.append((db.databaseName,tables_count,round(time_in_seconds,2)))

# COMMAND ----------

schema = StructType([
       StructField("name", StringType(), True),
       StructField("table_count", StringType(), True),
       StructField("duration_in_seconds", StringType(), True)])
 
df =spark.createDataFrame(run_stats,schema)
df.createOrReplaceTempView("run_stats")
display(sql("select * from run_stats"))

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

#display(sql("select * from run_stats where name like '%collibra_catalog%'"))

# COMMAND ----------

# %sql
# show tables in `collibra_catalog_8364e6ea-4e5c-4585-9c57-4624902096a1_7715ce76-774b-4040-a6d9-87d2639cf9d6_1po5n6`

# COMMAND ----------

# --%sql
# --show tables in `collibra_catalog_9d3b1550-2642-4a89-a3f5-5de15a97880c_6f35f389-b796-495e-9a2d-6b036805a596`

# COMMAND ----------

# %sql
# show tables in corp_us_hub 

# COMMAND ----------

