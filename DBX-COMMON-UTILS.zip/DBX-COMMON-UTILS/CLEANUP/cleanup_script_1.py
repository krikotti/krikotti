# Databricks notebook source
# MAGIC %md The VACUUM operation in Delta tables can affect table versions and data retrieval in certain scenarios. Here are some considerations regarding table versions and data retrieval after performing the VACUUM operation:
# MAGIC
# MAGIC Table versioning: In Delta Lake, table versions are maintained to track changes made to the table over time. The VACUUM operation removes old versions of files that are no longer needed, which can impact the table versioning. After the VACUUM operation, the older versions of data files are deleted, and the table version is updated to reflect the removal of these files. This means that you won't be able to access the deleted data using the table's history or time travel queries. Data retrieval from older versions: If you need to retrieve data from older versions of the table, it's important to consider the impact of the VACUUM operation. If you have performed the VACUUM operation and removed old versions of files, you won't be able to directly retrieve data from those deleted versions.
# MAGIC
# MAGIC However, if you have taken backups or checkpoints of the table before the VACUUM operation, you can still access the data from those backups or checkpoints.
# MAGIC
# MAGIC Time Travel queries: Delta Lake provides the ability to perform time travel queries to access data as it existed at specific points in time. However, the VACUUM operation can affect the availability of data for time travel queries. After the VACUUM operation, only the retained versions of the table files will be available for time travel queries. Old versions that have been removed by the VACUUM operation won't be accessible. To mitigate the impact on table versions and data retrieval, consider the following best practices:
# MAGIC
# MAGIC Before performing the VACUUM operation, ensure that you have backups or checkpoints of the table to preserve older versions of data if needed.
# MAGIC
# MAGIC If you require data retention for compliance or historical purposes, adjust the retention period accordingly, balancing storage usage and the ability to access older versions of data.
# MAGIC
# MAGIC Be mindful of the timing and scheduling of the VACUUM operation to minimize the impact on data retrieval and queries.
# MAGIC
# MAGIC By understanding the implications of the VACUUM operation on table versions and data retrieval, you can plan and manage your data maintenance processes effectively. %

# COMMAND ----------

# MAGIC %sql
# MAGIC create database if not exists dbx_us_vacuum
# MAGIC location 's3://tpc-aws-ted-tst-edpp-hub-com-eu-central-1/dbx_us_vacuum.db'
# MAGIC comment 'database for vacuum results';

# COMMAND ----------

# MAGIC %sql
# MAGIC show tables in dbx_us_vacuum

# COMMAND ----------

# MAGIC %sql
# MAGIC desc database default

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE spark_catalog.dbx_us_vacuum.clean_details (
# MAGIC   database STRING,
# MAGIC   table STRING,
# MAGIC   vacuum_timestamp TIMESTAMP,
# MAGIC   size_before_in_mb DOUBLE,
# MAGIC   size_after_in_mb DOUBLE,
# MAGIC   cleaned_size_in_mb DOUBLE,
# MAGIC   duration_in_seconds DOUBLE)
# MAGIC USING delta
# MAGIC TBLPROPERTIES (
# MAGIC   'delta.minReaderVersion' = '1',
# MAGIC   'delta.minWriterVersion' = '2')

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE spark_catalog.dbx_us_vacuum.clean_details
# MAGIC ADD COLUMN duration_in_seconds DOUBLE 

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into spark_catalog.dbx_us_vacuum.clean_details  select * from spark_catalog.dbx_us_vacuum.clean_details_bkp

# COMMAND ----------

# MAGIC %sql
# MAGIC select to_date(vacuum_timestamp, 'yyyy-MM-dd') from
# MAGIC   dbx_us_vacuum.clean_details limit 10

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   database,
# MAGIC   --to_date(vacuum_timestamp, 'yyyy-MM-dd') as data_of_cleanup,
# MAGIC   concat(
# MAGIC     CAST((before_size) AS STRING),
# MAGIC     ' GB'
# MAGIC   ) as before_size,
# MAGIC   concat(
# MAGIC     CAST((after_size) AS STRING),
# MAGIC     ' GB'
# MAGIC   ) as after_size,
# MAGIC   concat(
# MAGIC     CAST((cleaned_size) AS STRING),
# MAGIC     ' GB'
# MAGIC   ) as cleaned_size,
# MAGIC   before_size / (before_size + after_size) * 100 AS saved_percentage,
# MAGIC   after_size / (before_size + after_size) * 100 AS after_percentage,
# MAGIC   table_count
# MAGIC from
# MAGIC   (
# MAGIC     select
# MAGIC       database,
# MAGIC       (round(sum(cleaned_size_in_mb) / 1024, 2)) as cleaned_size,
# MAGIC       (round(sum(size_before_in_mb) / 1024, 2)) as before_size,
# MAGIC       (round(sum(size_after_in_mb) / 1024, 2)) as after_size,
# MAGIC       count(table) as table_count
# MAGIC     from
# MAGIC       dbx_us_vacuum.clean_details -- where
# MAGIC       --   database = 'com_us_hub'
# MAGIC     group by
# MAGIC       database
# MAGIC       --to_date(vacuum_timestamp, 'yyyy-MM-dd')
# MAGIC     order by
# MAGIC       --to_date(vacuum_timestamp, 'yyyy-MM-dd') desc,
# MAGIC       cleaned_size desc
# MAGIC   )
# MAGIC where
# MAGIC   cleaned_size > 0

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   database,
# MAGIC   --to_date(vacuum_timestamp, 'yyyy-MM-dd') as data_of_cleanup,
# MAGIC   concat(
# MAGIC     CAST((before_size) AS STRING),
# MAGIC     ' GB'
# MAGIC   ) as before_size,
# MAGIC   concat(
# MAGIC     CAST((after_size) AS STRING),
# MAGIC     ' GB'
# MAGIC   ) as after_size,
# MAGIC   concat(
# MAGIC     CAST((cleaned_size) AS STRING),
# MAGIC     ' GB'
# MAGIC   ) as cleaned_size,
# MAGIC   before_size / (before_size + after_size) * 100 AS saved_percentage,
# MAGIC   after_size / (before_size + after_size) * 100 AS after_percentage,
# MAGIC   table_count
# MAGIC from
# MAGIC   (
# MAGIC     select
# MAGIC       database,
# MAGIC       (round(sum(cleaned_size_in_mb) / 1024, 2)) as cleaned_size,
# MAGIC       (round(sum(size_before_in_mb) / 1024, 2)) as before_size,
# MAGIC       (round(sum(size_after_in_mb) / 1024, 2)) as after_size,
# MAGIC       count(table) as table_count
# MAGIC     from
# MAGIC       dbx_us_vacuum.clean_details -- where
# MAGIC       --   database = 'com_us_hub'
# MAGIC     group by
# MAGIC       database
# MAGIC       --to_date(vacuum_timestamp, 'yyyy-MM-dd')
# MAGIC     order by
# MAGIC       --to_date(vacuum_timestamp, 'yyyy-MM-dd') desc,
# MAGIC       cleaned_size desc
# MAGIC   )
# MAGIC where
# MAGIC   cleaned_size > 0

# COMMAND ----------

# MAGIC %sql
# MAGIC set spark.databricks.delta.formatCheck.enabled=false

# COMMAND ----------

df = spark.read.format("delta").load('s3://tpc-aws-ted-dev-edpp-hub-com-eu-central-1/dbx_us_vacuum.db/clean_details/part-00000-1ba21e7f-70bc-445b-abe0-fc0c307e6b9c-c000.snappy.parquet')

# COMMAND ----------

display(dbutils.fs.ls('s3://tpc-aws-ted-dev-edpp-hub-com-eu-central-1/dbx_us_vacuum.db/'))

# COMMAND ----------

# MAGIC %sql
# MAGIC desc database com_de_mart

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from dbx_us_vacuum.non_delta_tables

# COMMAND ----------

##done 'com_de_hub',
##database_names = ['com_de_mart_ca','com_de_mart_anz','com_de_mart_eucan','com_de_mart_ru']   #['com_de_mart_br'] #Done['corp_de_mart_gia','com_de_mart_ukie','com_de_alyt']

#database_names = ['com_de_mart_anz','com_de_mart_eucan','com_de_mart_ru','com_de_mart_ch','com_de_mart_uk','com_de_mart_tw','com_de_mart_in','com_de_mart_my','com_de_mart_th','com_de_mart_hk','com_de_mart_sg','com_de_mart_kr','com_de_mart_vn','com_de_mart_it','com_de_mart_mx','com_de_mart_il','com_de_mart_es','com_de_mart_om','com_de_mart_dz','com_de_mart_kz','com_de_mart_tr','com_de_mart_bh','com_de_mart_icmea','com_de_mart_id','com_de_mart_pt','com_de_mart_qa','com_de_mart_ae','com_de_mart_apac','com_de_mart_kw','com_de_mart_sa','com_de_mart_ua','com_de_mart_by','com_de_mart_za','com_de_mart_ec','com_de_mart_iberia','com_de_mart_sam','com_de_mart_ph','com_de_mart_at','com_de_mart_co','com_de_mart_nl','com_de_mart_uz','com_de_mart_ie','com_de_mart_ar','com_de_mart_az','com_de_mart_no','com_de_mart_se','com_de_mart_lv','com_de_mart_pl','com_de_mart_si','com_de_mart_pe','com_de_mart_ro','com_de_mart_rs','com_de_mart_fr','com_de_mart_de','com_de_mart_sk','com_de_mart_gem','com_de_mart_xk','corp_de_mart_smart','com_de_mart_me','com_de_mart_gpd','com_de_mart_be','com_de_mart_dk','com_de_mart_ee','com_de_mart_fi','com_de_mart_bg','com_de_mart_hr','com_de_mart_hu','com_de_mart_lt','com_de_mart_mk','com_de_mart_al','com_de_mart_cz','com_de_mart_gr','com_de_mart_ba','com_de_mart_czsk','com_de_mart_is','com_de_mart_cy','corp_de_mart','corp_de_raw_hrpa','com_de_mart_lb','com_de_mart_nz','com_de_mart_mea','com_de_mart_eg','com_de_mart_nordics','com_de_mart_cn','com_de_mart_mn','com_de_mart_tn','com_de_mart_bb','com_de_mart_ge','com_de_mart_am','com_de_mart_mcoee','com_de_mart_lu','com_de_mart_tj','com_de_mart_belux','com_de_mart_kg','com_de_mart_cl','com_de_mart_le','com_de_mart_uy','com_de_mart_do','com_de_mart_bn','com_de_mart_iq','com_de_mart_py','com_de_mart_tm','com_de_mart_sd','com_de_mart_ir','com_de_mart_lk','com_de_mart_ly','com_de_mart_gt','com_de_mart_cr','com_de_mart_er','com_de_mart_pa','com_de_mart_gb','com_de_mart_gpd_akv','com_de_mart_bz','com_de_mart_jp','corp_de_hub_gia','corp_de_hub_hr','corp_de_lake_hr','com_de_mart_stg_br','corp_de_alyt_hr','com_de_lake_gpr','com_de_mart_bk','com_de_mart_gobu','com_de_alyt_cxdh','corp_hrpa','corp_de_raw','corp_de_lake_hrpa','corp_de_raw_hr','corp_de_hub_hrpa','corp_de_mart_hrpa','com_de_mart_px_eucan','com_de_mart_takhzyro_natpar','com_de_mart_gpr','com_de_mart_au','com_de_mart_todai_eucan','logs_gem_eucan_grants','corp_de_hub_veeva','com_de_mart_glbl','com_de_mart_patient_metrics','com_de_hub_gpr','eds_de_lake_cdp','gia_de_mart','com_de_mart_vbu','gia_de_lake','com_de_mart_af','com_de_mart_ao','com_de_mart_apachq','com_de_mart_bd','com_de_mart_bm','com_de_mart_bo','com_de_mart_bs','com_de_mart_bw','com_de_mart_cb','com_de_mart_cis','com_de_mart_cu','com_de_mart_emadj','com_de_mart_emrs','com_de_mart_ep','com_de_mart_et','com_de_mart_gemhq','com_de_mart_gh','com_de_mart_grcn','com_de_mart_hn','com_de_mart_ht','com_de_mart_io','com_de_mart_jm','com_de_mart_jo','com_de_mart_ke','com_de_mart_ky','com_de_mart_ls','com_de_mart_ma','com_de_mart_md','com_de_mart_mm','com_de_mart_mo','com_de_mart_mu','com_de_mart_mz','com_de_mart_na','com_de_mart_ng','com_de_mart_ni','com_de_mart_np','com_de_mart_ol','com_de_mart_olexp','com_de_mart_ome','com_de_mart_pc','com_de_mart_pk','com_de_mart_rap','com_de_mart_relip','com_de_mart_rmag','com_de_mart_rme','com_de_mart_rmena3','com_de_mart_rmeta','com_de_mart_rol','com_de_mart_rru','com_de_mart_rw','com_de_mart_sb','com_de_mart_so','com_de_mart_ss','com_de_mart_su','com_de_mart_sv','com_de_mart_sy','com_de_mart_sz','com_de_mart_tt','com_de_mart_tz','com_de_mart_ug','com_de_mart_ve','com_de_mart_ye','com_de_mart_zw','com_de_rpt_ukie','corp_de_mart_veeva','test','com_de_pii_hub','ted-gms']
# 
# 
# database_names = ['ukie','cto_dedev_alyt_eds','com_de_mart_cs','com_de_mart_euadj','com_de_mart_eurs','com_de_mart_hqee','com_de_mart_li','com_de_mart_mc','com_de_mart_mt','com_de_mart_ps','com_de_mart_rne','com_de_mart_rsceeu','com_de_raw','corp_de_alyt_immuta_output_hr','com_de_alyt_gem','com_de_mart_atm','com_de_mart_us','corp_hrpa_dev','gia_de_raw','com_de_mart_tender','com_de_alyt_il','com_de_mart_pii_px','com_de_selfservice_eucan','corp_de_lake_veeva','corp_de_alyt_immuta_inputs','com_de_alyt','com_de_pii_lake']

# Donedatabase_names = ['default']

# COMMAND ----------

database_names = ['com_de_mart_ukie','com_de_mart_br','com_de_mart_ca','com_de_mart_eucan','com_de_mart_anz','com_de_mart_ch','com_de_mart_ru','com_de_mart_tw','com_de_mart_iberia','com_de_mart_il','com_de_mart_in','com_de_mart_my','com_de_mart_th','com_de_mart_uk','com_de_mart_hk','com_de_mart_it','com_de_mart_sg','com_de_mart_mx','com_de_mart_kr','com_de_mart_vn','com_de_mart_es','com_de_mart_pt','com_de_mart_dz','com_de_mart_sa','com_de_mart_tr','com_de_mart_bh','com_de_mart_id','com_de_mart_kw','com_de_mart_kz','com_de_mart_om','com_de_mart_qa','com_de_mart_ua','com_de_mart_ae','com_de_mart_by','com_de_mart_icmea','com_de_mart_za','com_de_mart_ec','com_de_mart_apac','com_de_mart_at','com_de_mart_de','com_de_mart_ie','com_de_mart_co','com_de_mart_ph','com_de_mart_sam','com_de_mart_nl','com_de_mart_ar','com_de_mart_fr','com_de_mart_lv','com_de_mart_no','com_de_mart_se','com_de_mart_pl','com_de_mart_si','com_de_mart_ro','com_de_mart_rs','com_de_mart_sk','com_de_mart_uz','com_de_mart_az','com_de_mart_pe','com_de_mart_gem','com_de_mart_xk','com_de_mart_gpd','com_de_mart_me','com_de_mart_be','com_de_mart_dk','com_de_mart_ee','com_de_mart_fi','com_de_mart_lt','com_de_mart_bg','com_de_mart_hr','com_de_mart_hu','com_de_mart_al','com_de_mart_mk','com_de_mart_cz','com_de_mart_gr','com_de_mart_ba','com_de_mart_is','com_de_mart_czsk','com_de_mart_cy','corp_de_mart_smart','com_de_mart_lb','com_de_mart_mea','com_de_mart_nordics','com_de_mart_nz','com_de_mart_belux','com_de_mart_lu','com_de_mart_mcoee','com_de_mart_eg','com_de_mart_cn','com_de_mart_bb','com_de_mart_am','com_de_mart_ge','com_de_mart_tn','com_de_mart_mn','com_de_mart_cl','com_de_mart_kg','com_de_mart_tj','com_de_mart_le','corp_de_mart_gia','com_de_mart_uy','com_de_mart_do','com_de_mart_iq','com_de_mart_py','com_de_mart_bn','com_de_mart_ir','com_de_mart_ly','com_de_mart_sd','com_de_mart_tm','com_de_mart_lk','com_de_mart_gb','com_de_mart_cr','com_de_mart_gt','com_de_mart_bz','com_de_mart_jp','com_de_mart_todai_eucan','com_de_mart_pa','com_de_mart_er','com_de_mart_stg_br','com_de_mart_bk','com_de_mart_gobu','com_de_mart_takhzyro_natpar','com_de_mart_px_eucan','com_de_mart_gpr','com_de_mart_glbl','corp_de_mart','corp_de_mart_hrpa','com_de_mart_af','com_de_mart_ao','com_de_mart_apachq','com_de_mart_au','com_de_mart_bd','com_de_mart_bm','com_de_mart_bo','com_de_mart_bs','com_de_mart_bw','com_de_mart_cb','com_de_mart_cis','com_de_mart_cu','com_de_mart_emadj','com_de_mart_emrs','com_de_mart_ep','com_de_mart_et','com_de_mart_gemhq','com_de_mart_gh','com_de_mart_grcn','com_de_mart_hn','com_de_mart_ht','com_de_mart_io','com_de_mart_jm','com_de_mart_jo','com_de_mart_ke','com_de_mart_ky','com_de_mart_ls','com_de_mart_ma','com_de_mart_md','com_de_mart_mm','com_de_mart_mo','com_de_mart_mu','com_de_mart_mz','com_de_mart_na','com_de_mart_ng','com_de_mart_ni','com_de_mart_np','com_de_mart_ol','com_de_mart_olexp','com_de_mart_ome','com_de_mart_pc','com_de_mart_pk','com_de_mart_rap','com_de_mart_relip','com_de_mart_rmag','com_de_mart_rme','com_de_mart_rmena3','com_de_mart_rmeta','com_de_mart_rol','com_de_mart_rru','com_de_mart_rw','com_de_mart_sb','com_de_mart_so','com_de_mart_ss','com_de_mart_su','com_de_mart_sv','com_de_mart_sy','com_de_mart_sz','com_de_mart_tt','com_de_mart_tz','com_de_mart_ug','com_de_mart_ve','com_de_mart_ye','com_de_mart_zw','gia_de_mart','com_de_mart_patient_metrics','com_de_mart_vbu','com_de_mart_cs','com_de_mart_euadj','com_de_mart_eurs','com_de_mart_hqee','com_de_mart_li','com_de_mart_mc','com_de_mart_mt','com_de_mart_ps','com_de_mart_rne','com_de_mart_rsceeu','com_de_mart_atm','com_de_mart_todai_ukie','com_de_mart_tender','com_de_mart_umea','corp_de_mart_veeva','com_de_mart_pii_px','com_de_mart_todai_ca']

# COMMAND ----------

database_names = ['com_de_alyt_cxdh','com_de_alyt_ca','com_de_alyt_anz','com_de_alyt_gpr','cto_detst_alyt_eds','com_de_alyt_il','com_de_alyt_gem','com_de_alyt_todai_eucan','com_de_alyt'] ##,'com_de_mart']

# COMMAND ----------

'com_de_alyt_cxdh','com_de_alyt_ca','com_de_alyt_anz','com_de_alyt_gpr','cto_detst_alyt_eds','com_de_alyt_il','com_de_alyt_gem','com_de_alyt_todai_eucan','com_de_alyt',


# COMMAND ----------

query = "select table from dbx_us_vacuum.clean_details"
temp_tables = spark.sql(query)
temp_table_names = set(row.table for row in temp_tables.collect())

# COMMAND ----------

temp_table_names

# COMMAND ----------

from pyspark.sql.functions import expr
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, LongType, DoubleType, TimestampType
import time

vacuum_details_table = "dbx_us_vacuum.clean_details"
non_delta_tables_table = "dbx_us_vacuum.non_delta_tables"

start_time = time.time()
# Create empty list to store non-Delta tables
non_delta_tables = []
# Create empty list to store Delta tables
vacuum_delta_tables = []

for database_name in database_names:
    start_time = time.time()
    if database_name.strip() == "":
        print("Invalid database name. Please provide a valid database name.")
    else:
        # Execute the SHOW VIEWS query
        try:
            vw_length = 0
            # Get a list of views in the database
            views = spark.sql(f"SHOW VIEWS IN {database_name}")
            # Get a list of view names
            view_names = set(row.viewName for row in views.collect())
            # Get the length of the set
            vw_length = len(view_names)
            # Print the length
            print("Total Count of Views only",vw_length)
            
        except Exception as e:
            print(f"Ignoring error: {str(e)}")

    # Get the list of tables in the database
    #tables = set(spark.sql(f"SHOW TABLES IN {database_name}").select("tableName").collect()) 
    tables = spark.sql(f"SHOW TABLES IN {database_name}")
    table_names = set(row.tableName for row in tables.collect())
    #tables = spark.sql(f"SHOW TABLES IN {database_name}").select("tableName").rdd.flatMap(lambda x: x).collect()
    #print("tables",tables)
    # Get the length of the set
    length = len(table_names)

    # Print the length
    print("Total Count of Tables and Views",length)
    if vw_length > 0:
        # Get tables without views
        tables_without_views = table_names - view_names
    else:
        tables_without_views = table_names
    tab_length = len(tables_without_views)
    #tables_without_views = tables_without_views - temp_table_names
    # Print the length
    print("Total Count of Tables only",tab_length)
    time_in_seconds = (time.time() - start_time)
    print(f"{round(time_in_seconds,2)} seconds for database table listing.")
    # Iterate over each table and perform VACUUM operation for Delta tables
    for table in tables_without_views:
        table_name = table
        start_time = time.time()
        try:
            # Check if the table is a Delta table
            is_delta_table = spark.sql(f"DESCRIBE EXTENDED {database_name}.{table_name}").filter("col_name = 'Provider'") \
                .select("data_type").collect()[0][0] == "delta"

            if is_delta_table:
                # Get the table location
                location_result = spark.sql(f"DESCRIBE EXTENDED {database_name}.{table_name}").filter("col_name = 'Location'")
                table_location = location_result.select("data_type").collect()[0][0]
                # Calculate the size of the table before vacuuming
                file_sizes_before = dbutils.fs.ls(table_location)
                size_before = sum(file.size for file in file_sizes_before) / (1024 * 1024)  # Convert to MB

                # Perform VACUUM operation
                spark.sql(f"VACUUM {database_name}.{table_name} RETAIN 240 HOURS")

                # Calculate the size of the table after vacuuming
                file_sizes_after = dbutils.fs.ls(table_location)
                size_after = sum(file.size for file in file_sizes_after) / (1024 * 1024)  # Convert to MB

                # Calculate cleaned-up size
                cleaned_size = size_before - size_after
                time_in_seconds = (time.time() - start_time)
                vacuum_delta_tables.append((database_name, table_name, spark.sql("SELECT CURRENT_TIMESTAMP").first()[0],
    size_before, size_after, cleaned_size, round(time_in_seconds,2)))
                print('table_name',table_name)
                # Print the vacuum details
                #vacuum_details.show(truncate=False)
            else:
                non_delta_tables.append((database_name,table_name))
        except Exception as e:
            # Ignore the error and continue to the next table
            print(f"Error occurred for table {database_name}.{table_name}")
            non_delta_tables.append((database_name,table_name))
            continue  

        # else:
        #     non_delta_tables.append((database_name,table_name))


    # Create schema for vacuum details
    schema = StructType([
        StructField("database", StringType(), nullable=False),
        StructField("table", StringType(), nullable=False),
        StructField("vacuum_timestamp", TimestampType(), nullable=False),
        StructField("size_before_in_mb", DoubleType(), nullable=False),
        StructField("size_after_in_mb", DoubleType(), nullable=False),
        StructField("cleaned_size_in_mb", DoubleType(), nullable=False),
        StructField("duration_in_seconds", DoubleType(), nullable=False)  
    ])

    # Create vacuum details DataFrame
    # vacuum_details = spark.createDataFrame(
    #     [(database_name, table_name, spark.sql("SELECT CURRENT_TIMESTAMP").first()[0],
    #     size_before, size_after, cleaned_size)],
    #     schema=schema
    # )
    vacuum_details_df = spark.createDataFrame(vacuum_delta_tables,schema=schema)

    # Write vacuum details to table
    vacuum_details_df.write.format("delta").mode("append").saveAsTable(vacuum_details_table)
    # Create DataFrame for non-Delta tables
    #non_delta_tables_df = spark.createDataFrame([(table,) for table in non_delta_tables], ["table"])


    schema = StructType([
        StructField("database_name", StringType(), True),
        StructField("table_name", StringType(), True)])
    
    non_delta_tables_df = spark.createDataFrame(non_delta_tables,schema)
    #non_delta_tables_df = spark.createDataFrame([(table,) for table in non_delta_tables], ["table"])

    # Write non-Delta tables to table
    non_delta_tables_df.write.format("delta").mode("overwrite").saveAsTable(non_delta_tables_table)
    print("Done",database_name)
print("Successfully Finished ",database_name)
# Print the list of non-Delta tables
#non_delta_tables_df.show(truncate=False)


# COMMAND ----------

database_names = ['com_de_alyt_cxdh','com_de_alyt_ca','com_de_alyt_anz','com_de_alyt_gpr','cto_detst_alyt_eds','com_de_alyt_il','com_de_alyt_gem','com_de_alyt_todai_eucan','com_de_alyt'] ##,'com_de_mart']

# COMMAND ----------

database_names = ['eds_de_eu_lake']

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, DoubleType, TimestampType
from delta.tables import DeltaTable
import time

# Create empty lists to store non-Delta tables and vacuum details
non_delta_tables = []
vacuum_delta_tables = []

vacuum_details_table = "dbx_us_vacuum.clean_details"
non_delta_tables_table = "dbx_us_vacuum.non_delta_tables"

# Assuming you have the list of database names in 'database_names' variable

for database_name in database_names:
    # if not database_name.strip():
    #     print("Invalid database name. Please provide a valid database name.")
    #     #continue
    
    start_time = time.time()
    if database_name.strip() == "":
        print("Invalid database name. Please provide a valid database name.")
    else:
        try:
            # Get a list of table names and view names
            tables = spark.sql(f"SHOW TABLES IN {database_name}").select("tableName").rdd.flatMap(lambda x: x).collect()
            views = spark.sql(f"SHOW VIEWS IN {database_name}").select("viewName").rdd.flatMap(lambda x: x).collect()
            view_names = set(views)
            
            # Filter out tables without views (non-Delta tables)
            tables_without_views = [table for table in tables if table not in view_names]
            
            for table_name in tables_without_views:
                try:
                    # Check if the table is a Delta table using DeltaTable API
                    table_path = f"{database_name}.{table_name}"
                    is_delta_table = DeltaTable.isDeltaTable(table_path)

                    if is_delta_table:
                        # Get the table location
                        table_location = DeltaTable.forPath(spark, table_path).path()

                        # Calculate the size of the table before vacuuming
                        file_sizes_before = dbutils.fs.ls(table_location)
                        size_before = sum(file.size for file in file_sizes_before) / (1024 * 1024)  # Convert to MB

                        # Perform VACUUM operation
                        DeltaTable.forPath(spark, table_path).vacuum(retentionHours=240)

                        # Calculate the size of the table after vacuuming
                        file_sizes_after = dbutils.fs.ls(table_location)
                        size_after = sum(file.size for file in file_sizes_after) / (1024 * 1024)  # Convert to MB

                        # Calculate cleaned-up size
                        cleaned_size = size_before - size_after
                        duration_in_seconds = time.time() - start_time
                        vacuum_delta_tables.append((database_name, table_name, spark.sql("SELECT CURRENT_TIMESTAMP").first()[0], size_before, size_after, cleaned_size, round(duration_in_seconds, 2)))
                    else:
                        non_delta_tables.append((database_name, table_name))
                except Exception as e:
                    # Ignore the error and continue to the next table
                    print(f"Error occurred for table {database_name}.{table_name}: {str(e)}")
                    continue
        except Exception as e:
            print(f"Ignoring error: {str(e)}")

        # Create schema for vacuum details
        schema = StructType([
            StructField("database", StringType(), nullable=False),
            StructField("table", StringType(), nullable=False),
            StructField("vacuum_timestamp", TimestampType(), nullable=False),
            StructField("size_before_in_mb", DoubleType(), nullable=False),
            StructField("size_after_in_mb", DoubleType(), nullable=False),
            StructField("cleaned_size_in_mb", DoubleType(), nullable=False),
            StructField("duration_in_seconds", DoubleType(), nullable=False)
        ])

        # Create vacuum details DataFrame
        vacuum_details_df = spark.createDataFrame(vacuum_delta_tables, schema=schema)

        # Write vacuum details to table
        vacuum_details_df.write.format("delta").mode("append").saveAsTable(vacuum_details_table)
        print("Written the data")
        # Create schema for non-Delta tables
        non_delta_tables_schema = StructType([
            StructField("database_name", StringType(), True),
            StructField("table_name", StringType(), True)
        ])

        # Create DataFrame for non-Delta tables
        non_delta_tables_df = spark.createDataFrame(non_delta_tables, non_delta_tables_schema)

        # Write non-Delta tables to table
        non_delta_tables_df.write.format("delta").mode("overwrite").saveAsTable(non_delta_tables_table)

print("Successfully Finished.")


# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, DoubleType, TimestampType
from delta.tables import DeltaTable
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

# Function to perform VACUUM operation for a Delta table
def perform_vacuum(table_path):
    try:
        delta_table = DeltaTable.forPath(spark, table_path)
        # Get the table location
        table_location = delta_table.path()

        # Calculate the size of the table before vacuuming
        file_sizes_before = dbutils.fs.ls(table_location)
        size_before = sum(file.size for file in file_sizes_before) / (1024 * 1024)  # Convert to MB

        # Perform VACUUM operation
        delta_table.vacuum(retentionHours=240)

        # Calculate the size of the table after vacuuming
        file_sizes_after = dbutils.fs.ls(table_location)
        size_after = sum(file.size for file in file_sizes_after) / (1024 * 1024)  # Convert to MB

        # Calculate cleaned-up size
        cleaned_size = size_before - size_after
        duration_in_seconds = time.time() - start_time
        vacuum_delta_tables.append((table_path, size_before, size_after, cleaned_size, round(duration_in_seconds, 2)))
    except Exception as e:
        # Ignore the error and continue to the next table
        print(f"Error occurred for table {table_path}: {str(e)}")
        pass

# Rest of the code...

# Function to process a single database
def process_database(database_name):
    try:
        # Get a list of table names and view names
        tables = spark.sql(f"SHOW TABLES IN {database_name}").select("tableName").rdd.flatMap(lambda x: x).collect()
        views = spark.sql(f"SHOW VIEWS IN {database_name}").select("viewName").rdd.flatMap(lambda x: x).collect()
        view_names = set(views)

        # Filter out tables without views (non-Delta tables)
        tables_without_views = [table for table in tables if table not in view_names]

        for table_name in tables_without_views:
            try:
                # Check if the table is a Delta table using DeltaTable API
                table_path = f"{database_name}.{table_name}"
                is_delta_table = DeltaTable.isDeltaTable(spark, table_path)

                if is_delta_table:
                    perform_vacuum(table_path)
                else:
                    non_delta_tables.append((database_name, table_name))
            except Exception as e:
                # Ignore the error and continue to the next table
                print(f"Error occurred for table {database_name}.{table_name}: {str(e)}")
                continue
    except Exception as e:
        print(f"Ignoring error: {str(e)}")

# Update the main loop to process databases in parallel using ThreadPoolExecutor
with ThreadPoolExecutor(max_workers=4) as executor:
    futures = [executor.submit(process_database, database_name) for database_name in database_names]
    for future in as_completed(futures):
        pass

# Rest of the code...


# COMMAND ----------


from pyspark.sql import SparkSession
from pyspark.sql.functions import expr
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, LongType, DoubleType, TimestampType
import time

# Create a Spark session
spark = SparkSession.builder \
    .appName("Vacuuming Delta Tables") \
    .getOrCreate()

vacuum_details_table = "dbx_us_vacuum.clean_details"
non_delta_tables_table = "dbx_us_vacuum.non_delta_tables"

# Function to perform VACUUM operation on a single table
def vacuum_table(database_name, table_name):
    try:
        # Check if the table is a Delta table
        is_delta_table = spark.sql(f"DESCRIBE EXTENDED {database_name}.{table_name}").filter("col_name = 'Provider'") \
            .select("data_type").collect()[0][0] == "delta"

        if is_delta_table:
            # Get the table location
            location_result = spark.sql(f"DESCRIBE EXTENDED {database_name}.{table_name}").filter("col_name = 'Location'")
            table_location = location_result.select("data_type").collect()[0][0]
            # Calculate the size of the table before vacuuming
            file_sizes_before = dbutils.fs.ls(table_location)
            size_before = sum(file.size for file in file_sizes_before) / (1024 * 1024)  # Convert to MB

            # Perform VACUUM operation
            spark.sql(f"VACUUM {database_name}.{table_name} RETAIN 240 HOURS")

            # Calculate the size of the table after vacuuming
            file_sizes_after = dbutils.fs.ls(table_location)
            size_after = sum(file.size for file in file_sizes_after) / (1024 * 1024)  # Convert to MB

            # Calculate cleaned-up size
            cleaned_size = size_before - size_after
            time_in_seconds = (time.time() - start_time)
            return (database_name, table_name, spark.sql("SELECT CURRENT_TIMESTAMP").first()[0],
                    size_before, size_after, cleaned_size, round(time_in_seconds, 2))
        else:
            return None
    except Exception as e:
        # Ignore the error and return None for non-Delta tables
        print(f"Error occurred for table {database_name}.{table_name}")
        return None

# Create empty list to store non-Delta tables
non_delta_tables = []
# Create empty list to store Delta tables
vacuum_delta_tables = []

# Enable DataFrame caching
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

# Parallel processing for each database name
for database_name in database_names:
    start_time = time.time()
    if database_name.strip() == "":
        print("Invalid database name. Please provide a valid database name.")
    else:
        try:
            vw_length = 0
            # Get a list of views in the database
            views = spark.sql(f"SHOW VIEWS IN {database_name}")
            # Get a list of view names
            view_names = set(row.viewName for row in views.collect())
            vw_length = len(view_names)
            print("Total Count of Views only", vw_length)
        except Exception as e:
            print(f"Ignoring error: {str(e)}")

    # Get the list of tables in the database
    tables = spark.sql(f"SHOW TABLES IN {database_name}")
    table_names = set(row.tableName for row in tables.collect())
    length = len(table_names)
    print("Total Count of Tables and Views", length)
    
    if vw_length > 0:
        # Get tables without views
        tables_without_views = table_names - view_names
    else:
        tables_without_views = table_names
    tab_length = len(tables_without_views)
    print("Total Count of Tables only", tab_length)
    time_in_seconds = (time.time() - start_time)
    print(f"{round(time_in_seconds,2)} seconds for database table listing.")

    # Parallel processing for VACUUM operation on Delta tables
    # parallel_vacuum_tables = sc.parallelize(tables_without_views).flatMap(lambda table: vacuum_table(database_name, table))
    # vacuum_delta_tables.extend(parallel_vacuum_tables.collect())
    # Collect the necessary information on the driver
    tables_without_views_list = list(tables_without_views)
    parallel_vacuum_tables = sc.parallelize(tables_without_views_list).flatMap(lambda table: vacuum_table(database_name, table))
    vacuum_delta_tables.extend(parallel_vacuum_tables.collect())

# # Collect the necessary information on the driver
# tables_without_views_list = list(tables_without_views)
# parallel_vacuum_tables = sc.parallelize(tables_without_views_list).flatMap(lambda table: vacuum_table(database_name, table))
# vacuum_delta_tables.extend(parallel_vacuum_tables.collect())

# Create schema for vacuum details
schema = StructType([
    StructField("database", StringType(), nullable=False),
    StructField("table", StringType(), nullable=False),
    StructField("vacuum_timestamp", TimestampType(), nullable=False),
    StructField("size_before_in_mb", DoubleType(), nullable=False),
    StructField("size_after_in_mb", DoubleType(), nullable=False),
    StructField("cleaned_size_in_mb", DoubleType(), nullable=False),
    StructField("duration_in_seconds", DoubleType(), nullable=False)
])

# Create vacuum details DataFrame
vacuum_details_df = spark.createDataFrame(vacuum_delta_tables, schema=schema)

# Write vacuum details to table
vacuum_details_df.write.format("delta").mode("append").saveAsTable(vacuum_details_table)

# Create DataFrame for non-Delta tables
schema = StructType([
    StructField("database_name", StringType(), True),
    StructField("table_name", StringType(), True)
])

non_delta_tables_df = spark.createDataFrame(non_delta_tables, schema)

# Write non-Delta tables to table
non_delta_tables_df.write.format("delta").mode("overwrite").saveAsTable(non_delta_tables_table)

print("Successfully Finished")


# COMMAND ----------

vacuum_delta_tables

# COMMAND ----------

vacuum_delta_tables

# COMMAND ----------

# Create schema for vacuum details
schema = StructType([
    StructField("database", StringType(), nullable=False),
    StructField("table", StringType(), nullable=False),
    StructField("vacuum_timestamp", TimestampType(), nullable=False),
    StructField("size_before_in_mb", DoubleType(), nullable=False),
    StructField("size_after_in_mb", DoubleType(), nullable=False),
    StructField("cleaned_size_in_mb", DoubleType(), nullable=False),
    StructField("duration_in_seconds", DoubleType(), nullable=False)  
])

# Create vacuum details DataFrame
# vacuum_details = spark.createDataFrame(
#     [(database_name, table_name, spark.sql("SELECT CURRENT_TIMESTAMP").first()[0],
#     size_before, size_after, cleaned_size)],
#     schema=schema
# )
vacuum_details_df = spark.createDataFrame(vacuum_delta_tables,schema=schema)

# Write vacuum details to table
vacuum_details_df.write.format("delta").mode("append").saveAsTable(vacuum_details_table)