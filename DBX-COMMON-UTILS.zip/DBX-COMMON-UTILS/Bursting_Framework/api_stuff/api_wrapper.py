# Databricks notebook source
"""
  The following use the logged in user's credentials to make all subsequent API calls.
  The person running this must be an administrator for some of the API calls but not all.
"""
api_url = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiUrl().get()
# api_url = "https://onetakeda-dedev.cloud.databricks.com/"
token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()

# COMMAND ----------

import requests
def make_post_request(endpoint, body):
  """
    Make a POST api call to Databricks. 
    Expects a variable called `api_url` to exist which is the base URL for the API.
    Expects a variable called `token` to exist which is used in the header for authentication.
    For example: https://dedev.databricks.onetakeda.com
    The endpoint parameter must be the Databricks' service endpoint such as "clusters" or "workspace".
    The body must be a dictionary which is posted as a JSON object.
    
  """
  url = "{base}/api/2.0/{endpoint}".format(base=api_url, endpoint=endpoint)
  headers = {'Authorization': 'Bearer {token}'.format(token=token)}
  response = requests.post(url, headers=headers, json=body, verify=True)
  if response.status_code == 200:
    return response.json()
  return response.content

def make_get_request(endpoint, params=None):
  """
    Make a GET api call to Databricks. 
    Expects a variable called `api_url` to exist which is the base URL for the API.
    Expects a variable called `token` to exist which is used in the header for authentication.
    For example: https://dedev.databricks.onetakeda.com
    The endpoint parameter must be the Databricks' service endpoint such as "clusters" or "workspace".
    The params must be a dictionary which is converted to url parameters.
    
  """
  url = "{base}/api/2.0/{endpoint}".format(base=api_url, endpoint=endpoint)
  headers = {'Authorization': 'Bearer {token}'.format(token=token)}
  response = requests.get(url, headers=headers, params=params, verify=True)
  if response.status_code == 200:
    return response.json()
  return response.content

# COMMAND ----------

def get_instance_profile_arn_for_group(group_name):
  """
    Systematically define the instance-profile and corresponding role ARN that MUST exist in AWS already.
    All IAM roles must be defined with the following pattern:
    "role-odl-<group_name>"
  """
  return "arn:aws:iam::{}:instance-profile/role-odl-{}".format(aws_account_id, group_name.lower())

# COMMAND ----------

def import_iam_policy_for_group(group_name):
  """
    Imports the instance-profile for a given group name (IAM role and instance profile must exist in AWS already).
    The imported instance profile can then be used when creating clusters.
    This role is also attached to the group for which it was created to allow users in the group to use the role 
    if they have create_cluster permissions. If not, then this doesn't matter but is there for the future.
  """
  endpoint = "instance-profiles/add"
  post_body = {
    "instance_profile_arn": get_instance_profile_arn_for_group(group_name)
  }
  return make_post_request(endpoint, post_body)

def import_iam_policy(policy_arn):
  """
    Imports the instance-profile (IAM role and instance profile must exist in AWS already).
    The imported instance profile can then be used when creating clusters.
    This role is also attached to the group for which it was created to allow users in the group to use the role 
    if they have create_cluster permissions. If not, then this doesn't matter but is there for the future.
  """
  endpoint = "instance-profiles/add"
  post_body = {
    "instance_profile_arn": policy_arn
  }
  return make_post_request(endpoint, post_body)

# COMMAND ----------

def create_group(group_name):
  """
    Create a group within Databricks with the given name.
    Attach a previously imported instance-profile to the group for use if desired.
  """
  endpoint = "preview/scim/v2/Groups"
  post_body = {
    "schemas": [
        "urn:ietf:params:scim:schemas:core:2.0:Group"
    ],
    "displayName": group_name,
    "roles": [{"value": get_instance_profile_arn(group_name)}]
  }
  return make_post_request(endpoint, post_body)

# COMMAND ----------

def create_cluster(group_name):
  """
    Create a cluster with default settings named with the group name.
    Permissions are not modifyable with the API hence the cluster is created under the user running this command.
    To modify permissions of the cluster, it must be done by the administrator user within the UI.
  """
  endpoint = "clusters/create"
  post_body = {
    "num_workers": None,
    "autoscale": {
        "min_workers": 2,
        "max_workers": 8
    },
    "cluster_name": group_name,
    "spark_version": "6.3.x-scala2.11",
    "spark_conf": {
        "spark.databricks.hive.metastore.glueCatalog.enabled": "true"
    },
    "aws_attributes": {
        "first_on_demand": 1,
        "availability": "SPOT_WITH_FALLBACK",
        "zone_id": "us-east-1a",
        "instance_profile_arn": get_instance_profile_arn(group_name),
        "spot_bid_price_percent": 100,
        "ebs_volume_count": 0
    },
    "node_type_id": "i3.xlarge",
    "ssh_public_keys": [],
    "custom_tags": {
      
    },
    "spark_env_vars": {
        "PYSPARK_PYTHON": "/databricks/python3/bin/python3"
    },
    "autotermination_minutes": 30,
    "init_scripts": [],
  }
  return make_post_request(endpoint, post_body)

# COMMAND ----------

# def create_service_account(username, password):
  
#   """{"credentials":"password","username":"TestServiceAccount","fullname":"Test Service Account","password":"TestServiceAccount1!","subject_name":null}"""
#   "Request URL: https://ustst.databricks.onetakeda.com/accounts"
#   "POST"
#   endpoint = "preview/scim/v2/Users"
#   post_body = {
#     "schemas":["urn:ietf:params:scim:schemas:core:2.0:User"],
#     "userName":username,
#     "groups":[{"serviceAccounts":"123456"}],
#   }
#   return make_post_request(endpoint, post_body)

# COMMAND ----------

import requests
def token_on_behalf_user(username, password, endpoint, body, call="POST"):
  """
    This function cannot use the notebook token in the headers because it is logging in as another user with a password.
  """
  userpass_url = api_url.replace("https://", "https://{}:{}@".format(username, password))
  url = "{base}/api/2.0/{endpoint}".format(base=userpass_url, endpoint=endpoint)
  
  if call == "POST":
    response = requests.post(url, headers={}, json=body, verify=True)
  else:
    response = requests.get(url, verify=True)

  if response.status_code == 200:
    return response.json()
  return response.content
  
def create_token_for_user(username, password, description, lifetime=None):
  endpoint = "token/create"
  body = {
    "comment": description
  }
  if lifetime:
    body['lifetime_seconds'] = lifetime
  return token_on_behalf_user(username, password, endpoint, body)

def revoke_token_for_user(username, password, token_id):
  endpoint = "token/delete"
  body = {
    "token_id": token_id
  }
  return token_on_behalf_user(username, password, endpoint, body)

def list_user_tokens(username, password):
  endpoint = "token/list"
  return token_on_behalf_user(username, password, endpoint, {}, call="GET")

# COMMAND ----------

def get_all_users():
  endpoint = "preview/scim/v2/Users"
  return make_get_request(endpoint)

# COMMAND ----------

def create_secret_scope(scope):
  endpoint = "secrets/scopes/create"
  post_body = {
    "scope": scope
  }
  return make_post_request(endpoint, post_body)

def store_secret_in_scope(scope, key, value):
  endpoint = "secrets/put"
  post_body = {
    "scope": scope,
    "key": key,
    "string_value": value
  }
  return make_post_request(endpoint, post_body)

# COMMAND ----------

def setup_usage_job_extract(env_bucket):
  """
    Bucket should be the shard root bucket such as: s3://tpc-aws-ted-dev-edpp-dbrks-us-east-1
  """
  endpoint = "usage/settings"
  post_body = {
    "aws_settings": {
      "s3_bucket": env_bucket
    }
  }
  return make_post_request(endpoint, post_body)

# COMMAND ----------

def getDbCreateSql(db_name, db_path):
  return "CREATE DATABASE IF NOT EXISTS {db_name} LOCATION '{db_path}'".format(db_name=db_name, db_path=db_path)

def getGrantPermissionSql(db_name, group_name, permission_type):
  return "GRANT {permission_type} ON DATABASE {db_name} TO `{group_name}`".format(permission_type=permission_type, db_name=db_name, group_name=group_name)

def availablePrivileges(privilege_to_test):
  return privilege_to_test.upper() in ["SELECT", "CREATE", "MODIFY", "READ_METADATA", "CREATE_NAMED_FUNCTION", "ALL PRIVILEGES"]

# COMMAND ----------

def create_metering_table(env, aws_region, shard_name):
  """
    env: dev, tst, prd
    aws_region: us-east-1, eu-central-1, ap-northeast-1
    shard_name: takeda-dev, takeda-qa, takeda-us-prd, takeda-mit, takeda-jp-dev, takeda-jp-tst, takeda-jp-prd, takeda-eu-dev, takeda-eu-tst, takeda-eu-prd
  """
  create_table_sql = """
  CREATE TABLE databricks.metering (
    workspaceId BIGINT,
    cloud STRING,
    meterName STRING,
    sku STRING,
    quantity DOUBLE,
    timestamp BIGINT,
    date STRING,
    tags MAP<STRING, STRING>,
    isPaying BOOLEAN)
  USING DELTA
  PARTITIONED BY (date, meterName)
  LOCATION 's3://tpc-aws-ted-{env}-edpp-dbrks-{region}/customer-logs/usage/{shard_name}/metering-tables/metering'
  """.format(env=env, region=aws_region, shard_name=shard_name)
  spark.sql(create_table_sql)