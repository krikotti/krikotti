# Databricks notebook source
deployments_conf = [{
	"aws_account_id": "263789222982",
	"env": "dev",
	"region": "us",
	"aws_region": "us-east-1",
	"cluster_zone": "a"
},{
	"aws_account_id": "263789222982",
	"env": "dev",
	"region": "de",
	"aws_region": "eu-central-1",
	"cluster_zone": "a"
},{
	"aws_account_id": "263789222982",
	"env": "dev",
	"region": "jp",
	"aws_region": "ap-northeast-1",
	"cluster_zone": "a"
},{
	"aws_account_id": "881018545998",
	"env": "tst",
	"region": "us",
	"aws_region": "us-east-1",
	"cluster_zone": "a"
},{
	"aws_account_id": "881018545998",
	"env": "tst",
	"region": "de",
	"aws_region": "eu-central-1",
	"cluster_zone": "a"
},{
	"aws_account_id": "881018545998",
	"env": "tst",
	"region": "jp",
	"aws_region": "ap-northeast-1",
	"cluster_zone": "a"
},{
	"aws_account_id": "432372222409",
	"env": "prd",
	"region": "us",
	"aws_region": "us-east-1",
	"cluster_zone": "a"
},{
	"aws_account_id": "432372222409",
	"env": "prd",
	"region": "de",
	"aws_region": "eu-central-1",
	"cluster_zone": "a"
},{
	"aws_account_id": "432372222409",
	"env": "prd",
	"region": "jp",
	"aws_region": "ap-northeast-1",
	"cluster_zone": "a"
}]

class DatabricksDeployments:
	def __init__(self, deployments_conf):
		self._deployments = {}
		for deployment in deployments_conf:
			env = deployment['env']
			region = deployment['region']
			self._deployments[env+region] = deployment

	def get_deployment_conf(self, env, region):
		return self._deployments[env+region]

	def get_root_bucket(self, env, region):
		conf = self.get_deployment_conf(env, region)
		return "tpc-aws-ted-{env}-edpp-dbrks-{aws_region}".format(
			env=conf['env'], 
			aws_region=conf['aws_region'])

	def get_cluster_zone_id(self, env, region):
		conf = self.get_deployment_conf(env, region)
		return "{aws_region}{cluster_zone}".format(
			aws_region=conf['aws_region'],
			cluster_zone=conf['cluster_zone'])

	def get_aws_account_id(self, env, region):
		conf = self.get_deployment_conf(env, region)
		return conf['aws_account_id']

