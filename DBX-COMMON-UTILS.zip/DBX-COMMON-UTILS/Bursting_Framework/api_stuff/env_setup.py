# Databricks notebook source
# MAGIC %run ./api_wrapper

# COMMAND ----------

# MAGIC %run ./config

# COMMAND ----------

users = get_all_users()
len(users['Resources'])

# COMMAND ----------

deployments = DatabricksDeployments(deployments_conf)

# COMMAND ----------

setup_usage_job_extract(deployments.get_root_bucket("prd", "de"))

# COMMAND ----------

# env: dev, tst, prd
# aws_region: us-east-1, eu-central-1, ap-northeast-1
# shard_name: takeda-dev, takeda-qa, takeda-us-prd, takeda-mit, takeda-jp-dev, takeda-jp-tst, takeda-jp-prd, takeda-eu-dev, takeda-eu-tst, takeda-eu-prd
create_metering_table("prd","eu-central-1","takeda-eu-prd")
# NOTE make sure cluster is not on GLUE

# COMMAND ----------

EU_PRD = [{
	"db_name": "com_de_raw",
	"db_path": "s3://tpc-aws-ted-prd-edpp-raw-com-eu-central-1/com_de_raw.db",
	"groups": {
		"grp-etl-Com-APAC": "SELECT",
		"grp-etl-Com-APAC-Admin": "ALL PRIVILEGES",
		"admins": "ALL PRIVILEGES"
	}
},{
	"db_name": "com_de_lake",
	"db_path": "s3://tpc-aws-ted-prd-edpp-lake-com-eu-central-1/com_de_lake.db",
	"groups": {
		"grp-etl-Com-APAC": "SELECT",
		"grp-etl-Com-APAC-Admin": "ALL PRIVILEGES",
		"admins": "ALL PRIVILEGES"
	}
},{
	"db_name": "com_de_hub",
	"db_path": "s3://tpc-aws-ted-prd-edpp-hub-com-eu-central-1/com_de_hub.db",
	"groups": {
		"grp-etl-Com-APAC": "SELECT",
		"grp-etl-Com-APAC-Admin": "ALL PRIVILEGES",
		"admins": "ALL PRIVILEGES"
	}
},{
	"db_name": "com_de_mart_sam",
	"db_path": "s3://tpc-aws-ted-prd-edpp-mart-com-eu-central-1/com_de_mart_sam.db",
	"groups": {
		"grp-etl-Com-APAC": "SELECT",
		"grp-etl-Com-APAC-Admin": "ALL PRIVILEGES",
		"admins": "ALL PRIVILEGES"
	}
},{
	"db_name": "com_de_mart_apac",
	"db_path": "s3://tpc-aws-ted-prd-edpp-mart-com-eu-central-1/com_de_mart_apac.db",
	"groups": {
		"grp-etl-Com-APAC": "SELECT",
		"grp-etl-Com-APAC-Admin": "ALL PRIVILEGES",
		"admins": "ALL PRIVILEGES"
	}
},{
	"db_name": "com_de_mart_anz",
	"db_path": "s3://tpc-aws-ted-prd-edpp-mart-com-eu-central-1/com_de_mart_anz.db",
	"groups": {
		"grp-etl-Com-APAC": "SELECT",
		"grp-etl-Com-APAC-Admin": "ALL PRIVILEGES",
		"admins": "ALL PRIVILEGES"
	}
},{
	"db_name": "com_de_mart_icmea",
	"db_path": "s3://tpc-aws-ted-prd-edpp-mart-com-eu-central-1/com_de_mart_icmea.db",
	"groups": {
		"grp-etl-Com-APAC": "SELECT",
		"grp-etl-Com-APAC-Admin": "ALL PRIVILEGES",
		"admins": "ALL PRIVILEGES"
	}
},{
	"db_name": "com_de_mart_ru",
	"db_path": "s3://tpc-aws-ted-prd-edpp-mart-com-eu-central-1/com_de_mart_ru.db",
	"groups": {
		"grp-etl-Com-APAC": "SELECT",
		"grp-etl-Com-APAC-Admin": "ALL PRIVILEGES",
		"admins": "ALL PRIVILEGES"
	}
},{
	"db_name": "com_de_mart_eucan",
	"db_path": "s3://tpc-aws-ted-prd-edpp-mart-com-eu-central-1/com_de_mart_eucan.db",
	"groups": {
		"grp-etl-Com-APAC": "SELECT",
		"grp-etl-Com-APAC-Admin": "ALL PRIVILEGES",
		"admins": "ALL PRIVILEGES"
	}
},{
	"db_name": "com_de_alyt",
	"db_path": "s3://tpc-aws-ted-prd-edpp-alyt-com-eu-central-1/com_de_alyt.db",
	"groups": {
		"grp-etl-Com-APAC": "SELECT",
		"grp-etl-Com-APAC-Admin": "ALL PRIVILEGES",
		"admins": "ALL PRIVILEGES"
	}
},{
	"db_name": "corp_de_raw",
	"db_path": "s3://tpc-aws-ted-prd-edpp-raw-corp-eu-central-1/corp_de_raw.db",
	"groups": {
		"grp-etl-cdp": "SELECT",
		"grp-etl-cdp-admin": "ALL PRIVILEGES",
		"admins": "ALL PRIVILEGES"
	}
},{
	"db_name": "corp_de_lake",
	"db_path": "s3://tpc-aws-ted-prd-edpp-lake-corp-eu-central-1/corp_de_lake.db",
	"groups": {
		"grp-etl-cdp": "SELECT",
		"grp-etl-cdp-admin": "ALL PRIVILEGES",
		"admins": "ALL PRIVILEGES"
	}
},{
	"db_name": "corp_de_hub",
	"db_path": "s3://tpc-aws-ted-prd-edpp-hub-corp-eu-central-1/corp_de_hub.db",
	"groups": {
		"grp-etl-cdp": "SELECT",
		"grp-etl-cdp-admin": "ALL PRIVILEGES",
		"admins": "ALL PRIVILEGES"
	}
},{
	"db_name": "corp_de_mart",
	"db_path": "s3://tpc-aws-ted-prd-edpp-mart-corp-eu-central-1/corp_de_mart.db",
	"groups": {
		"grp-etl-cdp": "SELECT",
		"grp-etl-cdp-admin": "ALL PRIVILEGES",
		"admins": "ALL PRIVILEGES"
	}
},{
	"db_name": "corp_de_alyt",
	"db_path": "s3://tpc-aws-ted-prd-edpp-alyt-corp-eu-central-1/corp_de_alyt.db",
	"groups": {
		"grp-etl-cdp": "SELECT",
		"grp-etl-cdp-admin": "ALL PRIVILEGES",
		"admins": "ALL PRIVILEGES"
	}
}]

# COMMAND ----------

def run_db_setup(confs):
  for conf in confs:
    if ("db_name" not in conf) or ("db_path" not in conf) or ("groups" not in conf):
      print("missing one of the required fields of db_name, db_path, groups in config: {}".format(conf))
      continue
    db_sql = getDbCreateSql(conf['db_name'], conf['db_path'])
    print(db_sql)
    spark.sql(db_sql)
#     if type(conf['groups']) != dict:
#       print("groups must be a dictionary of group names as keys and the previlidge for each group for the database.")
#     for group_name, privileges in conf['groups'].items():
#       for privilege in privileges:
#         if not availablePrivileges(privilege):
#           print("privilege is not one of the available ones. Please check the Databricks documentation.")
#         group_sql = getGrantPermissionSql(conf['db_name'], group_name, privilege)
#         print(group_sql)
#         spark.sql(group_sql)

# COMMAND ----------

run_db_setup(EU_PRD)

# COMMAND ----------

