# Databricks notebook source

GRANT SELECT, READ_METADATA, USAGE ON COM_DE_MART_UMEA.REF_CUSTOMER_MAP COM_DE_MART_UMEA;
GRANT SELECT, READ_METADATA, USAGE ON COM_DE_MART_UMEA.REF_PRICE COM_DE_MART_UMEA;
GRANT SELECT, READ_METADATA, USAGE ON COM_DE_MART_UMEA.TXN_DISTRIBUTOR_SALES COM_DE_MART_UMEA;
GRANT SELECT, READ_METADATA, USAGE ON COM_DE_MART_UMEA.TXN_TARGET_SALES COM_DE_MART_UMEA;
GRANT SELECT, READ_METADATA, USAGE ON COM_DE_MART_UMEA.REF_COUNTRY COM_DE_MART_UMEA;
GRANT SELECT, READ_METADATA, USAGE ON COM_DE_MART_UMEA.REF_PRODUCT COM_DE_MART_UMEA;

# COMMAND ----------

# MAGIC %py
# MAGIC ###RITM1822073
# MAGIC group_names = ["COM_DE_MART_UMEA"]
# MAGIC table_names = {'COM_DE_MART_UMEA.REF_CUSTOMER_MAP','COM_DE_MART_UMEA.REF_PRICE','COM_DE_MART_UMEA.TXN_DISTRIBUTOR_SALES','COM_DE_MART_UMEA.TXN_TARGET_SALES','COM_DE_MART_UMEA.REF_COUNTRY','COM_DE_MART_UMEA.REF_PRODUCT'}
# MAGIC privileges = "SELECT, READ_METADATA"
# MAGIC
# MAGIC for group_name in group_names:
# MAGIC     for table_name in table_names:
# MAGIC         query = "GRANT {} ON TABLE {} TO `{}`".format(privileges,table_name,group_name)
# MAGIC         spark.sql(query)
# MAGIC         print("query",query)

# COMMAND ----------

# MAGIC %py
# MAGIC ###RITM1822073
# MAGIC group_names = ["COM_DE_MART_UMEA"]
# MAGIC table_names = {'COM_DE_MART_UMEA.REF_CUSTOMER_MAP','COM_DE_MART_UMEA.REF_PRICE','COM_DE_MART_UMEA.TXN_DISTRIBUTOR_SALES','COM_DE_MART_UMEA.TXN_TARGET_SALES','COM_DE_MART_UMEA.REF_COUNTRY','COM_DE_MART_UMEA.REF_PRODUCT'}
# MAGIC privileges = "SELECT, READ_METADATA"
# MAGIC
# MAGIC for group_name in group_names:
# MAGIC     for table_name in table_names:
# MAGIC         query = "GRANT {} ON TABLE {} TO `{}`".format(privileges,table_name,group_name)
# MAGIC         spark.sql(query)
# MAGIC         print("query",query)

# COMMAND ----------

"PRIVILEGES".lower()

# COMMAND ----------

PRIVILEGES = "SELECT, READ_MATEDATA, CREATE, MODIFY"
database_name = 'pdt_us_alyt'
group_name = "Okta-DBX-E2-PDT-ANALYTICS-DataScientist"


# COMMAND ----------

query = "GRANT {} ON DATABASE {} TO `{}`".format(privilizes,database_name,group_name)
query