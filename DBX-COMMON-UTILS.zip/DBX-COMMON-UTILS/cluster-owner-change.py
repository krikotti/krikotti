# Databricks notebook source
# MAGIC %md Cluster Owner Change notebook 

# COMMAND ----------



# COMMAND ----------

##Get the token and the host name of the workspace from the notebook context variables.

TOKEN = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
DOMAIN = dbutils.notebook.entry_point.getDbutils().notebook().getContext().tags().get("browserHostName").get()

# COMMAND ----------

#
# Retrieve all the clusters info for the last 30 days  
#
import requests
bearer_token= f"Bearer {TOKEN}"
headers ={"Authorization":bearer_token}
endpoint="https://"+DOMAIN+"/api/2.0/clusters/list"
clusters = requests.get(endpoint,headers=headers).json()['clusters']

# COMMAND ----------

cluster_name_tosearch = ("API_","job-")
clusters_of_interest = [cluster for cluster in clusters if (not cluster['default_tags']['ClusterName'].startswith("API_") and not cluster['default_tags']['ClusterName'].startswith("job-") )]
change_owner="ddf53f00-ba5b-4aaa-9779-082919c21587"
clusters_of_interest_list = [cluster for cluster in clusters_of_interest if change_owner not in cluster['default_tags']['Creator']]
cluster_ids=[]
for cluster in clusters_of_interest_list:
    cluster_id=cluster['cluster_id']
    cluster_name=cluster['default_tags']['ClusterName']
    cluster_ids.append(cluster_id)

# COMMAND ----------

# value_list = ["value1", "value2", "value3"]
# for value in value_list:
#     if not value.startswith("API_") and not value.startswith("job-"):
#         print(value, "does not start with 'API_' or 'job-'")

# COMMAND ----------

cluster_ids


# COMMAND ----------


# cluster_name_tosearch = "API_"
# clusters_of_interest = [cluster for cluster in clusters if cluster_name_tosearch not in cluster['default_tags']['ClusterName']]
# cluster_name_tosearch = "job-"
# clusters_of_interest = [cluster for cluster in clusters_of_interest if cluster_name_tosearch not in cluster['default_tags']['ClusterName']]
# change_owner="ddf53f00-ba5b-4aaa-9779-082919c21587"
# clusters_of_interest = [cluster for cluster in clusters_of_interest if change_owner not in cluster['default_tags']['Creator']]
# cluster_ids=[]
# for cluster in clusters_of_interest:
#     cluster_id=cluster['cluster_id']
#     cluster_name=cluster['default_tags']['ClusterName']
#     cluster_ids.append(cluster_id)

# COMMAND ----------

####Working Function
import requests

def cluster_owner_change(cluster_id,change_owner):
    response = requests.post(
      'https://%s/api/2.0/clusters/change-owner' % (DOMAIN),
      headers={'Authorization': 'Bearer %s' % TOKEN},
      json = {
        "cluster_id":cluster_id,
        "owner_username":change_owner
        }
    )

    if response.status_code == 200:
      print('cluster_id',cluster_id)
    else:
      print("Error launching cluster_id: %s cluster: %s: %s" % (cluster_id, response.json()["error_code"], response.json()["message"]))



# COMMAND ----------

for cluster_id in cluster_ids: 
    cluster_owner_change(cluster_id,change_owner)

# COMMAND ----------

cust_ids = '1220-103102-sd092w0v' ##,'1130-125517-uzc1km7','1122-114216-rm5fi77z']

# COMMAND ----------

clusters_of_interests = [cluster for cluster in clusters_of_interest if cust_ids in cluster["cluster_id"]]

# COMMAND ----------

clusters_of_interests

# COMMAND ----------

import json
# Define the new configuration settings
new_config = {
    # Specify your new cluster configuration here
    "autotermination_minutes": 60
}
for cust_name in clusters_of_interests:  
    # Edit the cluster with the new configuration
    edit_cluster_url = "https://"+DOMAIN+"/api/2.0/clusters/edit"
    print(cust_name["cluster_id"])
    cust_id = cust_name["cluster_id"]
    print(cust_name["cluster_name"])
    edit_data = {
        "cluster_id": cust_name["cluster_id"],
        "cluster_name": cust_name["cluster_name"],
        "config": new_config  
    }

    response = requests.post(edit_cluster_url, headers=headers, data=json.dumps(edit_data))

    if response.status_code == 200:
        print(f"Edited cluster {cust_id} successfully")
    else:
        print(f"Failed to edit cluster {cust_id}. Status code: {response}")