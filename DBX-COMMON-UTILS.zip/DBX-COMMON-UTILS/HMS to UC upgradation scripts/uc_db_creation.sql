-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS dbx_uc_deprd.Upgrade_logs
COMMENT 'Managed Schema for UC Upgrade Tables Logs';

-- COMMAND ----------

alter database dbx_uc_deprd.Upgrade_logs owner to `unity-admins`

-- COMMAND ----------

desc database dbx_uc_deprd.Upgrade_logs