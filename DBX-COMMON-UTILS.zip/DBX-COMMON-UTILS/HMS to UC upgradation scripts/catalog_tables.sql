-- Databricks notebook source
CREATE TABLE spark_catalog.corp_de_mart.uc_catalog_table (
  SCHEMANAME STRING,
  TABLENAME STRING)
USING delta

-- COMMAND ----------

desc database corp_de_mart

-- COMMAND ----------

CREATE TABLE spark_catalog.corp_de_hub.uc_catalog_table (
  SCHEMANAME STRING,
  TABLENAME STRING)
USING delta

-- COMMAND ----------

insert into corp_de_mart.uc_catalog_table values ("corp_de_mart","txn_mrt_core_task_eu");

-- COMMAND ----------

-- MAGIC %md
-- MAGIC

-- COMMAND ----------

insert into corp_de_mart.uc_catalog_table values ("corp_de_mart","txn_mrt_core_case_eu_stg");
insert into corp_de_mart.uc_catalog_table values ("corp_de_mart","txn_mrt_core_case_eu");
insert into corp_de_mart.uc_catalog_table values ("corp_de_mart","txn_mrt_core_profl_eu");
insert into corp_de_mart.uc_catalog_table values ("corp_de_mart","txn_mrt_task_sla_eu");
insert into corp_de_mart.uc_catalog_table values ("corp_de_mart","txn_mrt_surveys_eu");
insert into corp_de_mart.uc_catalog_table values ("corp_de_mart","txn_mrt_sys_usr_eu");
insert into corp_de_mart.uc_catalog_table values ("corp_de_mart","txn_mrt_kb_knwldg_eu");
insert into corp_de_mart.uc_catalog_table values ("corp_de_mart","txn_mrt_kb_use_eu");
insert into corp_de_mart.uc_catalog_table values ("corp_de_mart","txn_mrt_sp_log_eu");

-- COMMAND ----------

insert into corp_de_hub.uc_catalog_table values ("corp_de_hub","txn_hub_core_task_eu");

-- COMMAND ----------

insert into corp_de_hub.uc_catalog_table values ("corp_de_hub","txn_hub_core_case_eu_stg");
insert into corp_de_hub.uc_catalog_table values ("corp_de_hub","txn_hub_core_case_eu");
insert into corp_de_hub.uc_catalog_table values ("corp_de_hub","txn_hub_core_profl_eu");
insert into corp_de_hub.uc_catalog_table values ("corp_de_hub","txn_hub_task_sla_eu");
insert into corp_de_hub.uc_catalog_table values ("corp_de_hub","txn_hub_surveys_eu");
insert into corp_de_hub.uc_catalog_table values ("corp_de_hub","txn_hub_sys_usr_eu");
insert into corp_de_hub.uc_catalog_table values ("corp_de_hub","txn_hub_kb_knwldg_eu");
insert into corp_de_hub.uc_catalog_table values ("corp_de_hub","txn_hub_kb_use_eu");
insert into corp_de_hub.uc_catalog_table values ("corp_de_hub","txn_hub_sp_log_eu");


-- COMMAND ----------

txn_hub_core_profl_eu
txn_hub_task_sla_eu
txn_hub_surveys_eu
txn_hub_sys_usr_eu
new_core_case1
txn_hub_kb_knwldg_eu
txn_hub_kb_use_eu
txn_hub_sp_log_eu

-- COMMAND ----------

txn_mrt_core_profl_eu
txn_mrt_task_sla_eu
txn_mrt_surveys_eu
txn_mrt_sys_usr_eu
new_core_case1
txn_mrt_kb_knwldg_eu
txn_mrt_kb_use_eu
txn_mrt_sp_log_eu

-- COMMAND ----------

insert into corp_de_hub.uc_catalog_table values ("corp_de_hub","txn_hub_core_case_eu_stg");
insert into corp_de_hub.uc_catalog_table values ("corp_de_hub","txn_hub_core_case_eu");

-- COMMAND ----------

insert into corp_de_hub.uc_catalog_table values ("corp_de_hub","txn_hub_core_case_eu_stg");
insert into corp_de_hub.uc_catalog_table values ("corp_de_hub","txn_hub_core_case_eu");

-- COMMAND ----------

select * from corp_de_hub.uc_catalog_table
