# Databricks notebook source
from pyspark.sql import functions as f
from pyspark.sql.types import *
import pandas as pd
pd.set_option('display.max_rows', 500)

# COMMAND ----------

# MAGIC %run /Users/saman.keshmiri@takeda.com/api_stuff/api_wrapper

# COMMAND ----------

display(spark.sql("select * from com_de_lake.data_security_metadata where target_database = 'COM_DE_MART_EUCAN' and module_name = 'Patient Metrics'"))

# COMMAND ----------

#load security metadata table into a dataframe
security_df = spark.sql("select * from com_de_lake.data_security_metadata where target_database = 'COM_DE_MART_EUCAN' and module_name = 'Patient Metrics'")

# COMMAND ----------

display(security_df)

# COMMAND ----------

# convert to metadata rdd to pandas dataframe
df_pd = security_df.toPandas()

# COMMAND ----------

# this will set owner of all source tables to admin
# this is a requirement for views to be created on top of source tables 
# ALL source tables need an owner.

list_source_tables = df_pd['Source_Database'] + '.' + df_pd['Source_Table_Name']
set_source_tables = set(list_source_tables)
lower_source_tables = [x.lower() for x in set_source_tables]
for table in lower_source_tables:
  spark.sql("ALTER TABLE {table} OWNER TO `admins`".format(table=table))

# COMMAND ----------

#converts the authfield column into an array of values
security_df2 = security_df.withColumn(
    "Authorization_Value",
    f.split(f.col("Authorization_Value"), ",\s*").cast(ArrayType(StringType()))
)

# COMMAND ----------

security_metadata_list = security_df2.collect()

# COMMAND ----------

#set of functions imported from 'corp_mart_security_V2 on 11/29 10:56PM'
def create_database(target_db_name):
  sql_statement = "CREATE DATABASE IF NOT EXISTS {target_db_name}".format(target_db_name=target_db_name)
  return sql_statement

def create_view_single(target_view_name, target_db_name, source_database, source_table_name, auth_field, auth_value):
  auth_value_temp = auth_value[0].strip("[]")
  if (auth_field.strip() == "") or (auth_value_temp == ""):
      view_statement = "CREATE OR REPLACE VIEW {target_db_name}.{target_view_name} AS SELECT * FROM {source_database}.{source_table_name}".format(target_db_name = target_db_name, target_view_name = target_view_name, source_database=source_database, source_table_name=source_table_name)
  else:
    if auth_field != "tender_country_key":
      view_statement = "CREATE OR REPLACE VIEW {target_db_name}.{target_view_name} AS SELECT * FROM {source_database}.{source_table_name} WHERE {auth_field} = '{auth_value}'".format(target_db_name = target_db_name, target_view_name = target_view_name, source_database=source_database, source_table_name=source_table_name,auth_field=auth_field,auth_value=auth_value_temp)
    else:
      view_statement = "CREATE OR REPLACE VIEW {target_db_name}.{target_view_name} AS SELECT * FROM {source_database}.{source_table_name} WHERE {auth_field} = '{auth_value}'".format(target_db_name = target_db_name, target_view_name = target_view_name, source_database=source_database, source_table_name=source_table_name,auth_field=auth_field,auth_value=auth_value_temp)
  return view_statement

def create_view_multiple(target_view_name, target_db_name, source_database, source_table_name, auth_field, auth_value):
  test_list = []
  for val in auth_value:
    test_list.append(val.strip('[]')[1:-1])
  auth_value_paren = '('+str(test_list)[1:-1] + ')'
  print(auth_value_paren)
  view_statement = "CREATE OR REPLACE VIEW {target_db_name}.{target_view_name} AS SELECT * FROM {source_database}.{source_table_name} WHERE {auth_field} IN {auth_value}".format(target_db_name = target_db_name, target_view_name = target_view_name, source_database=source_database, source_table_name=source_table_name,auth_field=auth_field,auth_value=auth_value_paren)
  return view_statement

def create_group_modified(group_name):
  """
    Create a group within Databricks with the given name.
    Attach a previously imported instance-profile to the group for use if desired.
  """
  endpoint = "preview/scim/v2/Groups"
  post_body = {
    "schemas": [
        "urn:ietf:params:scim:schemas:core:2.0:Group"
    ],
    "displayName": group_name,
#    "roles": [{"value": "arn:aws:iam::881018545998:instance-profile/role-Databricks-Worker-De-Test"}]
#    "roles": [{"value": "arn:aws:iam::432372222409:instance-profile/role-Databricks-Worker-PRD"}]
  }
  return make_post_request(endpoint, post_body)


def getGrantPermissionSqlView(db_name, view_name, group_name, permission_type):
  return "GRANT {permission_type} ON VIEW {db_name}.{view_name} TO `{group_name}`".format(permission_type=permission_type, db_name=db_name, view_name=view_name, group_name=group_name)

# COMMAND ----------

list_dbs = [x.lower() for x in set(df_pd.Target_Database)]

# COMMAND ----------

#create databases for all of the new country specific marts that we are creating
for db in list_dbs:
  target_path = 's3://tpc-aws-ted-prd-edpp-mart-com-eu-central-1/'+db+'.db'
  spark.sql("CREATE DATABASE IF NOT EXISTS {db} LOCATION '{path}'".format(db=db, path=target_path))

# COMMAND ----------

i=0
for r in security_metadata_list:
  source_database = r[0]
  source_table_name = r[1]
  authorization_field = r[2]
  authorization_value = r[3]
#  if authorization_field == "cntry_cd": #changing to lowercase 'cntry_cd'
#    authorization_field = "tender_country_key"
  target_database = r[4]
  target_view_name = r[5]
  data_sensitivity = r[6]
  if len(authorization_value) > 1:
    spark.sql(create_view_multiple(target_view_name, target_database, source_database, source_table_name, authorization_field, authorization_value))
    print("created: "+target_database+"."+target_view_name+" from: " +source_database+"."+source_table_name)
    if (data_sensitivity == 'N'):
      data_sens_grp_name = target_database
      create_group_modified(data_sens_grp_name) #group name will NOT be the same as the target database for data sensitive group
      #spark.sql("GRANT SELECT, READ_METADATA ON DATABASE {db_name} TO `{grp_name}`".format(db_name=data_sens_grp_name,grp_name=target_database)) #grants group select, read_metadata on target database
      #print("granted access to group "+data_sens_grp_name+" on database "+target_database)
      spark.sql(getGrantPermissionSqlView(target_database, target_view_name, data_sens_grp_name, "SELECT, READ_METADATA"))
      print("granted access to group "+data_sens_grp_name+" on view "+target_database+"."+target_view_name)
    else:
      grp_name_generic = target_database
      data_sens_grp_name = target_database+'_'+data_sensitivity
      create_group_modified(data_sens_grp_name)
      spark.sql(getGrantPermissionSqlView(target_database, target_view_name, data_sens_grp_name, "SELECT, READ_METADATA")) #grants select, read_metadata to data sensitive group on the view
      #spark.sql("REVOKE SELECT, READ_METADATA ON VIEW {db_name}.{view_name} FROM `{grp_name}`".format(db_name=target_database,view_name=target_view_name,grp_name=grp_name_generic))
      print("granted access to group "+data_sens_grp_name+" on view "+target_view_name)
      #print("revoked access from generic group "+grp_name_generic+" on view "+target_database+"."+target_view_name)
  else:  
    spark.sql(create_view_single(target_view_name, target_database, source_database, source_table_name, authorization_field, authorization_value))
    print("created: "+target_database+"."+target_view_name+" from: " +source_database+"."+source_table_name)
    if (data_sensitivity == 'N'):
      data_sens_grp_name = target_database
      create_group_modified(data_sens_grp_name) #group name will NOT be the same as the target database for data sensitive group
      #spark.sql("GRANT SELECT, READ_METADATA ON DATABASE {db_name} TO `{grp_name}`".format(db_name=data_sens_grp_name,grp_name=target_database)) #grants group select, read_metadata on target database
      #print("granted access to group "+data_sens_grp_name+" on database "+target_database)
      spark.sql(getGrantPermissionSqlView(target_database, target_view_name, data_sens_grp_name, "SELECT, READ_METADATA"))
      print("granted access to group "+data_sens_grp_name+" on view "+target_database+"."+target_view_name)
    else:
      grp_name_generic = target_database
      data_sens_grp_name = target_database+'_'+data_sensitivity
      create_group_modified(data_sens_grp_name)
      spark.sql(getGrantPermissionSqlView(target_database, target_view_name, data_sens_grp_name, "SELECT, READ_METADATA"))
      #spark.sql("REVOKE SELECT, READ_METADATA ON VIEW {db_name}.{view_name} FROM `{grp_name}`".format(db_name=target_database,view_name=target_view_name,grp_name=grp_name_generic))
      print("granted access to group "+data_sens_grp_name+" on view "+target_view_name)
      #print("revoked access from generic group "+grp_name_generic+" on view "+target_database+"."+target_view_name)
    print("created table at index"+str(i))
    i = i+1

# COMMAND ----------

# this needs to be ran post view creation 

list_target_tables = df_pd['Target_Database'] + '.' + df_pd['Target_View_Name']
set_target_tables = set(list_target_tables)
lower_target_tables = [x.lower() for x in set_target_tables]
i=0
for table in lower_target_tables:
  spark.sql("ALTER TABLE {table} OWNER to `admins`".format(table=table))
  print("assigned admin as owner for table " + table + " at index "+str(i))
  i=i+1

# COMMAND ----------

#need to build logic to go database by database and grant access to generic group on all of the objects that are not in the metadatatable 

#if the length of objects in the database in databricks is the same as the num of rows for that object in the metadata table, then we dont need to do that table

#this will isolate all of the databases that have more existing tables than the metadata list

list_delta_dbs = []
distinct_databases = df_pd['Target_Database'].unique()
for database in distinct_databases:
  len_existing_tables = len(spark.sql("show tables from {database_var}".format(database_var=database)).toPandas())
  len_metadata_tables = len(df_pd[df_pd['Target_Database']==database])
  if len_existing_tables == len_metadata_tables:
    print("Length of Metadata and Existing are the same, Database "+database+" will not require additional object permissions. Length of both was: " + str(len_existing_tables))
  else:
    list_delta_dbs.append(database)
    print("Added Database "+database+" to delta DB list. Num of existing DB tables was "+str(len_existing_tables)+" versus there being "+str(len_metadata_tables)+" in the Metadata table.")

# COMMAND ----------

list_delta_dbs

# COMMAND ----------

#this loop will go ahead and grant permission on the remaining tables that were in the existing but not the metadata one by one to the general group 
for database in list_delta_dbs:
  list_existing_tables = spark.sql("show tables from {database_var}".format(database_var=database)).toPandas()['tableName'].to_list()
  list_metadata_tables = df_pd[df_pd['Target_Database'] == database]['Target_View_Name']
  temp_list = [x.lower() for x in list_metadata_tables]
  delta_table_list = list(set(list_existing_tables) - set(temp_list)) #validate if this works...
  for table in delta_table_list:
    spark.sql(getGrantPermissionSqlView(database, table, database, "SELECT, READ_METADATA"))
    print("granted select, read_metadata on table "+database+"."+table+" to group "+database)

# COMMAND ----------

### commenting out entire revoke access logic
#revoke access loop
#start with views that have LEP in data sensitivity column
#revoke grant, read_metadata on LEP view from generic group name

# df_lep = security_df2.filter(f.col('Data_Sensitivity')=="LEP")
# revoke_table_list = df_lep.collect()
# i=0
# for r in revoke_table_list:
#   grp_name_generic = r[4]
#   target_database = r[4]
#   target_view_name = r[5]
#   if grp_name_generic not in ['COM_DE_MART_BB', 'COM_DE_MART_BZ', 'COM_DE_MART_BN','COM_DE_MART_GLBL','COM_DE_MART_IS', 'COM_DE_MART_JP','COM_DE_MART_LU','COM_DE_MART_LK']:
#     spark.sql("DENY SELECT, READ_METADATA ON VIEW {db_name}.{view_name} TO `{grp_name}`".format(db_name=target_database,view_name=target_view_name,grp_name=grp_name_generic))
#     print("denied access from generic group "+grp_name_generic+" on view "+target_database+"."+target_view_name+" at index "+str(i))
#     i=i+1