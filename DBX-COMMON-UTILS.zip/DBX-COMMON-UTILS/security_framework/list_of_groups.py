# Databricks notebook source
# MAGIC %md
# MAGIC ##### This code is to pull the current list of security groups

# COMMAND ----------

from pyspark.sql.types import ArrayType, StructField, StructType, StringType, IntegerType
from pyspark.sql import functions as f
from pyspark.sql.types import *
import pandas as pd
pd.set_option('display.max_rows', 500)

# COMMAND ----------

#load security metadata table into a dataframe
security_df = spark.sql("SELECT * FROM com_de_lake.data_security_metadata")

# COMMAND ----------

# convert to metadata rdd to pandas dataframe
df_pd = security_df.toPandas()

# COMMAND ----------

list_groups = []

# COMMAND ----------

i=0
for database in df_pd['Target_Database']:
  if df_pd['Data_Sensitivity'][i] == 'N':
    list_groups.append(database)
  else:
    temp = database+"_"+df_pd['Data_Sensitivity'][i]
    list_groups.append(temp)
  i=i+1

# COMMAND ----------

list_export = set(list_groups)

# COMMAND ----------

list_marts = set(df_pd['Target_Database'])

# COMMAND ----------

#displays the list of groups
display(spark.createDataFrame(list_marts, StringType()))

# COMMAND ----------

#displays the list of security groups
display(spark.createDataFrame(list_export, StringType()))