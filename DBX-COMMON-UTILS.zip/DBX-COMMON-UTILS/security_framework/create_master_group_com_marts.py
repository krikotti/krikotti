# Databricks notebook source
import pandas as pd

# COMMAND ----------

df_security_table = spark.sql("SELECT * FROM com_de_lake.data_security_metadata")

# COMMAND ----------

df_pd = df_security_table.toPandas()

# COMMAND ----------

# MAGIC %run /Users/saman.keshmiri@takeda.com/api_stuff/api_wrapper

# COMMAND ----------

def create_group_modified(group_name):
  """
    Create a group within Databricks with the given name.
    Attach a previously imported instance-profile to the group for use if desired.
  """
  endpoint = "preview/scim/v2/Groups"
  post_body = {
    "schemas": [
        "urn:ietf:params:scim:schemas:core:2.0:Group"
    ],
    "displayName": group_name,
    "roles": [{"value": "arn:aws:iam::881018545998:instance-profile/role-Databricks-Worker-De-Test"}]
#    "roles": [{"value": "arn:aws:iam::432372222409:instance-profile/role-Databricks-Worker-PRD"}]
  }
  return make_post_request(endpoint, post_body)


# COMMAND ----------

create_group_modified(group_name='COM_DE_MART_MASTER')

# COMMAND ----------

set_dbs = set(df_pd['Target_Database'])
for i,database in enumerate(set_dbs):
    spark.sql("GRANT SELECT, READ_METADATA ON DATABASE {db} TO `COM_DE_MART_MASTER`".format(db=database))
    print("Granted access to Master Group on Database {db} at position {pos}".format(db=database, pos=i))

# COMMAND ----------

