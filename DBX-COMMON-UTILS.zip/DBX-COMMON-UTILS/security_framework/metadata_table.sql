-- Databricks notebook source
select *
from com_de_lake.data_security_metadata
where Target_Database = 'COM_DE_MART_CA'

-- COMMAND ----------

-	txn_crm_multichnl_consent
-	txn_crm_approved_doc
-	txn_crm_consent_line
-	txn_crm_mc_cycle_chnl_plan
-	txn_crm_mc_cycle_plan
-	txn_crm_mc_cycle_plan_prod
-	txn_crm_mc_cycle_plan_tgt
-	txn_crm_sent_email
-	txn_crm_survey_dtl


-- COMMAND ----------

SELECT * 
FROM com_de_lake.data_security_metadata
WHERE Target_Database == 'COM_DE_MART_EUCAN'
and Target_View_Name == 'TXN_TM1_FIT_FIN'

-- COMMAND ----------

desc table extended com_de_mart_al.crm_account_vw

-- COMMAND ----------

show tables in com_de_mart_al

-- COMMAND ----------

CREATE DATABASE com_de_alyt_al
LOCATION 's3://'

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### when a user gets access to security group COM_DE_MART_AL -> this will also give them full read / write against the com_de_alyt_al layer

-- COMMAND ----------

1) getting read access to the mart layer
2) getting read/write access to the alyt layer

-- COMMAND ----------

desc table extended com_de_alyt_ca.age_group

-- COMMAND ----------

