-- Databricks notebook source
DESC TABLE EXTENDED com_de_lake.crm_user_vw

-- COMMAND ----------

ALTER TABLE com_de_lake.crm_user_vw OWNER TO `admins`  

-- COMMAND ----------

DESC TABLE EXTENDED com_de_lake.crm_user_vw

-- COMMAND ----------

desc table extended com_de_mart_hu.crm_address_vw

-- COMMAND ----------

desc table extended com_de_mart_th.ref_terr_alignment_intl

-- COMMAND ----------

-- MAGIC %py
-- MAGIC import pandas as pd
-- MAGIC df_pd = spark.sql("SELECT * FROM com_de_lake.data_security_metadata").toPandas()

-- COMMAND ----------

-- MAGIC %py
-- MAGIC df_pd.head()

-- COMMAND ----------

SELECT * FROM COM_DE_LAKE.crm_mccp_vw

-- COMMAND ----------

SELECT * FROM COM_DE_LAKE.crm_mccp_vw WHERE Country = 'ID'

-- COMMAND ----------

CREATE OR REPLACE VIEW COM_DE_MART_RU.crm_mccp_vw AS SELECT * FROM COM_DE_LAKE.crm_mccp_vw WHERE Country = 'ID'

-- COMMAND ----------

