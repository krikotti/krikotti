-- Databricks notebook source
SELECT
  *
FROM
  COM_DE_LAKE.data_security_metadata
WHERE
  Target_Database = 'COM_DE_MART_IT'

-- COMMAND ----------

SELECT
  *
FROM
  COM_DE_LAKE.data_security_metadata
WHERE
  Authorization_Field = 'country'

-- COMMAND ----------

REVOKE 
GRANT 

-- COMMAND ----------

select distinct(Authorization_Field)
from com_de_lake.data_security_metadata

-- COMMAND ----------

