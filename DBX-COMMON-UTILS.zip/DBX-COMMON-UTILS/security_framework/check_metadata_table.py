# Databricks notebook source
from pyspark.sql import functions as f
from pyspark.sql.types import *
import pandas as pd
pd.set_option('display.max_rows', 500)

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from com_de_lake.data_security_metadata 
# MAGIC WHERE Source_Database LIKE "CORP%"

# COMMAND ----------

# MAGIC %sql
# MAGIC select Source_Database, collect_set(Source_Table_Name)
# MAGIC from com_de_lake.data_security_metadata 
# MAGIC WHERE Source_Database LIKE "CORP%"
# MAGIC group by Source_Database

# COMMAND ----------

security_df = spark.sql("SELECT * FROM com_de_lake.data_security_metadata WHERE")

# COMMAND ----------

display(security_df)

# COMMAND ----------

df_pd = security_df.toPandas()

# COMMAND ----------

df_pd.tail(40)

# COMMAND ----------

df_pd.shape

# COMMAND ----------

df_pd[df_pd['Target_Database'] == 'COM_DE_MART_ANZ']

# COMMAND ----------

