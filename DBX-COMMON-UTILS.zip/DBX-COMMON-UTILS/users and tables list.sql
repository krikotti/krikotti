-- Databricks notebook source


-- COMMAND ----------

-- MAGIC %py
-- MAGIC from pyspark.sql import SparkSession
-- MAGIC
-- MAGIC # Initialize Spark session
-- MAGIC spark = SparkSession.builder.appName("TableListing").getOrCreate()
-- MAGIC
-- MAGIC # List of database names
-- MAGIC database_names = ["corp_de_hub", "corp_de_lake","corp_de_mart","corp_de_raw"]
-- MAGIC
-- MAGIC # Initialize an empty DataFrame to store the results
-- MAGIC final_df = spark.createDataFrame([], ["Database", "Table"])
-- MAGIC
-- MAGIC # Loop through each database and retrieve tables
-- MAGIC for db_name in database_names:
-- MAGIC     # Construct the SQL query
-- MAGIC     query = f"USE {db_name}; SHOW TABLES"
-- MAGIC     
-- MAGIC     # Execute the query and retrieve tables
-- MAGIC     tables_df = spark.sql(query)
-- MAGIC     
-- MAGIC     # Add details to the final DataFrame
-- MAGIC     tables_df_with_db = tables_df.withColumn("Database", db_name)
-- MAGIC     final_df = final_df.union(tables_df_with_db.select("Database", "tableName"))
-- MAGIC
-- MAGIC # Display the final DataFrame
-- MAGIC display(final_df)
-- MAGIC

-- COMMAND ----------

-- MAGIC %python
-- MAGIC from pyspark.sql import SparkSession
-- MAGIC from pyspark.sql.types import StructType, StructField, StringType
-- MAGIC
-- MAGIC # Initialize Spark session
-- MAGIC spark = SparkSession.builder.appName("EmptyDataFrame").getOrCreate()
-- MAGIC
-- MAGIC # Define the schema for the empty DataFrame
-- MAGIC schema = StructType([
-- MAGIC     StructField("database_name", StringType(), True),
-- MAGIC     StructField("table_name", StringType(), True)
-- MAGIC ])
-- MAGIC
-- MAGIC # Create an empty DataFrame with the specified schema
-- MAGIC empty_df = spark.createDataFrame([], schema)
-- MAGIC
-- MAGIC # Display the empty DataFrame
-- MAGIC empty_df.show()

-- COMMAND ----------

-- MAGIC %python
-- MAGIC from pyspark.sql import SparkSession
-- MAGIC from pyspark.sql.types import StructType, StructField, StringType
-- MAGIC from pyspark.sql.functions import lit
-- MAGIC import pandas as pd
-- MAGIC
-- MAGIC # Initialize Spark session
-- MAGIC spark = SparkSession.builder.appName("TableListing").getOrCreate()
-- MAGIC
-- MAGIC # List of database names
-- MAGIC # database_names = ["corp_de_hub", "corp_de_lake", "corp_de_mart", "corp_de_raw","corp_de_alyt"]
-- MAGIC database_names= spark.sql("show databases").toPandas()["databaseName"].tolist()
-- MAGIC
-- MAGIC # Initialize an empty DataFrame with an empty schema
-- MAGIC schema = StructType([
-- MAGIC     StructField("Database", StringType(), True),
-- MAGIC     StructField("table_name", StringType(), True)
-- MAGIC ])
-- MAGIC
-- MAGIC # Create an empty DataFrame with the specified schema
-- MAGIC final_df = spark.createDataFrame([], schema)
-- MAGIC
-- MAGIC # Loop through each database and retrieve tables
-- MAGIC for db_name in database_names:
-- MAGIC     # Construct the SQL query
-- MAGIC     use_db = f"USE {db_name};"
-- MAGIC     spark.sql(use_db)
-- MAGIC     query = f"SHOW TABLES"
-- MAGIC     
-- MAGIC     # Execute the query and retrieve tables
-- MAGIC     tables_df = spark.sql(query)
-- MAGIC     
-- MAGIC     # Add details to the final DataFrame
-- MAGIC     tables_df_with_db = tables_df.withColumn("Database", lit(db_name))
-- MAGIC     final_df = final_df.union(tables_df_with_db.select("Database", "tableName"))
-- MAGIC
-- MAGIC # Display the final DataFrame
-- MAGIC display(final_df)

-- COMMAND ----------

-- MAGIC %python
-- MAGIC from pyspark.sql import SparkSession
-- MAGIC from pyspark.sql.types import StructType, StructField, StringType
-- MAGIC
-- MAGIC # Initialize Spark session
-- MAGIC spark = SparkSession.builder.appName("TableListing").getOrCreate()
-- MAGIC
-- MAGIC # List of database names
-- MAGIC database_names = ["corp_de_hub", "corp_de_lake", "corp_de_mart", "corp_de_raw"]
-- MAGIC
-- MAGIC # Initialize an empty DataFrame with the specified schema
-- MAGIC schema = StructType([
-- MAGIC     StructField("Database", StringType(), True),
-- MAGIC     StructField("table_name", StringType(), True)
-- MAGIC ])
-- MAGIC
-- MAGIC # Create an empty DataFrame with the specified schema
-- MAGIC final_df = spark.createDataFrame([], schema)
-- MAGIC
-- MAGIC # Loop through each database and retrieve tables
-- MAGIC for db_name in database_names:
-- MAGIC     # Construct the SQL query
-- MAGIC     query = f"DESCRIBE TABLE {db_name}.*"
-- MAGIC     
-- MAGIC     # Execute the query and retrieve tables
-- MAGIC     tables_df = spark.sql(query)
-- MAGIC     
-- MAGIC     # Add details to the final DataFrame
-- MAGIC     tables_df_with_db = tables_df.withColumn("Database", db_name)
-- MAGIC     final_df = final_df.union(tables_df_with_db.select("Database", "tableName"))
-- MAGIC
-- MAGIC # Display the final DataFrame
-- MAGIC display(final_df)

-- COMMAND ----------

use corp_de_lake;
SHOW TABLES;

-- COMMAND ----------

hub --227 --41

-- COMMAND ----------

show users