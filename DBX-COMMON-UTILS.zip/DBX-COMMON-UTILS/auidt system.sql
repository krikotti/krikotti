-- Databricks notebook source
select workspace_id,
CASE
    WHEN workspace_id like '%3626691258112126%' THEN "jpdev"
    WHEN workspace_id like '%1058862015284785%' THEN "ustst"
    WHEN workspace_id like '%2033331146719248%' THEN "jpprd"
    WHEN workspace_id like '%5120932384972353%' THEN "mitdev"
    WHEN workspace_id like '%4311507526411502%' THEN "dedev"
    WHEN workspace_id like '%631113751561990%' THEN "usdev"
    WHEN workspace_id like '%2186391591496286%' THEN "usprd"
    WHEN workspace_id like '%845586985866129%' THEN "deprd"
    WHEN workspace_id like '%2944095046339467%' THEN "detst"
    WHEN workspace_id like '%4027261779416380%' THEN "jptst"
    ELSE "NON"
END as ENV,
user_identity.email as person_making_change,
request_params.commandText as command_text,
max(event_date)
from system.access.audit where event_date >= '2024-01-15' and request_params.commandText like '%txn_hub_core_case_eu%' or request_params.commandText like '%txn_hub_core_case_eu_stg%' 
--and workspace_id like '%1218280040453136%'
group by 1,2,3,4

-- COMMAND ----------

select workspace_id,
action_name,
service_name,
user_identity.email as person_making_change,
request_params.commandText as command_text,
max(event_date)
from system.access.audit where event_date >= '2024-02-15' and request_params.commandText like '%txn_hub_core_case_eu%' 
-- and workspace_id like '%1218280040453136%'
group by 1,2,3,4,5

-- COMMAND ----------

SELECT DISTINCT action_name,
service_name,user_identity.email AS user_email,request_params.name as table_name,request_params.clusterName
FROM system.access.audit
WHERE request_params.name = 'txn_hub_core_case_eu'
  AND event_date >= '2024-02-15'

-- COMMAND ----------

select * from 
(select workspace_id,
max(event_date),
user_identity.email as person_email_id,
action_name,
request_params.permission:principal:name as user_group,
user_agent
from system.access.audit where event_date >= '2023-01-01'
group by 1,3,4,5,6) where workspace_id like "%845586985866129%"
and action_name = "samlLogin"

-- COMMAND ----------

select workspace_id,
CASE
    WHEN workspace_id like '%3626691258112126%' THEN "jpdev"
    WHEN workspace_id like '%1058862015284785%' THEN "ustst"
    WHEN workspace_id like '%2033331146719248%' THEN "jpprd"
    WHEN workspace_id like '%5120932384972353%' THEN "mitdev"
    WHEN workspace_id like '%4311507526411502%' THEN "dedev"
    WHEN workspace_id like '%631113751561990%' THEN "usdev"
    WHEN workspace_id like '%2186391591496286%' THEN "usprd"
    WHEN workspace_id like '%845586985866129%' THEN "deprd"
    WHEN workspace_id like '%2944095046339467%' THEN "detst"
    WHEN workspace_id like '%4027261779416380%' THEN "jptst"
    ELSE "NON"
END as ENV,
event_date,
user_identity.email as person_email_id,
action_name,
request_params.permission:principal:name as user_group,
user_agent
from system.access.audit where event_date >= '2023-06-01'
--workspace_id like "%845586985866129%"
and action_name = "samlLogin"