# Databricks notebook source
# MAGIC %run /Users/saman.keshmiri@takeda.com/api_stuff/api_wrapper

# COMMAND ----------

import json
import requests
import pandas as pd

# COMMAND ----------

api_url = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiUrl().get()
token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()

# COMMAND ----------

url="{base}/api/2.0/groups/list".format(base=api_url)
print(url)
headers = {'Authorization': 'Bearer {token}'.format(token=token)}

# COMMAND ----------

response = requests.get(url, headers=headers, verify=False)
print(response)

# COMMAND ----------

parsed = json.loads(response.content.decode("utf-8"))

# COMMAND ----------

print(parsed)

# COMMAND ----------

parsed['group_names']

# COMMAND ----------

for group in parsed['group_names']:
  print(f"{group}")

# COMMAND ----------

url_users="{base}/api/2.0/groups/list-members".format(base=api_url)
PARAMS={"group_name": "admins"}
params=PARAMS
response = requests.get(url_users, headers=headers, params=params, verify=False)

# COMMAND ----------

#response = requests.get(url_users, headers=headers, params=params, verify=False)
#json.loads(response.content.decode("utf-8"))

# COMMAND ----------

#response = requests.get(url_users, headers=headers, params=params, verify=False)
#for user in json.loads(response.content.decode("utf-8"))['members']:
#  print(user['user_name'])

# COMMAND ----------

df_main = pd.DataFrame()

# COMMAND ----------

df_main.head()

# COMMAND ----------

parsed_user = []
for group in parsed['group_names']:
  url_users="{base}/api/2.0/groups/list-members".format(base=api_url)
  PARAMS={"group_name": f"{group}"}
  params=PARAMS
  response = requests.get(url_users, headers=headers, params=params, verify=False)
  try:
    for user in json.loads(response.content.decode("utf-8"))['members']:
      parsed_user.append([f"{group}", user['user_name']])
  except:
    print(f"******************************** error at {group} ********************************")
  df_main = df_main.append(parsed_user, ignore_index=True)
  print(f"completed group: {group}")

# COMMAND ----------

#parsed_user

# COMMAND ----------

type(parsed_user)

# COMMAND ----------

df_main

# COMMAND ----------



# COMMAND ----------

df_main_no_dupes = df_main.drop_duplicates()

# COMMAND ----------

sparkDF = spark.createDataFrame(df_main_no_dupes.reset_index().drop(['index'],axis=1).rename(columns={0:"Group_Name", 1:"User_ID"}))

# COMMAND ----------

display(sparkDF)

# COMMAND ----------

sparkDF.write.mode("overwrite").saveAsTable("databricks_user_list_E2")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from default.databricks_user_list_E2

# COMMAND ----------

# %sql
# select * from default.databricks_user_list_E2 where User_ID like "%vignesh.g@takeda.com%"

# COMMAND ----------

