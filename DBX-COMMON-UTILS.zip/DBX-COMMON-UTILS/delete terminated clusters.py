# Databricks notebook source
##Get the token and the host name of the workspace from the notebook context variables.

token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
host_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().tags().get("browserHostName").get()

# COMMAND ----------

import requests
# Databricks workspace URL
DATABRICKS_HOST = f"https://{host_name}"

# Databricks API token
DATABRICKS_TOKEN = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()

# COMMAND ----------

import requests

def check_cluster_status(json_dic):
    response = requests.get(
          'https://%s/api/2.0/clusters/get' % (DOMAIN),
          headers={'Authorization': 'Bearer %s' % (TOKEN)},
          json=json_dic
          )
    print(response.status_code)
    if response.status_code == 200:
        return response.json()['state']
    else:
        return "ERROR"

# Function to get all terminated clusters starting with "API_"
def get_terminated_clusters():
    endpoint = "/api/2.0/clusters/list"
    headers = {
        "Authorization": f"Bearer {DATABRICKS_TOKEN}"
    }
    params = {
        "state": "TERMINATED"
    }

    response = requests.get(DATABRICKS_HOST + endpoint, headers=headers, params=params)
    response_json = response.json()

    return [cluster for cluster in response_json["clusters"] if (cluster["cluster_name"].startswith("API_") and cluster["state"] == 'TERMINATED')]

# Function to delete a cluster by cluster ID
def delete_cluster(cluster_id):
    endpoint = f"/api/2.0/clusters/permanent-delete"
    headers = {
        "Authorization": f"Bearer {DATABRICKS_TOKEN}"
    }
    data = {
        "cluster_id": cluster_id
    }

    response = requests.post(DATABRICKS_HOST + endpoint, headers=headers, json=data)
    return response.json()

# Main function to delete all terminated clusters starting with "API_"
def delete_terminated_clusters():
    terminated_clusters = get_terminated_clusters()
    
    if not terminated_clusters:
        print("No terminated clusters starting with 'API_' found.")
        return
    
    for cluster in terminated_clusters:
        cluster_id = cluster["cluster_id"]
        print(f"Deleting cluster with ID: {cluster_id}")
        # result = delete_cluster(cluster_id)
        # print(result)

if __name__ == "__main__":
    delete_terminated_clusters()

# COMMAND ----------

import requests

def check_cluster_status(json_dic):
    response = requests.get(
          'https://%s/api/2.0/clusters/get' % (DOMAIN),
          headers={'Authorization': 'Bearer %s' % (TOKEN)},
          json=json_dic
          )
    print(response.status_code)
    if response.status_code == 200:
        return response.json()['state']
    else:
        return "ERROR"

# Function to get all terminated clusters starting with "API_"
def get_terminated_clusters():
    endpoint = "/api/2.0/clusters/list"
    headers = {
        "Authorization": f"Bearer {DATABRICKS_TOKEN}"
    }
    params = {
        "state": "TERMINATED"
    }

    response = requests.get(DATABRICKS_HOST + endpoint, headers=headers, params=params)
    response_json = response.json()

    return [cluster for cluster in response_json["clusters"] if (cluster["cluster_name"].startswith("API_") and cluster["state"] == 'TERMINATED')]

# Function to delete a cluster by cluster ID
def delete_cluster(cluster_id):
    endpoint = f"/api/2.0/clusters/permanent-delete"
    headers = {
        "Authorization": f"Bearer {DATABRICKS_TOKEN}"
    }
    data = {
        "cluster_id": cluster_id
    }

    response = requests.post(DATABRICKS_HOST + endpoint, headers=headers, json=data)
    return response.json()

# Main function to delete all terminated clusters starting with "API_"
def delete_terminated_clusters():
    terminated_clusters = get_terminated_clusters()
    
    if not terminated_clusters:
        print("No terminated clusters starting with 'API_' found.")
        return
    
    for cluster in terminated_clusters:
        cluster_id = cluster["cluster_id"]
        print(f"Deleting cluster with ID: {cluster_id}")
        result = delete_cluster(cluster_id)
        print(result)

if __name__ == "__main__":
    delete_terminated_clusters()

# COMMAND ----------

# # Function to remove the cluster from the workspace UI

# def remove_cluster_from_workspace_ui(cluster_id):
#     endpoint = f"/api/2.0/workspace/delete"
#     headers = {
#         "Authorization": f"Bearer {DATABRICKS_TOKEN}"
#     }
#     data = {
#         "path": f"/Clusters/{cluster_id}"
#     }

#     response = requests.post(DATABRICKS_HOST + endpoint, headers=headers, json=data)
#     return response.json()

# cluster_id = "0928-150015-anxrzc5p"
# remove_cluster_from_workspace_ui(cluster_id)
