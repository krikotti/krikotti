# Databricks notebook source


# COMMAND ----------

import boto3

# Get the AWS account ID
aws_acct_id = boto3.client('sts').get_caller_identity().get('Account')

# COMMAND ----------

# df = spark.read.option("compression", "gzip").option("header", "true").csv("s3a://tpc-aws-ted-tst-edpp-gobu-eu-central-1/veeva_global_kol/inputs/20240321/Address_20240321.csv.zip")

# COMMAND ----------



# COMMAND ----------


# Read the mount names and corresponding S3 bucket names for each environment
mount_names_and_buckets_by_environment = {
    "dev": [
        {"mount_name": "obu_veeva_global_kol", "bucket_name": "s3a://tpc-aws-ted-dev-edpp-gobu-eu-central-1/veeva_global_kol/"}
    ],
    "tst": [
        {"mount_name": "obu_veeva_global_kol", "bucket_name": "s3a://tpc-aws-ted-tst-edpp-gobu-eu-central-1/veeva_global_kol/"}
    ],
    "prod": [
        {"mount_name": "obu_veeva_global_kol", "bucket_name": "s3a://tpc-aws-ted-prd-edpp-gobu-eu-central-1/veeva_global_kol/"}       
    ],
    # Add more environments as needed
}

# Determine the environment based on the AWS account ID
if aws_acct_id == "103291568368":
    environment = "dev"
elif aws_acct_id == "671616840389":
    environment = "tst"
elif aws_acct_id == "824757673730":
    environment = "prod"
else:
    raise ValueError("AWS account ID does not match any known environments")


# Check if mount names already exist in the specified environment
existing_mounts = dbutils.fs.mounts()
existing_mount_names = [mount.mountPoint.split('/')[-1] for mount in existing_mounts]

for mount_info in mount_names_and_buckets_by_environment[environment]:
    mount_name = mount_info["mount_name"]
    bucket_name = mount_info["bucket_name"]
    if mount_name in existing_mount_names:
        #raise Exception(f"Mount name '{mount_name}' already exists in the specified environment. Aborting.")
        print(f"Mount name '{mount_name}' already exists in the specified environment. Skipping.")
        continue  # Skip this mount and continue with the next one

    # Mount the S3 bucket
    dbutils.fs.mount(source=bucket_name, mount_point=f"/mnt/{mount_name}")

    print(f"Successfully mounted '{bucket_name}' as '{mount_name}'.")