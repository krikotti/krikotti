# Databricks notebook source
# MAGIC %md ## Overview
# MAGIC This notebook acts as an ACL backup for existing workspaces.

# COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.text("destinationPath", "")

# COMMAND ----------

# from decimal import Decimal
# from pyspark.sql.functions import *
# from functools import reduce
# from pyspark.sql import DataFrame

# destinationPath = dbutils.widgets.get("destinationPath")
# aclBackupPath = destinationPath + "/aclBackup"

# dbrStringList = spark.conf.get("spark.databricks.clusterUsageTags.sparkVersion").split(".")
# dbr = Decimal(dbrStringList[0] + "." + dbrStringList[1])
# dbs = spark.sql("show databases")
# aclList = []

# for db in dbs.collect():
#   databaseName = ""
#   if dbr < 7:
#     databaseName = db.databaseName
#   else:
#     databaseName = db.databaseName
#   # append the database df to the list
#   aclList.append(spark.sql("SHOW GRANT ON DATABASE {}".format(databaseName))
#                  .withColumn("ObjectKey", when(col("ObjectType") == "CATALOG$", lit(databaseName)).otherwise(col("ObjectKey")))
#                  .withColumn("GrantLevel", concat(col("ObjectType"), lit(" LEVEL")))
#                  .withColumn("ObjectType", when(col("ObjectType") == "CATALOG$", "DATABASE").otherwise(col("ObjectType")))
#                 )
#   tables = spark.sql("show tables in {}".format(databaseName)).filter(col("isTemporary") == False)
#   for table in tables.collect():
# #     print("DEBUG: " + str(table.database) + " - " + str(table.tableName))

#     # append the table df to the list
#     aclList.append(spark.sql("show grant on table {}.{}".format(table.database, table.tableName))
#                    .withColumn("ObjectKey", when(col("ObjectType").isin("CATALOG$", "DATABASE"), lit("`" + table.database + "`.`" + table.tableName + "`")).otherwise(col("ObjectKey")))
#                    .withColumn("GrantLevel", concat(col("ObjectType"), lit(" LEVEL")))
#                    .withColumn("ObjectType", when(col("ObjectType").isin("CATALOG$", "DATABASE"), "TABLE").otherwise(col("ObjectType")))
#                   )
# # combine the dataframes together and write it out
# acls = reduce(DataFrame.unionByName, aclList)
# acls.coalesce(1).write.format("delta").mode("overwrite").save(aclBackupPath)

# display(acls)

# COMMAND ----------

# from decimal import Decimal
# from pyspark.sql.functions import *
# from functools import reduce
# from pyspark.sql import DataFrame

# destinationPath = dbutils.widgets.get("destinationPath")
# print("destinationPath",destinationPath)
# aclBackupPath = destinationPath + "/aclBackup"

# print("aclBackupPath",aclBackupPath)

# dbrStringList = spark.conf.get("spark.databricks.clusterUsageTags.sparkVersion").split(".")
# dbr = Decimal(dbrStringList[0] + "." + dbrStringList[1])
# dbs = spark.sql("show databases")
# aclList = []

# for db in dbs.collect():
#   databaseName = ""
#   if dbr < 7:
#     databaseName = db.databaseName
#   else:
#     databaseName = db.databaseName
#   # append the database df to the list
#   aclList.append(spark.sql("SHOW GRANT ON DATABASE {}".format(databaseName))
#                  .withColumn("ObjectKey", when(col("ObjectType") == "CATALOG$", lit(databaseName)).otherwise(col("ObjectKey")))
#                  .withColumn("GrantLevel", concat(col("ObjectType"), lit(" LEVEL")))
#                  .withColumn("ObjectType", when(col("ObjectType") == "CATALOG$", "DATABASE").otherwise(col("ObjectType")))
#                 )
#   tables = spark.sql("show tables in {}".format(databaseName)).filter(col("isTemporary") == False)
#   for table in tables.collect():
#       database = table.database
#       tableName = table.tableName
      
#       # Check if the table has a valid StorageDescriptor#InputFormat
#       hasValidInputFormat = spark.catalog.tableExists(f"{database}.{tableName}")
      
#       if hasValidInputFormat:
#           # Append the table df to the list
#           aclList.append(spark.sql(f"show grant on table `{database}`.`{tableName}`")
#                         .withColumn("ObjectKey", when(col("ObjectType").isin("CATALOG$", "DATABASE"), lit(f"`{database}`.`{tableName}`")).otherwise(col("ObjectKey")))
#                         .withColumn("GrantLevel", concat(col("ObjectType"), lit(" LEVEL")))
#                         .withColumn("ObjectType", when(col("ObjectType").isin("CATALOG$", "DATABASE"), "TABLE").otherwise(col("ObjectType")))
#                         )
#       else:
#           print(f"Skipping table {database}.{tableName} as it doesn't have a valid StorageDescriptor#InputFormat.")
# # combine the dataframes together and write it out
# acls = reduce(DataFrame.unionByName, aclList)
# acls.coalesce(1).write.format("delta").mode("overwrite").save(aclBackupPath)

# display(acls)

# COMMAND ----------

# MAGIC %sql
# MAGIC create table com_de_lake.sample_table (ID integer, EMP_NAME string)

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table com_de_lake.sample_table

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace  table com_de_lake.sample_table (ID integer, EMP_NAME string)

# COMMAND ----------

cluster_cache_memory = spark.conf.get("spark.databricks.memory.clusterCache.size")
print("Cluster Cache Memory:", cluster_cache_memory)

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %sql 
# MAGIC CLEAR CACHE;

# COMMAND ----------

from decimal import Decimal
from pyspark.sql.functions import *
from functools import reduce
from pyspark.sql import DataFrame

destinationPath = dbutils.widgets.get("destinationPath")
print("destinationPath",destinationPath)
aclBackupPath = destinationPath + "/aclBackup"

print("aclBackupPath",aclBackupPath)

dbrStringList = spark.conf.get("spark.databricks.clusterUsageTags.sparkVersion").split(".")
dbr = Decimal(dbrStringList[0] + "." + dbrStringList[1])
#dbs = spark.sql("show databases")
aclList = []
dbs = ["corp_de_raw","corp_de_lake","corp_de_mart","corp_de_hub"]
for db in dbs:  #.collect():
  databaseName = ""
  if dbr < 7:
    databaseName = db#.databaseName
  else:
    databaseName = db#.databaseName
  # append the database df to the list
  aclList.append(
      spark.sql(f"SHOW GRANT ON DATABASE `{databaseName}`")
      .withColumn("ObjectKey", 
                  when(col("ObjectType") == "CATALOG$", lit(databaseName))
                  .otherwise(col("ObjectKey")))
      .withColumn("GrantLevel", 
                  concat(col("ObjectType"), lit(" LEVEL")))
      .withColumn("ObjectType", 
                  when(col("ObjectType") == "CATALOG$", "DATABASE")
                  .otherwise(col("ObjectType")))
  )
  
  tables = spark.sql(f"show tables in `{databaseName}`").filter(col("isTemporary") == False)
  for table in tables.collect():
      database = table.database
      tableName = table.tableName
      
      # Check if the table has a valid StorageDescriptor#InputFormat
      hasValidInputFormat = spark.sql(f"SHOW TABLE EXTENDED IN `{database}` LIKE '{tableName}'").count() > 0
      
      if hasValidInputFormat:
          # Append the table df to the list
          aclList.append(
              spark.sql(f"SHOW GRANT ON TABLE `{database}`.`{tableName}`")
              .withColumn("ObjectKey", 
                          when(col("ObjectType").isin("CATALOG$", "DATABASE"), 
                               lit(f"`{database}`.`{tableName}`"))
                          .otherwise(col("ObjectKey")))
              .withColumn("GrantLevel", 
                          concat(col("ObjectType"), lit(" LEVEL")))
              .withColumn("ObjectType", 
                          when(col("ObjectType").isin("CATALOG$", "DATABASE"), 
                               "TABLE")
                          .otherwise(col("ObjectType")))
          )
      else:
          print(f"Skipping table {database}.{tableName} as it doesn't have a valid StorageDescriptor#InputFormat.")
          
# combine the dataframes together and write it out
acls = reduce(DataFrame.unionByName, aclList)
acls.coalesce(1).write.format("delta").mode("overwrite").save(aclBackupPath)

display(acls)

# COMMAND ----------

# from decimal import Decimal
# from pyspark.sql.functions import *
# from functools import reduce
# from pyspark.sql import DataFrame

# destinationPath = dbutils.widgets.get("destinationPath")
# print("destinationPath",destinationPath)
# aclBackupPath = destinationPath + "/aclBackup"

# print("aclBackupPath",aclBackupPath)

# dbrStringList = spark.conf.get("spark.databricks.clusterUsageTags.sparkVersion").split(".")
# dbr = Decimal(dbrStringList[0] + "." + dbrStringList[1])
# #dbs = spark.sql("show databases")
# aclList = []
# dbs = ["corp_de_raw","corp_de_lake","corp_de_mart","corp_de_hub"]
# for databaseName in dbs:
#   aclList.append(
#       spark.sql(f"SHOW GRANT ON DATABASE `{databaseName}`")
#       .withColumn("ObjectKey", 
#                   when(col("ObjectType") == "CATALOG$", lit(databaseName))
#                   .otherwise(col("ObjectKey")))
#       .withColumn("GrantLevel", 
#                   concat(col("ObjectType"), lit(" LEVEL")))
#       .withColumn("ObjectType", 
#                   when(col("ObjectType") == "CATALOG$", "DATABASE")
#                   .otherwise(col("ObjectType")))
#   )
  
#   tables = spark.sql(f"show tables in `{databaseName}`").filter(col("isTemporary") == False)
#   for table in tables.collect():
#       tableName = table.tableName
      
#       # Check if the table has a valid StorageDescriptor#InputFormat
#       hasValidInputFormat = spark.sql(f"SHOW TABLE EXTENDED IN `{databaseName}` LIKE '{tableName}'").count() > 0
      
#       if hasValidInputFormat:
#           # Append the table df to the list
#           aclList.append(
#               spark.sql(f"SHOW GRANT ON TABLE `{databaseName}`.`{tableName}`")
#               .withColumn("ObjectKey", 
#                           when(col("ObjectType").isin("CATALOG$", "DATABASE"), 
#                                lit(f"`{databaseName}`.`{tableName}`"))
#                           .otherwise(col("ObjectKey")))
#               .withColumn("GrantLevel", 
#                           concat(col("ObjectType"), lit(" LEVEL")))
#               .withColumn("ObjectType", 
#                           when(col("ObjectType").isin("CATALOG$", "DATABASE"), 
#                                "TABLE")
#                           .otherwise(col("ObjectType")))
#           )
#       else:
#           print(f"Skipping table {databaseName}.{tableName} as it doesn't have a valid StorageDescriptor#InputFormat.")
          
# # combine the dataframes together and write it out
# acls = reduce(DataFrame.unionByName, aclList)
# acls.coalesce(1).write.format("delta").mode("overwrite").save(aclBackupPath)

# display(acls)

# COMMAND ----------

for acl in acls.collect():
  aclBuilder = "GRANT {} ON {} {} TO `{}`".format(acl.ActionType, acl.ObjectType, acl.ObjectKey, acl.Principal)
  print(aclBuilder)