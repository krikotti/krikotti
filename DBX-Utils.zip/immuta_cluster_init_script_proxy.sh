#!/bin/bash
set -e

# This script acts as a proxy to the actual init script which is downloaded from the URI specified in
# 'IMMUTA_INIT_SCRIPT_URI'. We do this because when using Simplified Databricks configuration from the Immuta
# web service the init script that is pushed resides in Databricks storage and is not updated if Immuta undergoes
# an upgrade. This leads to version mismatches and prevents clusters from starting.
#
# With this script used as the init script a cluster will always be using the latest init script pulled
# from the built Immuta artifacts at cluster startup time. If Immuta is upgraded we only require the cluster to be
# restarted so that the newer init script is used.

echo "Downloading Immuta init script from ${IMMUTA_INIT_SCRIPT_URI}"
script=$(curl --location --insecure --silent --show-error -u "immuta_init:${IMMUTA_SYSTEM_API_KEY}" "${IMMUTA_INIT_SCRIPT_URI}")
source <(echo "$script") || echo "Error in downloaded init script!\n$script"