# Databricks notebook source
# Helper functions for working with both Spark and Pandas
# DataFrames (a sometimes necessary evil)

import pyspark.sql.functions as F
import numpy as np
import pandas as pd

from pyspark.sql.types import (StructType, StructField, StringType, DoubleType,
                               LongType, IntegerType, DateType, TimestampType)


# SPARK TO PANDAS
def get_target_pandas_dtype(dtype):
    conversions = {
        "string": "object",
        "double": "float64",
        "decimal(10,2)": "float64",
        "int": "int32",
        "smallint": "int32",
        "bigint": "int64",
        "date": "datetime64[ns]",
        "timestamp": "datetime64[ns]",
        "boolean": "bool"
    }
    if dtype in conversions.keys():
        return conversions[dtype]
    else:
        return dtype


def convert_spark_to_pandas(df):
    # Convert certain columns back to original types
    spark_dtypes = [dtype for _, dtype in df.dtypes]
    target_pandas_dtypes = [get_target_pandas_dtype(
        dtype) for dtype in spark_dtypes]

    # Convert to Pandas
    df_p = df.toPandas()

    # Fix types
    df_p = fix_spark_to_pandas_dtypes(df_p, spark_dtypes, target_pandas_dtypes)

    return df_p


def fix_spark_to_pandas_dtypes(df, spark_dtypes, target_pandas_dtypes):
    # Ensure that converted dtypes match spark dtypes
    types = zip(spark_dtypes, target_pandas_dtypes)
    for ii, (spark_dtype, target_pandas_dtype) in enumerate(types):
        actual_pandas_dtype = df.dtypes[ii].name
        if actual_pandas_dtype == target_pandas_dtype:
            continue
        elif target_pandas_dtype == "datetime64[ns]":
            df.iloc[:, ii] = pd.to_datetime(df.iloc[:, ii])
            assert df.dtypes[ii].name == target_pandas_dtype
        elif target_pandas_dtype[:3] == "int" and \
                actual_pandas_dtype[:3] == "int":
            continue
        elif target_pandas_dtype[:3] == "int" and \
                actual_pandas_dtype[:5] == "float":
            continue
        elif (target_pandas_dtype[:7] == "decimal" or
              target_pandas_dtype[:5] == "float") and \
                actual_pandas_dtype[:5] == "float":
            continue
        elif (target_pandas_dtype[:7] == "decimal" and
              actual_pandas_dtype == "object") or \
                (target_pandas_dtype[:5] == "float" and
                 actual_pandas_dtype == "object"):
            df.iloc[:, ii] = df.iloc[:, ii].astype(np.float64)
            assert df.dtypes[ii].name[:5] == "float"
        elif (target_pandas_dtype == "bool" and actual_pandas_dtype == "object"):
            df.iloc[:, ii] = df.iloc[:, ii].astype("bool")
        else:
            raise Exception(
                (f"Actual type: {actual_pandas_dtype}  --- Target type:"
                 f"{target_pandas_dtype}"))

    return df


# PANDAS TO SPARK
def get_target_spark_dtype(dtype):
    conversions = {
        "object": StringType(),
        "float64": DoubleType(),
        "float32": DoubleType(),
        "int64": LongType(),
        "int32": IntegerType(),
        "datetime64[ns]": TimestampType(),
    }
    if dtype.name in conversions.keys():
        return conversions[dtype.name]
    else:
        raise Exception(
            f"Pandas Dtype {dtype.name} not mapped to a Spark DataType")


def convert_nans_to_none(df):
    for col, dtype in df.dtypes:
        if dtype == 'double':
            df = df.withColumn(
                col,
                F.when(F.isnan(col), F.lit(None)).otherwise(F.col(col))
            )

    return df


def convert_pandas_to_spark(spark, df):
    # Create spark structtype
    columns = list(df.columns)
    dtypes = list(df.dtypes)
    struct_list = []
    datetimes_to_convert_to_dates = []
    for column, dtype in zip(columns, dtypes):
        spark_dtype = get_target_spark_dtype(dtype)
        if spark_dtype == TimestampType() and (df[column].dt.normalize() != df[column]).sum() == 0:
            spark_dtype = DateType()
        struct_field = StructField(column, spark_dtype)
        struct_list.append(struct_field)

    schema = StructType(struct_list)

    # Convert to spark
    df_s = spark.createDataFrame(df, schema, verifySchema=True)
    
    # If datetimes are all 00:00:00 for times, convert to Date


    # Convert nans to None to be consistent
    df_s = convert_nans_to_none(df_s)

    return df_s

