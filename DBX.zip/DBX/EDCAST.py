# Databricks notebook source
import logging
import boto3
from botocore.exceptions import ClientError
from io import BytesIO, StringIO
import traceback
import numpy
from google.cloud import bigquery
import os
import pandas as pd
from datetime import datetime, timedelta
from pyspark.sql.functions import *
from pytz import timezone
import concurrent.futures
from google.oauth2.service_account import Credentials
import json
import time

# COMMAND ----------

file_name = dbutils.widgets.get("file")
log_file_path = dbutils.widgets.get("log_file_path")
current_timestamp = datetime.now()
# adding timestamp to the filename
s3_file_name = "{}_{}.csv".format(file_name,current_timestamp.strftime('%Y%m%d%H%M%S'))
log_file_name = "log_file_{}_{}.log".format(file_name,current_timestamp.strftime('%Y%m%d%H%M%S'))
# env = 'dev'
# env = 'tst'
env='prd'
bucket='tpc-aws-ted-{}-edpp-raw-corp-us-east-1'.format(env)
config_file_path = "s3://tpc-aws-ted-{}-edpp-raw-corp-us-east-1/LMS/EdCast/config/Config_Edcast.json".format(env)
dimension_tables = ''


# COMMAND ----------

#Logger
try:
  # create the final log path
  finalpath = log_file_path + log_file_name
  # create a file buffer
  log_stringio = StringIO()
  # set the log levels
  logging.getLogger("py4j").setLevel(logging.ERROR)
  logging.getLogger('pyspark').setLevel(logging.DEBUG)
  logger = logging.getLogger('pyspark')
  logger.setLevel(logging.DEBUG)
  # create a stream handler object
  StreamHandler = logging.StreamHandler(log_stringio)
  StreamHandler.setLevel(logging.DEBUG)
  # format the log 
  formatter = logging.Formatter("%(asctime)s - %(threadName)s - %(name)s - %(levelname)s: %(message)s",datefmt ='%m/%d/%Y %I:%M:%S %p')
  StreamHandler.setFormatter(formatter)
  logger.addHandler(StreamHandler)
  
  logger.info("logging configuration done!")
except Exception as CreateLogFile_Error:
  raise CreateLogFile_Error

# COMMAND ----------

# MAGIC %run /TIDAL_UTILS/tidal_util

# COMMAND ----------

# function to write the formatted data to target path in S3 -
#  :param df: formatted dataframe (contains formatted data)
#  :param bucket_name: bucket to upload to
#  :param target_path:  path inside bucket where formatted file needs to be uploaded

def write_to_S3(csv_buffer, bucket_name, target_path):
  try:
    response = s3_resource.Object(bucket_name, target_path).put(Body=csv_buffer.getvalue())
    status = response.get("ResponseMetadata").get("HTTPStatusCode")
  except ClientError as e:
    logger.error(traceback.format_exc())
    return False
  
# if request is successful then return the response
  if status == 200:
    return response
  return False

# COMMAND ----------

try:
  s3_resource = boto3.resource('s3')
  s3_client = s3_resource.meta.client
  logger.info('S3 connection successfull')
except ClientError as e:
  logger.error(traceback.format_exc())
  raise e

# COMMAND ----------

def setup_gcp_connection(CONF_FILE):
    try:
        # CONF_FILE = '/dbfs/FileStore/LMS/eddata_300096.json'
        # Parametarized the cred file path and moved to S3 Location 3/26
        df = spark.read.format("json").option("multiLine", True).option("mode", "PERMISSIVE").load(CONF_FILE)
        # os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = CONF_FILE
        config_dict = df.limit(1).collect()[0].asDict()
        credentials = Credentials.from_service_account_info(config_dict)
        client = bigquery.Client(credentials=credentials)
        return client
    except Exception as e:
        logger.error(traceback.format_exc())
        raise e

# COMMAND ----------

def get_last_fetch_date(table_schema,table_name,last_fetch_date):
    try:
        # Parametarized the historical load date and moved to config file 3/26
        original_last_fetch_date = last_fetch_date
        last_fetch_date = spark.sql("select max(day) as last_fetch_date from {}.{}".format(table_schema,table_name)).collect()[0][0]
        current_date = str(current_timestamp).split(' ')[0]
        # Modified the code to identify based on dimension or fact table 3/26
        if last_fetch_date is None and file_name in dimension_tables:
            return None
        if last_fetch_date is None  and file_name not in dimension_tables:
            return original_last_fetch_date
        if(last_fetch_date > current_date ):
            last_fetch_date = str(current_timestamp-timedelta(days=1)).split(' ')[0]
        print(last_fetch_date)    
        return last_fetch_date
        
    except Exception as e:
        logger.error(traceback.format_exc())
        raise e


# COMMAND ----------

def fetch_data(upper_bound,lower_bound):
    try:
        # Modified the code to identify based on dimension or fact table 3/26
        query = ''
        if last_fetch_date is None :
            query = "with all_records as (select {},row_number() over(order by day) as rn from {}.{} ) select * except(rn) from all_records where rn>={} and rn<{}"
            print(query.format("[col_names]",gcp_schema,file_name,lower_bound,upper_bound))
            results = gcp_client.query(query.format(col_names,gcp_schema,file_name,lower_bound,upper_bound)).to_dataframe().fillna('').astype(str)
            return results
        else:
            query = "with all_records as (select {},row_number() over(order by day) as rn from {}.{} where day > '{}' ) select * except(rn) from all_records where rn>={} and rn<{}"
            print(query.format("[col_names]",gcp_schema,file_name,last_fetch_date,lower_bound,upper_bound))
            results = gcp_client.query(query.format(col_names,gcp_schema,file_name,last_fetch_date,lower_bound,upper_bound)).to_dataframe().fillna('').astype(str)
            return results
        
    except Exception as e:
        logger.error(traceback.format_exc())
        raise e

# COMMAND ----------

def get_data_from_gcp(gcp_client,gcp_schema,file_name,col_names,last_fetch_date):
    try:
        count_query=''
        # Modified the code to identify based on dimension or fact table 3/26
        if last_fetch_date is None:
            count_query = "select count(*) from {}.{}".format(gcp_schema,file_name)
        else:
            count_query = "select count(*) from {}.{} where day > '{}'".format(gcp_schema,file_name,last_fetch_date)
        record_count = spark.createDataFrame(gcp_client.query(count_query).to_dataframe()).collect()[0][0]
        lower_bound = []
        upper_bound = []
        for rows in range(1,record_count+1,50000):
            lower_bound.append(rows)
            if rows+50000 <= record_count:
                upper_bound.append(rows+50000)
            else:
                upper_bound.append(record_count+1)
        pandas_df = None
        print(record_count)
        dataframe_lst=[]
        if record_count > 0:
            with concurrent.futures.ThreadPoolExecutor() as executor:
                dataframe_lst = list(executor.map(fetch_data,upper_bound,lower_bound))
            pandas_df = pd.concat(dataframe_lst, ignore_index=True)
        else:
            logger.info("No Record found")
        return pandas_df,record_count
    except Exception as e:
        logger.error(traceback.format_exc())
        raise e


# COMMAND ----------

def sns_notification(email_subject, email_message, sns_notification_region, sns_topic_arn):
#To initiate email notification of script fails

    try:
        sns_client = boto3.client('sns', region_name = sns_notification_region)       
        sns_client.publish(
        TopicArn = sns_topic_arn,
        MessageStructure = 'string',
        Message = email_message,
        Subject = email_subject
        )
        print("Email notification sent.")
        
    except Exception as sns_error:
        print('Error occured in sending Email notification. Detail Exception: '+str(sns_error))
        raise sns_error

# COMMAND ----------

# getting config file from S3 and assigning values to the variable 
import configparser
from io import StringIO

try:
  # get config file Path from the job parameters

  config_path = 's3://tpc-aws-ted-{}-edpp-raw-corp-us-east-1/LMS/EdCast/config/config.ini'.format(env)
  
  # read the config file
  res = sc.textFile(config_path).collect()

 # created a buffer object and passed the file content to it
  buf = StringIO("\n".join(res))
  # create an object of configparser
  config = configparser.ConfigParser()
  # read the config file using config object
  config.readfp(buf)

  CALLBACK_JOB_ID = config.get('Edcast','callback_id_'+file_name)
  sns_notification_region = config.get('Edcast','sns_notification_region')
  sns_topic_arn = config.get('Edcast','sns_topic_arn')
  last_fetch_date = config.get('Edcast','historical_load_date')
  # Cred File and dimension table list is being fetched from config file 3/26
  CONF_FILE = config.get('Edcast','CONF_FILE')
  dimension_tables = config.get('Edcast','dimension_tables')
  
  logger.info('variables loaded from the config file!')

except Exception as e:
  logger.error(traceback.format_exc())
  write_to_S3(log_stringio, bucket, finalpath)
  raise e


# COMMAND ----------

try:
    gcp_client = setup_gcp_connection(CONF_FILE)
    logger.info('GCP connection successfull')
    config_df = spark.read.option("multiline", "true").json(config_file_path).where(col("file_name")==file_name)
    logger.info('Config File read successfull')
    if config_df.head():
        config_df = config_df.collect()
    else:
        raise Exception("Table Name : {} Not Found in Config File".format(file_name))
    lake_table_schema = config_df[0]["lake_table_schema"] #read from config_df
    lake_table_name = config_df[0]["lake_table_name"] #read from config_df
    destination = config_df[0]["destination"] #read from config_df
    gcp_schema = config_df[0]["gcp_schema"] #read from config
    col_names = ",".join(config_df[0]["col_names"]) #read from config
    last_fetch_date = get_last_fetch_date(lake_table_schema,lake_table_name,last_fetch_date)
    logger.info('Last Fetch Date : {}'.format(last_fetch_date))
    print(last_fetch_date)
    logger.info('Data Fetch Started')
    output_df,record_count = get_data_from_gcp(gcp_client,gcp_schema,file_name,col_names,last_fetch_date)
    if(record_count>0):
        output_df = spark.createDataFrame(output_df).replace('NaT','').toPandas().astype(str)
        output_df = output_df.replace('\n','',regex=True)
    # output_df=spark.createDataFrame(output_df).replace('NaT','')
        logger.info('Data Fetch Successful')
    #Final_path = "s3://{}/{}edcast_{}/{}".format(bucket,destination,file_name,s3_file_name)
    Final_path = "{}edcast_{}/{}".format(destination,file_name,s3_file_name)
    s3_path = 's3://'+bucket+'/'+Final_path
    print(s3_path)
    if output_df is not None:
        output_csv_buffer = StringIO()
        output_df.to_csv(s3_path,index=False,escapechar="\\",doublequote=False)
        # output_df.write.option("header", "true").csv(s3_path)
except Exception as e:
    logger.error(traceback.format_exc())
    raise e


# COMMAND ----------

try:
    email_subject = 'Edcast Run Status : {0} : {1} '.format(file_name,env)
    email_message = '{0} Run Status : Successful on {1}'.format(file_name, str(current_timestamp).split(' ')[0])
    sns_notification(email_subject, email_message, sns_notification_region, sns_topic_arn)
except Exception as e:
    logger.error(traceback.format_exc())
    raise e    
finally:
    write_to_S3(log_stringio, bucket, finalpath)
    tidal_callback_jobid=vars()['CALLBACK_JOB_ID']
    tidal_job_callback(tidal_callback_jobid)
    
