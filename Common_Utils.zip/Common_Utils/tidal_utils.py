# Databricks notebook source
# Getting EST time to pass to Tidal 
from pytz import timezone
import datetime
from datetime import datetime as dt
def get_job_date():
  est = timezone('US/Eastern')
  date_curr = dt.now(est)  #.strftime("%H%M%S")
  secs = int(date_curr.strftime("%S"))
  
  if secs < 5:
    add_secs = 60 
  else:
    add_secs = 105
  
  scheduled_time = date_curr + datetime.timedelta(0,add_secs)
  scheduled_time_str = scheduled_time.strftime("%H%M")
  date_tidal = scheduled_time.strftime("%Y%m%d")
  return date_tidal, scheduled_time_str

# COMMAND ----------

# DBTITLE 1,Get Job and Run ID
import json
#Getting current job run id to pass to Tidal 
def get_job_run_id():
  job_json_str = dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson()
  job_json = json.loads(job_json_str)
  run_id_obj = job_json.get('currentRunId', {})
  run_id = run_id_obj.get('id', None) if run_id_obj else None
  job_id = job_json.get('tags', {}).get('jobId', None)
  return run_id

# COMMAND ----------

# DBTITLE 1,For Tidal Credentials
import boto3
from botocore.exceptions import ClientError

def get_tidal_credentials():

    secret_name = "obu-us-prd-tidal-cred"
    region_name = "us-east-1"

    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name,
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'ResourceNotFoundException':
            print("The requested secret " + secret_name + " was not found")
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            print("The request was invalid due to:", e)
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            print("The request had invalid params:", e)
        else:
          raise
    else:
        # Secrets Manager decrypts the secret value using the associated KMS CMK
        # Depending on whether the secret was a string or binary, only one of these fields will be populated
        print(get_secret_value_response)
        if 'SecretString' in get_secret_value_response:
            text_secret_data = get_secret_value_response['SecretString']
        else:
            binary_secret_data = get_secret_value_response['SecretString']
            
        return text_secret_data

# COMMAND ----------

# DBTITLE 1,Tidal Callback
import requests
import base64 
#API call to Tidal
#TODO: Get uid/pwd from secret manager
import time

def tidal_job_callback(tidal_job_id):
  DOMAIN_TIDAL = 'http://usvgatagcmp001.onetakeda.com:8080/api/tesUSProd/postbody'
  CREDENTIALS_TIDAL = json.loads(get_tidal_credentials())["tidal_credentials"]
  CREDENTIALS_TIDAL = bytes(CREDENTIALS_TIDAL,'ascii')
  
  userAndPass = base64.b64encode(CREDENTIALS_TIDAL).decode("ascii")
  header_xml = { 'Content-Type' : 'text/xml', 'Authorization' : 'Basic %s' % userAndPass }
  job_date, job_time = get_job_date()
  dbjob_run_id = get_job_run_id()
  print("DB job run id : " + str(dbjob_run_id) + "  Tidal_jobid = " + str(tidal_job_id))
  req_xml= '<?xml version="1.0" encoding="UTF-8" ?> <entry xmlns="http://purl.org/atom/ns#">     <tes:JobGroup.insert xmlns:tes="http://www.tidalsoftware.com/client/tesservlet">         <id>'+str(tidal_job_id)+'</id>         <startdate>'+str(job_date)+'</startdate>        <fromtime>'+job_time+'</fromtime>        <untiltime></untiltime>        <params></params>        <vars>RUN-ID='+str(dbjob_run_id)+'</vars>        <deps>N</deps>        <usejobtz></usejobtz>     </tes:JobGroup.insert></entry>'
  print(req_xml)
  response = requests.post(DOMAIN_TIDAL, data=req_xml, headers=header_xml).text
  print(response)

# COMMAND ----------

# tidal_job_callback('45211')

# COMMAND ----------

# tidal_job_callback('45211')