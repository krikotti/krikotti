# Databricks notebook source
# MAGIC %md
# MAGIC ###Author: Krishna Reddy Kotti
# MAGIC Only for Databricks Admins to use

# COMMAND ----------

# MAGIC %md
# MAGIC ### API Cluster Cleanup
# MAGIC This notebook looks at all the running "API_" clusters and cleans up any cluster that has been running for longer than specified number of hours.

# COMMAND ----------

dbutils.widgets.text(name="started_since_hrs",defaultValue="24",label="Hours_since_start")
dbutils.widgets.text(name="activity_since_hrs",defaultValue="24",label="Hours_since_last_activity")
dbutils.widgets.text(name="cluster_name_pattern",defaultValue="API_",label="Cluster name to search")


# COMMAND ----------

started_greaterthan_hrs = int(dbutils.widgets.get('started_since_hrs'))
idle_greaterthan_hrs = int(dbutils.widgets.get('started_since_hrs'))
cluster_name_tosearch = dbutils.widgets.get("cluster_name_pattern")

# COMMAND ----------

##Get the token and the host name of the workspace from the notebook context variables.

token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
host_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().tags().get("browserHostName").get()

# COMMAND ----------

import requests
bearer_token= f"Bearer {token}"
headers ={"Authorization":bearer_token}
endpoint="https://"+host_name+"/api/2.0/clusters/list"
clusters = requests.get(endpoint,headers=headers).json()['clusters']

# COMMAND ----------

def terminate_cluster(cluster_id):
  endpoint="https://"+host_name+"/api/2.0/clusters/delete"
  data= {'cluster_id': cluster_id }
  print(f'shutting down cluster id {cluster_id}')
  requests.post(endpoint,headers=headers,json=data).json()

# COMMAND ----------

cluster_ids=[]
clusters_of_interest = [cluster for cluster in clusters if cluster_name_tosearch in cluster['default_tags']['ClusterName']]
import datetime
for cluster in clusters_of_interest:
    cluster_id=cluster['cluster_id']
    cluster_name=cluster['default_tags']['ClusterName']
    cluster_start_time = datetime.datetime.fromtimestamp(cluster['start_time']/1000)
    if 'last_activity_time' in cluster:
      last_activity_time = datetime.datetime.fromtimestamp(cluster['last_activity_time']/1000)
    current_time=datetime.datetime.now()
    time_since_start = current_time-cluster_start_time
    time_since_last_activity =  current_time-last_activity_time
    time_since_start_hrs =(time_since_start.total_seconds())/3600
    time_since_activity_hrs =(time_since_last_activity.total_seconds())/3600
    print(f"Cluster {cluster_name} with id {cluster_id} started for  {time_since_start_hrs} hrs, was last active  {time_since_activity_hrs} hrs ago")
    if time_since_start_hrs > started_greaterthan_hrs:
      print(f'Terminating cluster {cluster_name}, since it has been active for longer than {started_greaterthan_hrs}')
      terminate_cluster(cluster_id)    

# COMMAND ----------

