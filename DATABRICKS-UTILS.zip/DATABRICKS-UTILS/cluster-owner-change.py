# Databricks notebook source
# MAGIC %md Cluster Owner Change notebook 

# COMMAND ----------



# COMMAND ----------

##Get the token and the host name of the workspace from the notebook context variables.

TOKEN = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
DOMAIN = dbutils.notebook.entry_point.getDbutils().notebook().getContext().tags().get("browserHostName").get()

# COMMAND ----------

####Working Function
import requests

def cluster_owner_change(cluster_id,change_owner):
    response = requests.post(
      'https://%s/api/2.0/clusters/change-owner' % (DOMAIN),
      headers={'Authorization': 'Bearer %s' % TOKEN},
      json = {
        "cluster_id":cluster_id,
        "owner_username":change_owner
        }
    )

    if response.status_code == 200:
      print('cluster_id',cluster_id)
    else:
      print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))



# COMMAND ----------

change_owner="8c6c63c8-2213-4fd3-8cd5-c628d393aff9"

# COMMAND ----------

cluster_ids = ['0131-173241-vfioah0z','0120-015245-pf41dijf','0908-190748-5qe9pwjh',"0601-103531-nfzfkado","0121-080219-71yaurou",'1208-073125-jutq51g9','1207-125924-gyk1s950','1201-104121-f8qoigcn']

# COMMAND ----------

for cluster_id in cluster_ids: 
    cluster_owner_change(cluster_id,change_owner)

# COMMAND ----------


# %sh
# curl --netrc -X POST \
# https://onetakeda-jpdev.cloud.databricks.com/api/2.0/clusters/change-owner \
# --data @{
# "cluster_id":"0722-184813-ih999qrk",
# "owner_username":"11ed42b3-876a-4a51-9251-7d115f3e0aa7"
# } \
# | jq .


