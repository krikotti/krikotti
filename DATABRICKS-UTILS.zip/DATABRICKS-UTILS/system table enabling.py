# Databricks notebook source
# MAGIC %sh
# MAGIC curl -v -X PUT -H "Authorization: Bearer dapie55368fb3898a3387923787c38d6858d" "https://onetakeda-dedev.cloud.databricks.com/api/2.0/unity-catalog/metastores/f70b2fe1-12c7-46c1-9232-84cbc654042c/systemschemas/query"

# COMMAND ----------

# MAGIC %sh
# MAGIC curl -v -X PUT -H "Authorization: Bearer dapie55368fb3898a3387923787c38d6858d" "https://onetakeda-dedev.cloud.databricks.com/api/2.0/unity-catalog/metastores/f70b2fe1-12c7-46c1-9232-84cbc654042c/systemschemas/workflow"