# Databricks notebook source

##Get the token and the host name of the workspace from the notebook context variables.

TOKEN = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
DOMAIN = dbutils.notebook.entry_point.getDbutils().notebook().getContext().tags().get("browserHostName").get()

# COMMAND ----------


import requests
# Create empty list to store non-Delta tables
cluster_details_list = []
bearer_token= f"Bearer {TOKEN}"
headers ={"Authorization":bearer_token}
endpoint="https://"+DOMAIN+"/api/2.0/clusters/list"
clusters = requests.get(endpoint,headers=headers).json()['clusters']
cluster_name_tosearch = '7.3.x-scala2.12'
clusters_of_interest = [cluster for cluster in clusters if cluster_name_tosearch in cluster['spark_version']]
for cluster_detail in clusters_of_interest:

        
        print("Cluster",cluster_detail['default_tags']['ClusterName'], "Owner Name","DBR Runtime Version", cluster_detail['spark_version'] )
        # print("Cluster",cluster_detail['default_tags']['ClusterName'], "Owner Name",cluster_detail['custom_tags']['application-owner'],"DBR Runtime Version", cluster_detail['spark_version'] )
        # cluster_details_list.append((cluster_detail['default_tags']['ClusterName'],cluster_detail['custom_tags']['application-owner'],cluster_detail['spark_version']))


# COMMAND ----------

# Define the schema for the DataFrame
from pyspark.sql.types import StringType, StructType, StructField

schema = StructType([
    StructField("ClusterName", StringType(), True),
    StructField("ClusterOwner", StringType(), True),
    StructField("DBRRuntimeVersion", StringType(), True)
])
# Create vacuum details DataFrame
cust_details = spark.createDataFrame(cluster_details_list,schema)
display(cust_details)