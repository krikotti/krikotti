-- Databricks notebook source
show grants on `Okta-DBX-E2-COM-NSBUKlickDataShare-DataAnalyst`

-- COMMAND ----------

show databases

-- COMMAND ----------

-- MAGIC %py
-- MAGIC import time
-- MAGIC from pyspark.sql import SparkSession
-- MAGIC
-- MAGIC # Databricks group name
-- MAGIC group_name = "COM_DE_MART_TAS_TM1"
-- MAGIC #database_names = ["corp_us_hub", "com_us_hub","corp_us_mart"]
-- MAGIC start_time = time.time()
-- MAGIC database_names = spark.sql("show databases")
-- MAGIC database_names = set(row.databaseName for row in database_names.collect())
-- MAGIC time_in_seconds = (time.time() - start_time)
-- MAGIC print(f"{round(time_in_seconds,2)} seconds for database listing.")
-- MAGIC
-- MAGIC # Create SparkSession
-- MAGIC spark = SparkSession.builder \
-- MAGIC     .appName("Retrieve Database Grants") \
-- MAGIC     .getOrCreate()
-- MAGIC
-- MAGIC
-- MAGIC # Initialize an empty DataFrame
-- MAGIC final_df = None
-- MAGIC
-- MAGIC for database_name in database_names:
-- MAGIC     if not database_name.startswith("collibra_catalog"):
-- MAGIC         # Execute the SQL query
-- MAGIC         query = f"SHOW GRANT `{group_name}` ON DATABASE `{database_name}`"
-- MAGIC         result = spark.sql(query)
-- MAGIC
-- MAGIC         # Append the rows to the final DataFrame
-- MAGIC         if final_df is None:
-- MAGIC             final_df = result
-- MAGIC         else:
-- MAGIC             final_df = final_df.union(result)
-- MAGIC
-- MAGIC # Show the final DataFrame
-- MAGIC display(final_df.show(truncate=False))
-- MAGIC
-- MAGIC

-- COMMAND ----------

grant usage on database com_de_mart_tas to `COM_DE_MART_TAS_TM1`;
grant usage on database com_de_mart_tas to `COM_DE_MART_TAS_CX`;

-- COMMAND ----------

# # Initialize an empty DataFrame
# final_df = None
# #table_names = set(row.tableName for row in tables.collect())
# for database_name in database_names:
#     print(database_name)
#     # Execute the SQL query
#     query = f"SHOW GRANT `{group_name}` ON DATABASE {database_name}"
#     print(query)
#     result = spark.sql(query)

#     # Append the rows to the final DataFrame
#     if final_df is None:
#         final_df = result
#     else:
#         final_df = final_df.union(result)

# # Show the final DataFrame
# display(final_df.show(truncate=False))