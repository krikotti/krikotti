# Databricks notebook source
print("Self Service User Management")

# COMMAND ----------

