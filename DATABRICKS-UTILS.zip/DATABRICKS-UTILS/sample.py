# Databricks notebook source
##Get the token and the host name of the workspace from the notebook context variables.

token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
host_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().tags().get("browserHostName").get()

# COMMAND ----------

print("token",token,"host_name",host_name)