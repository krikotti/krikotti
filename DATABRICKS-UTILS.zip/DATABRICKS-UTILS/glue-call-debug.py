# Databricks notebook source
import boto3
import boto3
#boto3.set_stream_logger(name='botocore')

next_token = ""
client = boto3.client('glue',region_name='eu-central-1')
crawler_tables = []
i = 0
while True:
  response = client.get_tables(CatalogId = '263789222982',DatabaseName = 'com_de_hub', Expression = "customer_vw" ,NextToken = next_token)

  
  size = 0 
  for tables in response['TableList']:
    for columns in tables['StorageDescriptor']['Columns']:
        crawler_tables.append(tables['Name'] + '.' + columns['Name'])
    size = size + 1
  next_token = response.get('NextToken')
  i = i + 1
  print(f" {i}th iteration : {next_token} : {size}")
  if next_token is None:
    break
print(crawler_tables)



# COMMAND ----------

