# Databricks notebook source
# MAGIC %md
# MAGIC ### Display base table before vacuum - com_de_alyt_gem.vacuum_tables

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from com_de_alyt_gem.vacuum_tables

# COMMAND ----------

# MAGIC %md
# MAGIC #### Steps involved in performing vacuum operation
# MAGIC 1. Iterate through base table to get table list for vacuum.
# MAGIC 2. To check if the table is delta or not to avoid any errors during vacuum operation.
# MAGIC 3. Last_run_date column in base table captures the last runtime of vacuum command with respect to the table.
# MAGIC 4. Based on the frequency and rentention days, vacuum operation is executed. 
# MAGIC 5. For example, if vacuum command is performed today for table A with frequecy "2" then next time vacuum is performed after 2 days based on next_run_date column derived using last_run_date.
# MAGIC 6. After vacuum command executed, last_run_date & last_run_status column updated to today's date & run status respectively.
# MAGIC 7. Retention days are set for delta table as per days mentioned in base table during vacuum operation and unset after completion.
# MAGIC 8. Email notification sent to respective recipients with vacuum run status for every day.
# MAGIC 9. When inserting new records to base table, last_run_date should be inserted with current_date() of insertion if inserted before vacuum script run else current_date()+1

# COMMAND ----------

# MAGIC %md
# MAGIC ### Function defined to perform vacuum

# COMMAND ----------

def vacuum_frequency(schema_name, table_name, days, last_run_date):
    try:
        retention_hrs = days * 24
        spark.sql(
            f'ALTER TABLE {schema_name}.{table_name} SET TBLPROPERTIES(delta.deletedFileRetentionDuration = "interval {days} days")'
        )  ##Retention interval for table is set as per frequency mentioned in base table
        spark.sql(
            f"VACUUM {schema_name}.{table_name} RETAIN {retention_hrs} HOURS"
        )  ##vacuum command exectution
        spark.sql(
            f"update com_de_alyt_gem.vacuum_tables set last_run_date=current_date(),last_run_status='Success' where table_name='{table_name}'"
        )  ##updating last_run_date & last_run_status column to today's date and run status respectively
        print("vacuum completed for " + schema_name + "." + table_name)
        spark.sql(
            f"ALTER TABLE {schema_name}.{table_name} UNSET TBLPROPERTIES(delta.deletedFileRetentionDuration)"
        )  ##Table property unset after vacuum completion
        #globals()["success_table_list"] += str(schema_name) + '.' + str(table_name) + "<br>"        
    except Exception as error:
        print("vacuum falied for " + schema_name + "." + table_name)
        spark.sql(
            f"update com_de_alyt_gem.vacuum_tables set last_run_date=current_date(),last_run_status='Failed' where table_name='{table_name}'"
        )
        globals()["failure_table_list"] += schema_name + '.' + table_name + ' - ' + error + '<br>'

# COMMAND ----------

# MAGIC %md
# MAGIC ### Function to check table is delta or not

# COMMAND ----------

def delta_check(TableName: str) -> bool:
    try:
        is_delta_table = spark.sql(f"DESCRIBE EXTENDED {TableName}").filter("col_name = 'Provider'") \
                .select("data_type").collect()[0][0] == "delta"
        if is_delta_table:
            is_delta = "True"
        else:
            is_delta = "False"
            globals()["failure_table_list"] += TableName + ' - ' + 'Not a delta table' + '<br>'
    except Exception as error:
        print(error)
        is_delta = "False"
        globals()["failure_table_list"] += TableName + ' - ' + 'Table or view not found' + '<br>'
    return is_delta

# COMMAND ----------

# MAGIC %md
# MAGIC ### Function to send email

# COMMAND ----------

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage

SMTP_SERVER_HOST = "smtprelay-emear.onetakeda.com"
SMTP_SERVER_PORT = 25
EMAIL_SENDER ="premkumar.duraisamy@takeda.com,krishna-reddy.kotti@takeda.com"

# COMMAND ----------

def send_email(failure_table_list):
    from datetime import date
    today_date = date.today().strftime('%Y-%m-%d')
    subject = 'Vacuum run status - ' + today_date
    recipients = "premkumar.duraisamy@takeda.com,krishna-reddy.kotti@takeda.com"

    # Set up the email message
    msg = MIMEMultipart()
    msg['From'] = EMAIL_SENDER # who appears to be sending the email
    msg['To'] = recipients # who appears to be recieving the email (different from what you pass to server.sendmail())
    msg['Subject'] = subject
    msg.attach(MIMEText("Hello Team,<br><br>PFB failures occured during vacuum operation.<br><br> <b>Failures:</b> <br>{}<br><br>Regards<br>GEM I&A team".format(failure_table_list), 'html'))

    # Send the email
    with smtplib.SMTP(SMTP_SERVER_HOST, 25) as smtp:
        smtp.starttls()
        smtp.send_message(msg)
        print("successfully sent email to %s:" %(msg['To']))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Main class to invoke vacuum function

# COMMAND ----------

from datetime import datetime
dt_obj = datetime.now()
ts_am_pm = dt_obj.strftime('%p') #To get the current timestamp details - AM/PM
# To get only required table list from base table
desc_table = spark.sql(
    f"select schema_name,table_name,days,frequency,last_run_date from com_de_alyt_gem.vacuum_tables where (last_run_date=current_date() or last_run_date+cast(frequency as int)=current_date()) and slot='{ts_am_pm}'"
    ).collect()
failure_table_list=''
if desc_table:
    for i in desc_table:  # Iterate through base table to get table list for vacuum
        schema_name = i[0]
        table_name = i[1]
        days = i[2]
        last_run_date = i[4]
        res = delta_check(schema_name + '.' + table_name) # To check whether table is delta or not
        if res == "True":
            vacuum_frequency(schema_name, table_name, days, last_run_date)
else:
    print("Empty table list for vacuum")
if len(failure_table_list) != 0:
    send_email(failure_table_list)
    #To send email to recipient list with vacuum run status

# COMMAND ----------

# MAGIC %md
# MAGIC ### Today's vacuum run status

# COMMAND ----------

todays_run_details = spark.sql(
    f"select schema_name,table_name,days,frequency,last_run_date,last_run_status,slot from com_de_alyt_gem.vacuum_tables where (last_run_date=current_date() or last_run_date+cast(frequency as int)=current_date()) and slot='{ts_am_pm}'"
).collect()
if len(todays_run_details) == 0:
    print("The dataframe todays_run_details is empty.")
else:
    display(todays_run_details)
    print("The dataframe todays_run_details is not empty.")