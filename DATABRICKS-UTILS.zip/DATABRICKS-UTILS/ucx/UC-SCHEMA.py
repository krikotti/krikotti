# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE TABLE corp_de_hub.uc_catalog_table (
# MAGIC   SCHEMANAME STRING,
# MAGIC   TABLENAME STRING)
# MAGIC USING delta