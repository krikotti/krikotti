# Databricks notebook source
# MAGIC %md This notebook contains the code for identifying which Databricks objects are using init scripts on DBFS. 
# MAGIC
# MAGIC **Prerequisites**
# MAGIC
# MAGIC - You must have the **/helpers** directory present in the workspace before running this notebook.
# MAGIC - By default, this notebook runs against the current workspace.
# MAGIC - Attach this notebook to a cluster running Databricks Runtime 13.3 LTS.
# MAGIC - If you want to check additional workspaces, you will need the *workspace URL* and the *administator's PAT token* for the workspace you want to check.
# MAGIC
# MAGIC See https://kb.databricks.com/dbfs-init-script-detection-notebook for more details.

# COMMAND ----------

# MAGIC %pip install -U databricks-sdk==0.14.0

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

ws_url = "https://onetakeda-dedev.cloud.databricks.com/"
ws_pat = "dapie55368fb3898a3387923787c38d6858d"

# COMMAND ----------

dbutils.widgets.text("ws_url", "", "Workspace URL (optional)")
dbutils.widgets.text("ws_pat", "", "PAT (required if URL is provided)")

# COMMAND ----------

# MAGIC %load_ext autoreload
# MAGIC %autoreload 2

# COMMAND ----------

import html as h
import logging as log

from databricks.sdk import WorkspaceClient

from helpers import *

# COMMAND ----------

ws_url = dbutils.widgets.get("ws_url").strip()
ws_pat = dbutils.widgets.get("ws_pat").strip()
if ws_url != "":
  if ws_pat == "":
    raise Exception("PAT is required if Workspace URL is provided")
  wc = WorkspaceClient(host=ws_url, token=ws_pat)
else:
  wc = WorkspaceClient()

log_level = log.WARNING
log.basicConfig(level=log_level)

# COMMAND ----------

clusters_with_named = identify_clusters_or_jobs_with_named_scripts(wc)

# COMMAND ----------

legacy_global_init_scripts = identify_legacy_global_init_scripts(wc)

# COMMAND ----------

clusters = identify_clusters(wc)

# COMMAND ----------

jobs = identify_jobs(wc)

# COMMAND ----------

dlts = identify_dlt_pipelines(wc)

# COMMAND ----------

policies = identify_cluster_policies(wc)

# COMMAND ----------

html_table_template = """<html><head>
<style>
table, th, td {{
  border: 1px solid black;
}}

th, td {{
  padding: 10px;
}}
</style>
</head><body><table>
{}
</table></body></html>"""

# COMMAND ----------

if clusters:
  rows = [f'<tr><td>{h.escape(v["name"])}</td><td><a href="{ws_url}/#setting/clusters/{cluster_id}/edit">Edit</a></td><td>{"<br/>".join(v["scripts"])}</td></tr>' 
  for cluster_id, v in clusters.items()]
  html = html_table_template.format("<tr><th>Cluster</th><th></th><th>Init scripts</th></tr>\n"+"\n".join(rows))
  displayHTML(html)
else:
  print("No clusters with init scripts on DBFS")      

# COMMAND ----------

if clusters_with_named:
  rows = [f'<tr><td>{h.escape(cluster_name)}</td><td>{"<br/>".join(v["scripts"])}</td></tr>'
  for cluster_name, v in clusters_with_named.items()]
  html = html_table_template.format("<tr><th>Cluster or Job</th><th>Init scripts</th></tr>\n"+"\n".join(rows))
  displayHTML(html)
else:
  print("No clusters or jobs with named init scripts on DBFS")

# COMMAND ----------

if legacy_global_init_scripts:
  rows = [f'<tr><td>{h.escape(script)}</td></tr>'
          for script in legacy_global_init_scripts]
  html = html_table_template.format("<tr><th>Legacy global init scripts</th></tr>\n"+"\n".join(rows))
  displayHTML(html)
else:
  print("You aren't using legacy global init scripts")

# COMMAND ----------

if jobs:
  rows = []
  for job_id, v in jobs.items():
    job_cell = f'<td><a href="{ws_url}/#job/{job_id}/tasks">{h.escape(v["name"])}</a></td>'
    init_scripts_cell = f'<td>{"<br/>".join([h.escape(s) for s in v["scripts"].keys()])}</td>'
  
    new_clusters_tasks = []
    job_clusters_tasks = {}
    for t in v["scripts"].values():
      new_clusters_tasks = new_clusters_tasks + t["new_clusters"]
      for jb, tasks in t["job_clusters"].items():
        if jb not in job_clusters_tasks:
          job_clusters_tasks[jb] = set()
        job_clusters_tasks[jb].update(set(tasks))

    tasks_cell = f'<td>'
    if new_clusters_tasks:
      tasks_cell = tasks_cell + f'''Tasks with new clusters:<br/><ul>
    {"".join([f'<li><a href="{ws_url}/#job/{job_id}/tasks/task/{t}">{h.escape(t)}</a></li>' for t in set(new_clusters_tasks)])}
    </ul><br/>'''
    if job_clusters_tasks:
      tasks_cell = tasks_cell + f'''Tasks with job clusters:<br/><ul>
    {"".join([f'<li>Job cluster: <a href="{ws_url}/#job/{job_id}/tasks/task/{list(tasks)[0]}">{h.escape(jc)}</a>. Tasks: {", ".join(tasks)}</li>' 
      for jc, tasks in job_clusters_tasks.items()])}
    </ul><br/>'''
    tasks_cell = tasks_cell + "</td>"

    rows.append('<tr>' + job_cell + init_scripts_cell + tasks_cell + '</tr>')

  html = html_table_template.format("<tr><th>Job</th><th>Init scripts</th><th>Tasks</th></tr>\n"+"\n".join(rows))
  displayHTML(html)
else:
  print("No jobs with init scripts on DBFS")

# COMMAND ----------

if dlts:
  rows = [f'''<tr><td>{h.escape(v["name"])}</td><td><a href="{ws_url}/#joblist/pipelines/{pipeline_id}/settings">Edit</a></td><td>
        {"<br/>".join(
                [h.escape(s) + "<br/>In clusters: " + h.escape(", ".join(cls)) for s, cls in v["scripts"].items()])}
                </td></tr>'''
        for pipeline_id, v in dlts.items()]
  html = html_table_template.format("<p><b>Click on JSON tab to edit init scripts!</b></p><tr><th>DLT Pipeline</th><th></th><th>Init scripts</th></tr>\n"+"\n".join(rows))
  displayHTML(html)
else:
  print("There are no DLT pipelines with init scripts on DBFS")

# COMMAND ----------

if policies:
  rows = [f'<tr><td>{h.escape(v["name"])}</td><td><a href="{ws_url}/#setting/clusters/cluster-policies/edit/{policy_id}">Edit</a></td><td>{"<br/>".join(v["scripts"])}</td></tr>' 
        for policy_id, v in policies.items()]
  html = html_table_template.format("<tr><th>Cluster policy</th><th></th><th>Init scripts</th></tr>\n"+"\n".join(rows))
  displayHTML(html)
else:
  print("There are no cluster policies with references to init scripts on DBFS")

# COMMAND ----------

# MAGIC %md **Warning!** The next cell may display error messages about non-existent DBFS files. This means you have Databricks objects (cluster, jobs, DLT pipelines, or cluster policies) that point to non-existent files on DBFS. Remove references to those files if they are not used anymore.

# COMMAND ----------

all_init_scripts = extract_init_scripts(clusters, jobs, dlts, policies, clusters_with_named)
init_scripts_with_dbfs_reference = check_dbfs_file_references(wc, all_init_scripts)

# COMMAND ----------

if init_scripts_with_dbfs_reference:
  rows = [f'<tr><td>{h.escape(i)}</td></tr>' for i in init_scripts_with_dbfs_reference]
  html = html_table_template.format("<tr><th>Init scripts that reference files on DBFS</th></tr>\n"+"\n".join(rows))
  displayHTML(html)
else:
  print("There are no init scripts that reference files on DBFS")