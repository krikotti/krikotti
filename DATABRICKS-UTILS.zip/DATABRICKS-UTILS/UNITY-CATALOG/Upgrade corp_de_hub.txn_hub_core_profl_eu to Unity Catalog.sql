-- Databricks notebook source
-- Upgrade `hive_metastore`.`corp_de_hub`.`txn_hub_core_profl_eu` to `dbx_uc_dedev`.`corp_de_hub`.`txn_hub_core_profl_eu`
SYNC TABLE `dbx_uc_dedev`.`corp_de_hub`.`txn_hub_core_profl_eu` FROM `hive_metastore`.`corp_de_hub`.`txn_hub_core_profl_eu` SET OWNER `unity-admins`;
ALTER TABLE `hive_metastore`.`corp_de_hub`.`txn_hub_core_profl_eu` SET TBLPROPERTIES ('comment' = 'This table is deprecated. Please update to use `dbx_uc_dedev`.`corp_de_hub`.`txn_hub_core_profl_eu` instead of `hive_metastore`.`corp_de_hub`.`txn_hub_core_profl_eu`');
