-- Databricks notebook source


-- COMMAND ----------

-- create table dbx_uc_dedev.dbx_us_vacuum.clean_details_test1 as select * from spark_catalog.dbx_us_vacuum.clean_details

-- COMMAND ----------

insert overwrite dbx_uc_dedev.dbx_us_vacuum.clean_details_test1 select * from dbx_uc_dedev.dbx_us_vacuum.clean_details

-- COMMAND ----------

insert overwrite dbx_uc_dedev.dbx_us_vacuum.clean_details_test select * from spark_catalog.dbx_us_vacuum.clean_details