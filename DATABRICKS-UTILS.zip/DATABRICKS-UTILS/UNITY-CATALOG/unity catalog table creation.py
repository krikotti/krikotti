# Databricks notebook source


# COMMAND ----------

# MAGIC %sql
# MAGIC desc database dbx_us_vacuum

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into spark_catalog.dbx_us_vacuum.uc_catalog_table values ('dbx_us_vacuum','clean_details');
# MAGIC insert into spark_catalog.dbx_us_vacuum.uc_catalog_table values ('dbx_us_vacuum','clean_details_bkp');
# MAGIC insert into spark_catalog.dbx_us_vacuum.uc_catalog_table values ('dbx_us_vacuum','non_delta_tables');

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE spark_catalog.dbx_us_vacuum.uc_catalog_table (
# MAGIC   SCHEMANAME STRING,
# MAGIC   TABLENAME STRING)
# MAGIC USING delta
# MAGIC
# MAGIC