# Databricks notebook source
# MAGIC %md Cluster API

# COMMAND ----------

import requests

DOMAIN = 'onetakeda-dedev.cloud.databricks.com'
TOKEN = 'dapi65c0e5a81671f6dd73496c12ba186dfd'

# COMMAND ----------

####Working Function   
import requests

def create_cluster():
    response = requests.post(
      'https://%s/api/2.0/clusters/create' % (DOMAIN),
      headers={'Authorization': 'Bearer %s' % TOKEN},
      json = {
            "autoscale": {
                "min_workers": 1,
                "max_workers": 8
            },
            "cluster_name": "DE-CORP-SECURED-NONUSER",
            "spark_version": "11.3.x-scala2.12",
            "spark_conf": {
                "spark.hadoop.fs.s3a.acl.default": "BucketOwnerFullControl",
                "spark.databricks.hive.metastore.glueCatalog.enabled": "true",
                "spark.databricks.delta.autoCompact.enabled": "true",
                "spark.databricks.repl.allowedLanguages": "python,sql",
                "spark.databricks.acl.dfAclsEnabled": "true",
                "spark.hadoop.hive.metastore.glue.catalogid": "263789222982",
                "spark.hadoop.aws.glue.cache.db.size": "1000",
                "spark.hadoop.aws.glue.cache.db.ttl-mins": "30",
                "spark.hadoop.aws.glue.cache.db.enable": "true",
                "spark.hadoop.aws.glue.cache.table.size": "1000",
                "spark.databricks.delta.optimizeWrite.enabled": "true",
                "spark.hadoop.aws.glue.cache.table.ttl-mins": "30",
                "spark.hadoop.aws.glue.cache.table.enable": "true"
            },
            "aws_attributes": {
                "first_on_demand": 2,
                "availability": "SPOT_WITH_FALLBACK",
                "zone_id": "auto",
                "instance_profile_arn": "arn:aws:iam::103291568368:instance-profile/TEC-EC2-DATABRICKS-DEDEV-CORP-SECURED",
                "spot_bid_price_percent": 100,
                "ebs_volume_count": 0
            },
            "node_type_id": "i3.xlarge",
            "driver_node_type_id": "i3.2xlarge",
            "ssh_public_keys": [],
            "custom_tags": {
                "business-unit-n2": "CorpIT-Corporate Affairs IT",
                "app": "CORP Comman Data Pipline",
                "it-technical-owner": "dl.Ted-Platform-Team@Takeda.com",
                "business-criticality": "High",
                "application-name": "databricks",
                "it-business-owner": "dl.It_Databricks_Admins@takeda.com",
                "data-classification": "high",
                "ResourceClass": "Classic",
                "project-id": "APMS-92548",
                "apms-id": "APMS-91706",
                "environment-id": "Development",
                "application-owner": "rob.king@takeda.com",
                "ops-exclude-patch": "RITM0590559",
                "account-type": "Development",
                "Team": "databricks",
                "business-unit-n1": "CORP IT"
            },
            "spark_env_vars": {},
            "autotermination_minutes": 60,
            "enable_elastic_disk": "true",
            "init_scripts": [
                {
                    "workspace": {
                        "destination": "/WORKSPACE_LIB/init-scripts/DBX/custom-cert.sh"
                    }
                }
            ],
            "policy_id": "0F61EF4EEC0005DF",
            "enable_local_disk_encryption": "false"
        }
    )

    if response.status_code == 200:
      print(response.json()['cluster_id'])
    else:
      print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))

create_cluster()

# COMMAND ----------

####Working Function
#RITM2096400 04/15/2024
import requests


def create_sql_wh_cluster():
    response = requests.post(
      'https://%s/api/2.0/sql/warehouses' % (DOMAIN),
      headers={'Authorization': 'Bearer %s' % TOKEN},
      json = {
          "name": "CORP-DIGITAL-COMM-SQL",
          "cluster_size": "Medium",
          "min_num_clusters": 1,
          "max_num_clusters": 4,
          "auto_stop_mins": 10,
          "tags": {
            "custom_tags": [
              {
                "key": "project-id",
                "value": "APMS-92225"
              },
              {
                "key": "account-type",
                "value": "development"
              },
              {
                "key": "Team",
                "value": "DATABRICKS"
              },
              {
                "key": "apms-id",
                "value": "APMS-91706"
              },
              {
                "key": "application-name",
                "value": "Commercial Common Data Pipeline GPD"
              },
              {
                "key": "app",
                "value": "EDB CORP DIGITAL COMMUNICATION "
              },
              {
                "key": "it-business-owner",
                "value": "dl.It_Databricks_Admins@takeda.com"
              },
              {
                "key": "business-criticality",
                "value": "high"
              },
              {
                "key": "business-unit-n1",
                "value": "CORP IT"
              },
              {
                "key": "business-unit-n2",
                "value": "EDB-CORP-DIGITAL-COMMUNICATION"
              },
              {
                "key": "environment-id",
                "value": "DEV"
              },
              {
                "key": "application-owner",
                "value": "eric.brown@takeda.com"
              },
              {
                "key": "it-technical-owner",
                "value": "jim.lee@takeda.com"
              },
              {
                "key": "data-classification",
                "value": "confidential"
              }
            ]
          },
          "spot_instance_policy": "COST_OPTIMIZED",
          "enable_photon": "true",
          "enable_serverless_compute": "true"
        }
    )

    if response.status_code == 200:
      print("Successfully Created ",response.json())
    else:
      print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))

create_sql_wh_cluster()

# COMMAND ----------

####Working Function
#RITM2098302 04/10/2024
import requests


def create_sql_wh_cluster():
    response = requests.post(
      'https://%s/api/2.0/sql/warehouses' % (DOMAIN),
      headers={'Authorization': 'Bearer %s' % TOKEN},
      json = {
          "name": "COM-DI-GPD-CXOMNICHANNEL-SQL",
          "cluster_size": "Medium",
          "min_num_clusters": 1,
          "max_num_clusters": 4,
          "auto_stop_mins": 10,
          "tags": {
            "custom_tags": [
              {
                "key": "project-id",
                "value": "APMS-92363"
              },
              {
                "key": "account-type",
                "value": "development"
              },
              {
                "key": "Team",
                "value": "DATABRICKS"
              },
              {
                "key": "apms-id",
                "value": "APMS-91706"
              },
              {
                "key": "application-name",
                "value": "Commercial Common Data Pipeline GPD"
              },
              {
                "key": "app",
                "value": "COM GEM IT"
              },
              {
                "key": "it-business-owner",
                "value": "dl.It_Databricks_Admins@takeda.com"
              },
              {
                "key": "business-criticality",
                "value": "high"
              },
              {
                "key": "business-unit-n1",
                "value": "COMM IT GEM"
              },
              {
                "key": "business-unit-n2",
                "value": "Commercial Common Data Pipeline GPD"
              },
              {
                "key": "environment-id",
                "value": "DEV"
              },
              {
                "key": "application-owner",
                "value": "kranthi-kumar.sreeram@takeda.com"
              },
              {
                "key": "it-technical-owner",
                "value": "jim.lee@takeda.com"
              },
              {
                "key": "data-classification",
                "value": "confidential"
              }
            ]
          },
          "spot_instance_policy": "COST_OPTIMIZED",
          "enable_photon": "true",
          "enable_serverless_compute": "true"
        }
    )

    if response.status_code == 200:
      print("Successfully Created ",response.json())
    else:
      print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))

create_sql_wh_cluster()

# COMMAND ----------

####Working Function
#RITM2054503 03/28/2024
import requests


def create_sql_wh_cluster():
    response = requests.post(
      'https://%s/api/2.0/sql/warehouses' % (DOMAIN),
      headers={'Authorization': 'Bearer %s' % TOKEN},
      json = {
          "name": "CORP-HRPA-ONBOARDING-SQL",
          "cluster_size": "Medium",
          "min_num_clusters": 1,
          "max_num_clusters": 3,
          "auto_stop_mins": 10,
          "tags": {
            "custom_tags": [
              {
                "key": "project-id",
                "value": "APMS-92119"
              },
              {
                "key": "account-type",
                "value": "development"
              },
              {
                "key": "Team",
                "value": "CORP HRPA"
              },
              {
                "key": "apms-id",
                "value": "APMS-91706"
              },
              {
                "key": "application-name",
                "value": "EDB - Corp HR Analytics"
              },
              {
                "key": "app",
                "value": "EDB - Corp HR Analytics"
              },
              {
                "key": "it-business-owner",
                "value": "dl.It_Databricks_Admins@takeda.com"
              },
              {
                "key": "business-criticality",
                "value": "high"
              },
              {
                "key": "business-unit-n1",
                "value": "CORP IT HR"
              },
              {
                "key": "business-unit-n2",
                "value": "CORP IT HR"
              },
              {
                "key": "environment-id",
                "value": "DEV"
              },
              {
                "key": "application-owner",
                "value": "Blaise Kennings"
              },
              {
                "key": "it-technical-owner",
                "value": "jim.lee@takeda.com"
              },
              {
                "key": "data-classification",
                "value": "confidential"
              }
            ]
          },
          "spot_instance_policy": "COST_OPTIMIZED",
          "enable_photon": "true",
          "enable_serverless_compute": "true"
        }
    )

    if response.status_code == 200:
      print("Successfully Created ",response.json())
    else:
      print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))

create_sql_wh_cluster()

# COMMAND ----------

####Working Function   RITM1974642
import requests

def create_cluster():
    response = requests.post(
      'https://%s/api/2.0/clusters/create' % (DOMAIN),
      headers={'Authorization': 'Bearer %s' % TOKEN},
      json = {
            "autoscale": {
                "min_workers": 1,
                "max_workers": 8
            },
            "cluster_name": "DE-GLBL-OBU",
            "spark_version": "14.3.x-scala2.12",
            "spark_conf": {
                "spark.hadoop.fs.s3a.acl.default": "BucketOwnerFullControl",
                "spark.databricks.hive.metastore.glueCatalog.enabled": "true",
                "spark.databricks.delta.autoCompact.enabled": "true",
                "spark.databricks.repl.allowedLanguages": "python,sql,scala",
                "spark.hadoop.hive.metastore.glue.catalogid": "263789222982",
                "spark.hadoop.aws.glue.cache.db.size": "1000",
                "spark.hadoop.aws.glue.cache.db.ttl-mins": "30",
                "spark.hadoop.aws.glue.cache.db.enable": "true",
                "spark.hadoop.aws.glue.cache.table.size": "1000",
                "spark.databricks.delta.optimizeWrite.enabled": "true",
                "spark.hadoop.aws.glue.cache.table.ttl-mins": "30",
                "spark.hadoop.aws.glue.cache.table.enable": "true"
            },
            "aws_attributes": {
                "first_on_demand": 2,
                "availability": "SPOT_WITH_FALLBACK",
                "zone_id": "auto",
                "instance_profile_arn": "arn:aws:iam::103291568368:instance-profile/TEC-EC2-DATABRICKS-DEDEV-DE-GLBL-OBU-ROLE",
                "spot_bid_price_percent": 100,
                "ebs_volume_count": 0
            },
            "node_type_id": "i3.xlarge",
            "driver_node_type_id": "i3.2xlarge",
            "ssh_public_keys": [],
            "custom_tags": {
                "business-unit-n2": "Comm IT-Oncology BU",
                "app": "Commercial Data Analytics US OBU",
                "it-technical-owner": "dl.Ted-Platform-Team@Takeda.com",
                "business-criticality": "High",
                "application-name": "databricks",
                "it-business-owner": "dl.It_Databricks_Admins@takeda.com",
                "data-classification": "high",
                "ResourceClass": "Classic",
                "project-id": "APMS-92024",
                "apms-id": "APMS-91706",
                "environment-id": "Development",
                "application-owner": "Archana.Addepalli@Takeda.com",
                "ops-exclude-patch": "RITM0590559",
                "account-type": "Development",
                "Team": "databricks",
                "business-unit-n1": "Comm IT"
            },
            "spark_env_vars": {},
            "autotermination_minutes": 60,
            "enable_elastic_disk": "true",
            "init_scripts": [
                {
                    "workspace": {
                        "destination": "/WORKSPACE_LIB/init-scripts/DBX/custom-cert.sh"
                    }
                }
            ],
            "policy_id": "0F61EF4EEC0005DF",
            "enable_local_disk_encryption": "false"
        }
    )

    if response.status_code == 200:
      print(response.json()['cluster_id'])
    else:
      print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))

create_cluster()

# COMMAND ----------

####Working Function   RITM1877284
import requests

def create_cluster():
    response = requests.post(
      'https://%s/api/2.0/clusters/create' % (DOMAIN),
      headers={'Authorization': 'Bearer %s' % TOKEN},
      json = {
          "autoscale": {
              "min_workers": 1,
              "max_workers": 6
          },
          "cluster_name": "EDB-METADATA-CATALOG",
          "spark_version": "13.3.x-scala2.12",
          "spark_conf": {
              "spark.hadoop.fs.s3a.acl.default": "BucketOwnerFullControl",
              "spark.databricks.hive.metastore.glueCatalog.enabled": "true",
              "spark.databricks.delta.autoCompact.enabled": "true",
              "spark.databricks.repl.allowedLanguages": "python,sql",
              "spark.databricks.acl.dfAclsEnabled": "true",
              "spark.hadoop.hive.metastore.glue.catalogid": "263789222982",
              "spark.hadoop.aws.glue.cache.db.size": "1000",
              "spark.hadoop.aws.glue.cache.db.ttl-mins": "30",
              "spark.hadoop.aws.glue.cache.db.enable": "true",
              "spark.hadoop.aws.glue.cache.table.size": "1000",
              "spark.databricks.delta.optimizeWrite.enabled": "true",
              "spark.hadoop.aws.glue.cache.table.ttl-mins": "30",
              "spark.hadoop.aws.glue.cache.table.enable": "true"
          },
          "aws_attributes": {
              "first_on_demand": 2,
              "availability": "SPOT_WITH_FALLBACK",
              "zone_id": "auto",
              "instance_profile_arn": "arn:aws:iam::103291568368:instance-profile/TEC-EC2-DATABRICKS-DEDEV-EDB-METADATA-CATALOG-ROLE",
              "spot_bid_price_percent": 100,
              "ebs_volume_count": 0
          },
          "node_type_id": "i3.xlarge",
          "driver_node_type_id": "i3.2xlarge",
          "ssh_public_keys": [],
          "custom_tags": {
              "business-unit-n2": "EDB Data Marketplace ",
              "app": "EDB Data Marketplace ",
              "it-technical-owner": "dl.Ted-Platform-Team@Takeda.com",
              "business-criticality": "High",
              "application-name": "databricks",
              "it-business-owner": "dl.It_Databricks_Admins@takeda.com",
              "data-classification": "high",
              "ResourceClass": "Classic",
              "project-id": "APMS-10133",
              "apms-id": "APMS-91706",
              "environment-id": "Development",
              "application-owner": "bill.chen@takeda.com",
              "ops-exclude-patch": "RITM0590559",
              "account-type": "Development",
              "Team": "databricks",
              "business-unit-n1": "Data Marketplace"
          },
          "spark_env_vars": {},
          "autotermination_minutes": 45,
          "enable_elastic_disk": "true",
          "init_scripts": [
              {
                  "workspace": {
                      "destination": "/WORKSPACE_LIB/init-scripts/DBX/custom-cert.sh"
                  }
              }
          ],
          "policy_id": "0F61EF4EEC0005DF",
          "enable_local_disk_encryption": "false",
          "runtime_engine": "STANDARD"
      }
    )

    if response.status_code == 200:
      print(response.json()['cluster_id'])
    else:
      print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))

create_cluster()

# COMMAND ----------

####Working Function
#RITM1966588 01/19/2024
import requests


def create_sql_wh_cluster():
    response = requests.post(
      'https://%s/api/2.0/sql/warehouses' % (DOMAIN),
      headers={'Authorization': 'Bearer %s' % TOKEN},
      json = {
          "name": "COM-DI-GEM-COUNTRY-1-SQL",
          "cluster_size": "Medium",
          "min_num_clusters": 1,
          "max_num_clusters": 4,
          "auto_stop_mins": 10,
          "tags": {
            "custom_tags": [
              {
                "key": "project-id",
                "value": "APMS-92505"
              },
              {
                "key": "account-type",
                "value": "development"
              },
              {
                "key": "Team",
                "value": "DATABRICKS"
              },
              {
                "key": "apms-id",
                "value": "APMS-91706"
              },
              {
                "key": "application-name",
                "value": "Commercial Data Analytics GEM Europe"
              },
              {
                "key": "app",
                "value": "COM GEM IT"
              },
              {
                "key": "it-business-owner",
                "value": "dl.It_Databricks_Admins@takeda.com"
              },
              {
                "key": "business-criticality",
                "value": "high"
              },
              {
                "key": "business-unit-n1",
                "value": "COMM IT GEM"
              },
              {
                "key": "business-unit-n2",
                "value": "COMM IT GEM"
              },
              {
                "key": "environment-id",
                "value": "DEV"
              },
              {
                "key": "application-owner",
                "value": "kranthi-kumar.sreeram@takeda.com"
              },
              {
                "key": "it-technical-owner",
                "value": "jim.lee@takeda.com"
              },
              {
                "key": "data-classification",
                "value": "confidential"
              }
            ]
          },
          "spot_instance_policy": "COST_OPTIMIZED",
          "enable_photon": "true",
          "enable_serverless_compute": "true"
        }
    )

    if response.status_code == 200:
      print("Successfully Created ",response.json())
    else:
      print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))

create_sql_wh_cluster()

# COMMAND ----------

####Working Function
#RITM1926658 12/21/2023
import requests


def create_sql_wh_cluster():
    response = requests.post(
      'https://%s/api/2.0/sql/warehouses' % (DOMAIN),
      headers={'Authorization': 'Bearer %s' % TOKEN},
      json = {
          "name": "COM-EUCAN-DI-COUNTRY-1-SQL",
          "cluster_size": "Medium",
          "min_num_clusters": 1,
          "max_num_clusters": 4,
          "auto_stop_mins": 10,
          "tags": {
            "custom_tags": [
              {
                "key": "project-id",
                "value": "APMS-92115"
              },
              {
                "key": "account-type",
                "value": "development"
              },
              {
                "key": "Team",
                "value": "DATABRICKS"
              },
              {
                "key": "apms-id",
                "value": "APMS-91706"
              },
              {
                "key": "application-name",
                "value": "Commercial Data Analytics EUCAN Europe"
              },
              {
                "key": "app",
                "value": "CORP IT"
              },
              {
                "key": "it-business-owner",
                "value": "dl.It_Databricks_Admins@takeda.com"
              },
              {
                "key": "business-criticality",
                "value": "high"
              },
              {
                "key": "business-unit-n1",
                "value": "COMM IT EUCAN"
              },
              {
                "key": "business-unit-n2",
                "value": "COMM IT EUCAN"
              },
              {
                "key": "environment-id",
                "value": "DEV"
              },
              {
                "key": "application-owner",
                "value": "kranthi-kumar.sreeram@takeda.com"
              },
              {
                "key": "it-technical-owner",
                "value": "jim.lee@takeda.com"
              },
              {
                "key": "data-classification",
                "value": "confidential"
              }
            ]
          },
          "spot_instance_policy": "COST_OPTIMIZED",
          "enable_photon": "true",
          "enable_serverless_compute": "true"
        }
    )

    if response.status_code == 200:
      print("Successfully Created ",response.json())
    else:
      print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))

create_sql_wh_cluster()

# COMMAND ----------

####Working Function
##Ticket Number: RITM1817376 10/30/2023 DE-CORP-HR-ANALYTICS
import requests

def create_cluster():
    response = requests.post(
      'https://%s/api/2.0/clusters/create' % (DOMAIN),
      headers={'Authorization': 'Bearer %s' % TOKEN},
      json = {
            "autoscale": {
            "min_workers": 1,
            "max_workers": 10
        },
        "cluster_name": "DE-CORP-HR-ANALYTICS",
        "spark_version": "13.3.x-scala2.12",
        "spark_conf": {
            "spark.hadoop.fs.s3a.acl.default": "BucketOwnerFullControl",
            "spark.databricks.hive.metastore.glueCatalog.enabled": "true",
            "spark.databricks.delta.autoCompact.enabled": "true",
            "spark.databricks.repl.allowedLanguages": "python,sql,r,scala",
            "spark.databricks.acl.dfAclsEnabled": "false",
            "spark.databricks.acl.needAdminPermissionToViewLogs": "false",
            "spark.hadoop.hive.metastore.glue.catalogid": "263789222982",
            "spark.hadoop.aws.glue.cache.db.size": "1000",
            "spark.hadoop.aws.glue.cache.db.ttl-mins": "30",
            "spark.hadoop.aws.glue.cache.db.enable": "true",
            "spark.hadoop.aws.glue.cache.table.size": "1000",
            "spark.databricks.delta.optimizeWrite.enabled": "true",
            "spark.hadoop.aws.glue.cache.table.ttl-mins": "30",
            "spark.hadoop.aws.glue.cache.table.enable": "true"
        },
        "aws_attributes": {
            "first_on_demand": 2,
            "availability": "SPOT_WITH_FALLBACK",
            "zone_id": "auto",
            "instance_profile_arn": "arn:aws:iam::103291568368:instance-profile/TEC-EC2-DATABRICKS-DEDEV-DE-CORP-HR-ANALYTICS-ROLE",
            "spot_bid_price_percent": 100,
            "ebs_volume_count": 0
        },
        "node_type_id": "i3.2xlarge",
        "driver_node_type_id": "i3.2xlarge",
        "ssh_public_keys": [],
        "custom_tags": {
            "business-unit-n2": "CORP IT-Strategy Operations",
            "app": "CORP HR Analytics ",
            "it-technical-owner": "dl.Ted-Platform-Team@Takeda.com",
            "business-criticality": "High",
            "application-name": "databricks",
            "it-business-owner": "dl.It_Databricks_Admins@takeda.com",
            "data-classification": "high",
            "ResourceClass": "Classic",
            "project-id": "APMS-92119",
            "apms-id": "APMS-91706",
            "environment-id": "Development",
            "application-owner": "anand.vats@takeda.com",
            "ops-exclude-patch": "RITM0590559",
            "account-type": "Development",
            "Team": "databricks",
            "business-unit-n1": "PDT IT"
        },
        "spark_env_vars": {},
        "autotermination_minutes": 60,
        "enable_elastic_disk": "true",
        "init_scripts": [
            {
                "workspace": {
                    "destination": "/WORKSPACE_LIB/init-scripts/DBX/custom-cert.sh"
                }
            }
        ],
        "policy_id": "0F61EF4EEC0005DF",
        "enable_local_disk_encryption": "false",
        "runtime_engine": "STANDARD"
    }
    )

    if response.status_code == 200:
      print(response.json()['cluster_id'])
    else:
      print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))

create_cluster()

# COMMAND ----------

####Working Function
##Ticket Number: RITM1836704 10/25/2023 DE-PDT-ANALYTICS
import requests

def create_cluster():
    response = requests.post(
      'https://%s/api/2.0/clusters/create' % (DOMAIN),
      headers={'Authorization': 'Bearer %s' % TOKEN},
      json = {
            "autoscale": {
            "min_workers": 1,
            "max_workers": 10
        },
        "cluster_name": "DE-PDT-ANALYTICS",
        "spark_version": "13.3.x-scala2.12",
        "spark_conf": {
            "spark.hadoop.fs.s3a.acl.default": "BucketOwnerFullControl",
            "spark.databricks.hive.metastore.glueCatalog.enabled": "true",
            "spark.databricks.delta.autoCompact.enabled": "true",
            "spark.databricks.repl.allowedLanguages": "python,sql,r,scala",
            "spark.databricks.acl.dfAclsEnabled": "false",
            "spark.databricks.acl.needAdminPermissionToViewLogs": "false",
            "spark.hadoop.hive.metastore.glue.catalogid": "263789222982",
            "spark.hadoop.aws.glue.cache.db.size": "1000",
            "spark.hadoop.aws.glue.cache.db.ttl-mins": "30",
            "spark.hadoop.aws.glue.cache.db.enable": "true",
            "spark.hadoop.aws.glue.cache.table.size": "1000",
            "spark.databricks.delta.optimizeWrite.enabled": "true",
            "spark.hadoop.aws.glue.cache.table.ttl-mins": "30",
            "spark.hadoop.aws.glue.cache.table.enable": "true"
        },
        "aws_attributes": {
            "first_on_demand": 2,
            "availability": "SPOT_WITH_FALLBACK",
            "zone_id": "auto",
            "instance_profile_arn": "arn:aws:iam::103291568368:instance-profile/TEC-EC2-DATABRICKS-DEDEV-PDT-ANALYTICS-ROLE",
            "spot_bid_price_percent": 100,
            "ebs_volume_count": 0
        },
        "node_type_id": "i3.2xlarge",
        "driver_node_type_id": "i3.2xlarge",
        "ssh_public_keys": [],
        "custom_tags": {
            "business-unit-n2": "PDT IT-Strategy Operations",
            "app": "PDT Analytics Foundation",
            "it-technical-owner": "dl.Ted-Platform-Team@Takeda.com",
            "business-criticality": "High",
            "application-name": "databricks",
            "it-business-owner": "dl.It_Databricks_Admins@takeda.com",
            "data-classification": "high",
            "ResourceClass": "Classic",
            "project-id": "APMS-10216",
            "apms-id": "APMS-91706",
            "environment-id": "Development",
            "application-owner": "neelpa.shah@takeda.com",
            "ops-exclude-patch": "RITM0590559",
            "account-type": "Development",
            "Team": "databricks",
            "business-unit-n1": "PDT IT"
        },
        "cluster_log_conf": {
            "s3": {
                "destination": "s3://tpc-aws-ted-dev-edpp-raw-pdt-eu-central-1/dev/databricks_logs/",
                "region": "eu-central-1",
                "enable_encryption": "true",
                "canned_acl": "bucket-owner-full-control"
            }
        },
        "spark_env_vars": {},
        "autotermination_minutes": 60,
        "enable_elastic_disk": "true",
        "init_scripts": [
            {
                "workspace": {
                    "destination": "/WORKSPACE_LIB/init-scripts/DBX/custom-cert.sh"
                }
            }
        ],
        "policy_id": "0F61EF4EEC0005DF",
        "enable_local_disk_encryption": "false",
        "runtime_engine": "STANDARD"
    }
    )

    if response.status_code == 200:
      print(response.json()['cluster_id'])
    else:
      print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))

create_cluster()

# COMMAND ----------

####Working Function
#RITM1817381 10/25/2023
import requests


def create_sql_wh_cluster():
    response = requests.post(
      'https://%s/api/2.0/sql/warehouses' % (DOMAIN),
      headers={'Authorization': 'Bearer %s' % TOKEN},
      json = {
          "name": "CORP-HR-POC-SQL",
          "cluster_size": "Medium",
          "min_num_clusters": 1,
          "max_num_clusters": 3,
          "auto_stop_mins": 10,
          "tags": {
            "custom_tags": [
              {
                "key": "project-id",
                "value": "APMS-92119"
              },
              {
                "key": "account-type",
                "value": "development"
              },
              {
                "key": "Team",
                "value": "CORP HR"
              },
              {
                "key": "apms-id",
                "value": "APMS-91706"
              },
              {
                "key": "application-name",
                "value": "CORP HR"
              },
              {
                "key": "app",
                "value": "CORP IT"
              },
              {
                "key": "it-business-owner",
                "value": "dl.It_Databricks_Admins@takeda.com"
              },
              {
                "key": "business-criticality",
                "value": "high"
              },
              {
                "key": "business-unit-n1",
                "value": "CORP IT HR"
              },
              {
                "key": "business-unit-n2",
                "value": "CORP IT HR"
              },
              {
                "key": "environment-id",
                "value": "DEV"
              },
              {
                "key": "application-owner",
                "value": "anand.vats@takeda.com"
              },
              {
                "key": "it-technical-owner",
                "value": "jim.lee@takeda.com"
              },
              {
                "key": "data-classification",
                "value": "confidential"
              }
            ]
          },
          "spot_instance_policy": "COST_OPTIMIZED",
          "enable_photon": "true",
          "enable_serverless_compute": "true"
        }
    )

    if response.status_code == 200:
      print("Successfully Created ",response.json())
    else:
      print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))

create_sql_wh_cluster()

# COMMAND ----------

####Working Function
#RITM1753359 10/12/2023
import requests


def create_sql_wh_cluster():
    response = requests.post(
      'https://%s/api/2.0/sql/warehouses' % (DOMAIN),
      headers={'Authorization': 'Bearer %s' % TOKEN},
      json = {
          "name": "PDT-ANALYTICS-SQL",
          "cluster_size": "Medium",
          "min_num_clusters": 1,
          "max_num_clusters": 3,
          "auto_stop_mins": 10,
          "tags": {
            "custom_tags": [
              {
                "key": "project-id",
                "value": "APMS-10216"
              },
              {
                "key": "account-type",
                "value": "development"
              },
              {
                "key": "Team",
                "value": "PDT Analytics Foundation"
              },
              {
                "key": "apms-id",
                "value": "APMS-91706"
              },
              {
                "key": "application-name",
                "value": "PDT Analytics Foundation"
              },
              {
                "key": "app",
                "value": "PDT Analytics Foundation"
              },
              {
                "key": "it-business-owner",
                "value": "dl.It_Databricks_Admins@takeda.com"
              },
              {
                "key": "business-criticality",
                "value": "high"
              },
              {
                "key": "business-unit-n1",
                "value": "PDT IT"
              },
              {
                "key": "business-unit-n2",
                "value": "PDT IT"
              },
              {
                "key": "environment-id",
                "value": "DEV"
              },
              {
                "key": "application-owner",
                "value": "neelpa.shah@takeda.com"
              },
              {
                "key": "it-technical-owner",
                "value": "dl.Ted-Platform-Team@Takeda.com"
              },
              {
                "key": "data-classification",
                "value": "confidential"
              }
            ]
          },
          "spot_instance_policy": "COST_OPTIMIZED",
          "enable_photon": "true",
          "enable_serverless_compute": "true",
          "warehouse_type": "Pro"
        }
    )

    if response.status_code == 200:
      print("Successfully Created ",response.json())
    else:
      print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))



# COMMAND ----------

create_sql_wh_cluster()

# COMMAND ----------

response = requests.post(
      'https://%s/api/2.0/clusters/create' % (DOMAIN),
      headers={'Authorization': 'Bearer %s' % (TOKEN)},
      json = json_content 
      )

if response.status_code == 200:
      print("Cluster ID: {}".format(response.json()['cluster_id']))
else:
  print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))

# COMMAND ----------

import requests
response = requests.get(
  'https://%s/api/2.0/groups/list-members' % (DOMAIN),
  headers={'Authorization': 'Bearer %s' % TOKEN},
  json=  {
  "group_name": "grp-com-mdm-bus-uat"
  }
)

if response.status_code == 200:
  print(response.json())
else:
  print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))

# COMMAND ----------

# MAGIC %md SQL WH Setup

# COMMAND ----------

# MAGIC %md SQL WH SETUP

# COMMAND ----------

####Working Function
import requests


def create_sql_wh_cluster():
    response = requests.post(
      'https://%s/api/2.0/sql/warehouses' % (DOMAIN),
      headers={'Authorization': 'Bearer %s' % TOKEN},
      json = {
          "name": "COM-GMA-SQL",
          "cluster_size": "Medium",
          "min_num_clusters": 1,
          "max_num_clusters": 3,
          "auto_stop_mins": 60,
          "auto_resume": "True",
          "tags": {
            "custom_tags": [
              {
                "key": "project-id",
                "value": "APMS-04902"
              },
              {
                "key": "account-type",
                "value": "development"
              },
              {
                "key": "Team",
                "value": "Comm IT"
              },
              {
                "key": "apms-id",
                "value": "APMS-91706"
              },
              {
                "key": "application-name",
                "value": "databricks"
              },
              {
                "key": "app",
                "value": "Global Medical Affairs"
              },
              {
                "key": "it-business-owner",
                "value": "dl.It_Databricks_Admins@takeda.com"
              },
              {
                "key": "business-criticality",
                "value": "high"
              },
              {
                "key": "business-unit-n1",
                "value": "Comm IT"
              },
              {
                "key": "business-unit-n2",
                "value": "Comm IT"
              },
              {
                "key": "environment-id",
                "value": "DEV"
              },
              {
                "key": "application-owner",
                "value": "Jorge.Ortiz-Frank@takeda.com"
              },
              {
                "key": "it-technical-owner",
                "value": "dl.It_Databricks_Admins@takeda.com"
              },
              {
                "key": "data-classification",
                "value": "confidential"
              }
            ]
          },
          "spot_instance_policy": "COST_OPTIMIZED",
          "enable_photon": "True",
          "enable_serverless_compute": "False",
          "warehouse_type": "PRO"
        }
    )

    if response.status_code == 200:
      print("Successfully Created ",response.json())
    else:
      print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))



# COMMAND ----------

create_sql_wh_cluster()

# COMMAND ----------

####Working Function
import requests

def create_cluster():
    response = requests.post(
      'https://%s/api/2.0/clusters/create' % (DOMAIN),
      headers={'Authorization': 'Bearer %s' % TOKEN},
      json = {
        "autoscale": {
            "min_workers": 1,
            "max_workers": 8
        },
        "cluster_name": "DE-COM-MDM-KOKORO",
        "spark_version": "13.3.x-scala2.12",
        "aws_attributes": {
            "first_on_demand": 2,
            "availability": "SPOT_WITH_FALLBACK",
            "zone_id": "auto",
            "instance_profile_arn": "arn:aws:iam::103291568368:instance-profile/TEC-EC2-DATABRICKS-DEDEV-DE-MDM-KOKORO-ROLE",
            "spot_bid_price_percent": 100,
            "ebs_volume_count": 0
        },
        "node_type_id": "i3.xlarge",
        "driver_node_type_id": "i3.2xlarge",
        "ssh_public_keys": [],
        "custom_tags": {
            "app": "Kokoro EUCAN MDM",
            "project-id": "APMS-10250",
            "environment-id": "DEV",
            "application-owner": "venkatesh.ramakrishnan@takeda.com",
            "account-type": "development",
            "version":"2022-03-30"
        },
        "spark_env_vars": {},
        "autotermination_minutes": 60,
        "enable_elastic_disk": "true",
        "cluster_source": "API",
        "policy_id": "0F61EF4EEC0005C1",
        "enable_local_disk_encryption": "false",
        "runtime_engine": "STANDARD"
    }
    )

    if response.status_code == 200:
      print(response.json()['cluster_id'])
    else:
      print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))



# COMMAND ----------

create_cluster()

# COMMAND ----------

####Working Function
import requests

DOMAIN = 'onetakeda-ustst.cloud.databricks.com'
TOKEN = 'dapi4425f4db5d64f30b90703b169e4655d0'

def create_cluster():
    response = requests.post(
      'https://%s/api/2.0/clusters/create' % (DOMAIN),
      headers={'Authorization': 'Bearer %s' % TOKEN},
      json = {
        "autoscale": {
            "min_workers": 1,
            "max_workers": 8
        },
        "cluster_name": "DE-COM-USBU-FSR",
        "spark_version": "12.2.x-scala2.12",
        "aws_attributes": {
            "first_on_demand": 2,
            "availability": "SPOT_WITH_FALLBACK",
            "zone_id": "auto",
            "instance_profile_arn": "arn:aws:iam::671616840389:instance-profile/TEC-EC2-DATABRICKS-USTST-DE-COM-USBU-FIELDSALESREPORTING-ROLE",
            "spot_bid_price_percent": 100,
            "ebs_volume_count": 0
        },
        "node_type_id": "i3.2xlarge",
        "driver_node_type_id": "i3.4xlarge",
        "ssh_public_keys": [],
        "custom_tags": {
            "app": "USBU HummingBird FSR ",
            "project-id": "APMS-92112",
            "environment-id": "TST",
            "application-owner": "Mohan.Kuruganti@takeda.com",
            "account-type": "test",
            "version":"2022-03-30"
        },
        "spark_env_vars": {},
        "autotermination_minutes": 60,
        "enable_elastic_disk": "true",
        "cluster_source": "API",
        "policy_id": "9C6308F703006920",
        "enable_local_disk_encryption": "false",
        "runtime_engine": "STANDARD"
    }
    )

    if response.status_code == 200:
      print(response.json()['cluster_id'])
    else:
      print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))



# COMMAND ----------

create_cluster()

# COMMAND ----------

"business-unit-n2": "CORPORATE-IT",
            "app": "Data Digital and Learning Analytics Hub",
            "it-technical-owner": "dl.Ted-Platform-Team@Takeda.com",
            "business-criticality": "High",
            "application-name": "databricks",
            "it-business-owner": "dl.It_Databricks_Admins@takeda.com",
            "data-classification": "high",
            "ResourceClass": "Classic",
            "project-id": "APMS-10137",
            "apms-id": "APMS-91706",
            "environment-id": "test",
            "application-owner": "anand.vats@takeda.com",
            "ops-exclude-patch": "RITM0590559",
            "account-type": "test",
            "Team": "databricks",
            "business-unit-n1": "CORPORATE",
            "version":"2022-03-30"

# COMMAND ----------

{
    "autoscale": {
        "min_workers": 1,
        "max_workers": 6
    },
    "cluster_name": "DE-CORP-TDP",
    "spark_version": "12.2.x-scala2.12",
    "spark_conf": {
        "spark.hadoop.fs.s3a.acl.default": "BucketOwnerFullControl",
        "spark.databricks.hive.metastore.glueCatalog.enabled": "true",
        "spark.databricks.delta.autoCompact.enabled": "true",
        "spark.databricks.repl.allowedLanguages": "python,sql",
        "spark.databricks.acl.dfAclsEnabled": "false",
        "spark.hadoop.hive.metastore.glue.catalogid": "263789222982",
        "spark.hadoop.aws.glue.cache.db.size": "1000",
        "spark.hadoop.aws.glue.cache.db.ttl-mins": "30",
        "spark.hadoop.aws.glue.cache.db.enable": "true",
        "spark.hadoop.aws.glue.cache.table.size": "1000",
        "spark.databricks.delta.optimizeWrite.enabled": "true",
        "spark.hadoop.aws.glue.cache.table.ttl-mins": "30",
        "spark.hadoop.aws.glue.cache.table.enable": "true"
    },
    "aws_attributes": {
        "first_on_demand": 2,
        "availability": "SPOT_WITH_FALLBACK",
        "zone_id": "auto",
        "instance_profile_arn": "arn:aws:iam::671616840389:instance-profile/TEC-EC2-DATABRICKS-USTST-DE-CORP-TRUSTEDDATAPRODUCT-ROLE",
        "spot_bid_price_percent": 100,
        "ebs_volume_count": 0
    },
    "node_type_id": "i3.2xlarge",
    "driver_node_type_id": "i3.2xlarge",
    "ssh_public_keys": [],
    "custom_tags": {
        "business-unit-n2": "CORPORATE-IT",
        "app": "Data Digital and Learning Analytics Hub",
        "it-technical-owner": "dl.Ted-Platform-Team@Takeda.com",
        "business-criticality": "High",
        "application-name": "databricks",
        "it-business-owner": "dl.It_Databricks_Admins@takeda.com",
        "data-classification": "high",
        "ResourceClass": "Classic",
        "project-id": "APMS-10137",
        "apms-id": "APMS-91706",
        "environment-id": "Development",
        "application-owner": "anand.vats@takeda.com",
        "ops-exclude-patch": "RITM0590559",
        "account-type": "production",
        "Team": "databricks",
        "business-unit-n1": "CORPORATE"
    },
    "spark_env_vars": {},
    "autotermination_minutes": 60,
    "enable_elastic_disk": true,
    "cluster_source": "API",
    "init_scripts": [
        {
            "workspace": {
                "destination": "/WORKSPACE_LIB/init-scripts/DBX/custom-cert.sh"
            }
        }
    ],
    "policy_id": "9C61EF4F96003437",
    "enable_local_disk_encryption": false,
    "runtime_engine": "STANDARD",
    "cluster_id": "0727-084356-u5gl2sm6"
}

# COMMAND ----------

import requests

DOMAIN = 'usdev.databaricks.onetakeda.com'
TOKEN = 'dapi9b21958d794382983209631eca6817e4'

response = requests.post(
  'https://%s/api/2.0/clusters/create' % (DOMAIN),
  headers={'Authorization': 'Bearer %s' % TOKEN},
  json={
    "cluster_name": "my-cluster1",
    "spark_version": "5.5.x-scala2.11",
    "node_type_id": "i3.xlarge",
    "spark_env_vars": {
      "PYSPARK_PYTHON": "/databricks/python3/bin/python3"
    },
    "num_workers": 25
  }
)

if response.status_code == 200:
  print(response.json()['cluster_id'])
else:
  print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))

# COMMAND ----------


response = requests.get(
  'https://%s/api/2.0/groups/list-members' % (DOMAIN),
  headers={'Authorization': 'Bearer %s' % TOKEN},
  json=  {
  "group_name": "grp-com-mdm-bus-uat"
  }
)

if response.status_code == 200:
  print(response.json())
else:
  print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))

# COMMAND ----------


user_names = ['Deepak.KL@takeda.com','abhishek.kala@takeda.com','shailesh.srivastava@takeda.com','Kashinath.Yadav@takeda.com','Anand.Vats@takeda.com','nimish.nagpal@takeda.com','malini.acharya@takeda.com','Suraj.Marathe@takeda.com','rishi.singh@takeda.com','sivaneshbabu.anandaraman@takeda.com','balaji.ranganathan@takeda.com','aditya.jain@takeda.com','adrija.ganguly@takeda.com','soumen.ghosh@takeda.com','priyabrata.beura@takeda.com','maduva.giri@takeda.com','prerna.na@takeda.com','somoshree.basak@takeda.com','nisha.agarwal@takeda.com','rashmi.l@takeda.com','Chad.Wollheim@takeda.com','kumaresh.subramanian@takeda.com','ishdeep.duggal@takeda.com','swapnil.deshpande@takeda.com','prateek.chopra@takeda.com','ketki.pawar@takeda.com','nitesh.parikh@takeda.com','vinayak.jagtap@takeda.com','ujjwal.porwal@takeda.com','sainikhil.pilli@takeda.com','animesh.shukla@takeda.com','rachit.misra@takeda.com','aman-kumar.singh@takeda.com','shanthi.l@takeda.com','rajendraprasad.bingi@takeda.com','raja.doddi@takeda.com','chandana.m@takeda.com','anuradha.mahalle@takeda.com','abhishek.jain@takeda.com','rishab.agarwal@takeda.com','puneet.sinhal2@takeda.com','USMDMTidalSvcAcc','vaibhavi.shirode@takeda.com']
import requests

DOMAIN = 'usdev.databaricks.onetakeda.com'
TOKEN = 'dapi9b21958d794382983209631eca6817e4'

for user_name in user_names:
  response = requests.post(
    'https://%s/api/2.0/groups/add-member' % (DOMAIN),
    headers={'Authorization': 'Bearer %s' % TOKEN},
    json=  {
    "user_name": '%s' % user_name,   
    "parent_name": "grp-de-mdm-omni"
     }
  )

  if response.status_code == 200:
    print(response.json())
  else:
    print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))

# COMMAND ----------

import requests

DOMAIN = 'usdev.databaricks.onetakeda.com'
TOKEN = 'dapi9b21958d794382983209631eca6817e4'

response = requests.post(
  'https://%s/api/2.0/groups/create' % (DOMAIN),
  headers={'Authorization': 'Bearer %s' % TOKEN},
  json=  {
  "group_name": "grp-test"
  }
)

if response.status_code == 200:
  print(response.json())
else:
  print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))

# COMMAND ----------

import requests

DOMAIN = 'usdev.databaricks.onetakeda.com'
TOKEN = 'dapi9b21958d794382983209631eca6817e4'
name2 = "arnav.chaudhary@takeda.com"
name1 = ["arnav.chaudhary@takeda.com","apolok.mandal@takeda.com"];
for name in name1:
  response = requests.post(
    'https://%s/api/2.0/groups/add-member' % (DOMAIN),
    headers={'Authorization': 'Bearer %s' % TOKEN},
    json=  {
    "user_name": '%s' % name,   
    "parent_name": "grp-test"
     }
  )

  if response.status_code == 200:
    print(response.json())
  else:
    print("Error launching cluster: %s: %s" % (response.json()["error_code"], response.json()["message"]))

# COMMAND ----------

import requests

DOMAIN = 'usdev.databaricks.onetakeda.com'
TOKEN = 'dapi9b21958d794382983209631eca6817e4'
group_names = ["grp-test"]
for group_name in group_names:
  response = requests.post(
    'https://%s/api/2.0/groups/delete' % (DOMAIN),
    headers={'Authorization': 'Bearer %s' % TOKEN},
    json=  {
    "group_name": "%s" % group_name
    }
  )

  if response.status_code == 200:
    print(response.json())
  else:
    print("Error Creating the  group: %s: %s" % (response.json()["error_code"], response.json()["message"]))

# COMMAND ----------

import requests

DOMAIN = 'usdev.databaricks.onetakeda.com'
TOKEN = 'dapi9b21958d794382983209631eca6817e4'
group_names = ['grp-da-com','grp-ds-com','grp-bi-com-ps','grp-da-crop','grp-ds-corp-itdigital','grp-dev-corp-itdigital','grp-de-corp-smart','grp-ds-corp-smart','grp-de-crop-data-catalog','grp-ops-entcdp','grp-it-com-gi-med','grp-ds-gms-hikari','grp-ops-gms-toltkpi','grp-ops-gms-trackwise','grp-ops-gmsgq-kpi','grp-it-mdm-users','grp-de-mdm-omni','grp-it-com-nsbu','grp-ops-com-nsbu','grp-ds-com-mmaa','grp-ds-obu-path2rx','grp-ds-obu-path2rx-dec-eng','grp-ops-rnd-gma','grp-uat-rnd-mps','grp-de-pdt-analytics','grp-rnd-mps']
for group_name in group_names:
  response = requests.post(
    'https://%s/api/2.0/groups/create' % (DOMAIN),
    headers={'Authorization': 'Bearer %s' % TOKEN},
    json=  {
    "group_name": "%s" % group_name
    }
  )

  if response.status_code == 200:
    print(response.json())
  else:
    print("Error Creating the  group: %s: %s" % (response.json()["error_code"], response.json()["message"]))

# COMMAND ----------

import requests

DOMAIN = 'usdev.databaricks.onetakeda.com'
TOKEN = 'dapi9b21958d794382983209631eca6817e4'
group_names = ['grp-da-com','grp-ds-com','grp-bi-com-ps','grp-da-crop','grp-ds-corp-itdigital','grp-dev-corp-itdigital','grp-de-corp-smart','grp-ds-corp-smart','grp-de-crop-data-catalog','grp-ops-entcdp','grp-it-com-gi-med','grp-ds-gms-hikari','grp-ops-gms-toltkpi','grp-ops-gms-trackwise','grp-ops-gmsgq-kpi','grp-it-mdm-users','grp-de-mdm-omni','grp-it-com-nsbu','grp-ops-com-nsbu','grp-ds-com-mmaa','grp-ds-obu-path2rx','grp-ds-obu-path2rx-dec-eng','grp-ops-rnd-gma','grp-uat-rnd-mps','grp-de-pdt-analytics','grp-rnd-mps']
for group_name in group_names:
  response = requests.post(
    'https://%s/api/2.0/groups/delete' % (DOMAIN),
    headers={'Authorization': 'Bearer %s' % TOKEN},
    json=  {
    "group_name": "%s" % group_name
    }
  )

  if response.status_code == 200:
    print(response.json())
  else:
    print("Error Creating the  group: %s: %s" % (response.json()["error_code"], response.json()["message"]))

# COMMAND ----------

import requests

DOMAIN = 'usdev.databaricks.onetakeda.com'
TOKEN = 'dapi9b21958d794382983209631eca6817e4'
group_names = ["test"]
for group_name in group_names:
    response = requests.post(
      'https://%s/api/2.0/groups/delete' % (DOMAIN),
      headers={'Authorization': 'Bearer %s' % TOKEN},
      json=  {
      "group_name": "%s" % group_name
      }
    )

    if response.status_code == 200:
      print(response.json())
    else:
      print("Error Creating the  group: %s: %s" % (response.json()["error_code"], response.json()["message"]))