# Databricks notebook source


# COMMAND ----------

from pyspark.sql import *

# Create a Spark session
spark = SparkSession.builder.appName("CreateDatabases").getOrCreate()

def create_databases(database_names):
    for db_name in database_names:
        create_db_query = f"CREATE DATABASE IF NOT EXISTS {db_name} Location {path}/{db_name}.db COMMENT"
        spark.sql(create_db_query)
        print(f"Created database: {db_name}")

# List of database names you want to create
database_names = ["db1", "db2", "db3"]

# Call the function to create databases
create_databases(database_names)

# Stop the Spark session
spark.stop()


# COMMAND ----------

CREATE DATABASE IF NOT EXISTS com_jp_raw_ddt_rwd
Location 's3://tpc-aws-ted-dev-edpp-raw-com-ap-northeast-1/ddt/rwd/com_jp_raw_ddt_rwd.db' 
COMMENT 'RAW Real world data Database for DDT Project';

# COMMAND ----------


def databases_tables(database_names):
    table_list = []
    for db_name in database_names:
        layer = db_name.split("_")[2]
        layer_1= layer.upper()
        data = db_name.split("_")[-1]
        path = f"s3://tpc-aws-ted-dev-edpp-{layer}-com-ap-northeast-1/ddt"
        sep = "'"
        get_table_query = f"show tables in {db_name}"

        print("tables details {}".format(get_table_query))
        df = spark.sql(get_table_query)
        display(df)
    return df
        

# COMMAND ----------

def create_databases(database_names):
    db_list = []
    for db_name in database_names:
        layer = db_name.split("_")[2]
        layer_1= layer.upper()
        data = db_name.split("_")[-1]
        path = f"s3://tpc-aws-ted-dev-edpp-{layer}-com-ap-northeast-1/ddt"
        sep = "'"
        drop_db_query = f"DROP DATABASE IF EXISTS {db_name};"
        spark.sql(drop_db_query)
        if data == 'rwd':
            create_db_query = f"CREATE DATABASE IF NOT EXISTS {db_name} Location {sep}{path}/{db_name}.db{sep} COMMENT {sep}{layer_1} Layer RWD Database for DDT Team{sep};"
        else:
            create_db_query = f"CREATE DATABASE IF NOT EXISTS {db_name} Location {sep}{path}/{db_name}.db{sep} COMMENT {sep}{layer_1} Layer RWD {data} Database for DDT Team{sep};"
        print("database create query {}".format(create_db_query))
        spark.sql(create_db_query)
        alter_query = f"alter database {db_name} owner to `admins`;"
        spark.sql(alter_query)
        print(f"Created database: {db_name}")
        db_list.append(db_name)
    return db_list

# COMMAND ----------

# alter_query = f"alter database {db_name} owner to `admins`;"
        # spark.sql(alter_query)

# COMMAND ----------

database_names = ["com_jp_lake_ddt_rwd","com_jp_hub_ddt_rwd","com_jp_mart_ddt_rwd","com_jp_alyt_ddt_rwd","com_jp_raw_ddt_rwd_common","com_jp_lake_ddt_rwd_common","com_jp_hub_ddt_rwd_common","com_jp_mart_ddt_rwd_common","com_jp_alyt_ddt_rwd_common","com_jp_raw_ddt_rwd_hemophilia","com_jp_lake_ddt_rwd_hemophilia","com_jp_hub_ddt_rwd_hemophilia","com_jp_mart_ddt_rwd_hemophilia","com_jp_alyt_ddt_rwd_hemophilia","com_jp_raw_ddt_rwd_sbs","com_jp_lake_ddt_rwd_sbs","com_jp_hub_ddt_rwd_sbs","com_jp_mart_ddt_rwd_sbs","com_jp_alyt_ddt_rwd_sbs","com_jp_raw_ddt_rwd_tak625","com_jp_lake_ddt_rwd_tak625","com_jp_hub_ddt_rwd_tak625","com_jp_mart_ddt_rwd_tak625","com_jp_alyt_ddt_rwd_tak625","com_jp_raw_ddt_rwd_uc_cd","com_jp_lake_ddt_rwd_uc_cd","com_jp_hub_ddt_rwd_uc_cd","com_jp_mart_ddt_rwd_uc_cd","com_jp_alyt_ddt_rwd_uc_cd","com_jp_raw_ddt_rwd_test","com_jp_lake_ddt_rwd_test","com_jp_hub_ddt_rwd_test","com_jp_mart_ddt_rwd_test","com_jp_alyt_ddt_rwd_test"]
create_databases(database_names)


# COMMAND ----------

database_names = ["com_jp_lake_ddt_rwd","com_jp_hub_ddt_rwd","com_jp_mart_ddt_rwd","com_jp_alyt_ddt_rwd","com_jp_raw_ddt_rwd_common","com_jp_lake_ddt_rwd_common","com_jp_hub_ddt_rwd_common","com_jp_mart_ddt_rwd_common","com_jp_alyt_ddt_rwd_common","com_jp_raw_ddt_rwd_hemophilia","com_jp_lake_ddt_rwd_hemophilia","com_jp_hub_ddt_rwd_hemophilia","com_jp_mart_ddt_rwd_hemophilia","com_jp_alyt_ddt_rwd_hemophilia","com_jp_raw_ddt_rwd_sbs","com_jp_lake_ddt_rwd_sbs","com_jp_hub_ddt_rwd_sbs","com_jp_mart_ddt_rwd_sbs","com_jp_alyt_ddt_rwd_sbs","com_jp_raw_ddt_rwd_tak625","com_jp_lake_ddt_rwd_tak625","com_jp_hub_ddt_rwd_tak625","com_jp_mart_ddt_rwd_tak625","com_jp_alyt_ddt_rwd_tak625","com_jp_raw_ddt_rwd_uc_cd","com_jp_lake_ddt_rwd_uc_cd","com_jp_hub_ddt_rwd_uc_cd","com_jp_mart_ddt_rwd_uc_cd","com_jp_alyt_ddt_rwd_uc_cd","com_jp_raw_ddt_rwd_test","com_jp_lake_ddt_rwd_test","com_jp_hub_ddt_rwd_test","com_jp_mart_ddt_rwd_test","com_jp_alyt_ddt_rwd_test"
]
# create_databases(database_names)
databases_tables(database_names)

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC show tables in com_jp_mart_ddt_rwd_test

# COMMAND ----------

# MAGIC %sql
# MAGIC desc database com_jp_mart_ddt_rwd

# COMMAND ----------

# MAGIC %sql
# MAGIC alter database com_jp_hub_ddt_rwd owner to `admins`;

# COMMAND ----------

# MAGIC %sql
# MAGIC desc database com_jp_hub_ddt_rwd

# COMMAND ----------

# MAGIC %sql
# MAGIC show tables in com_jp_alyt_ddt_rwd

# COMMAND ----------

for db_name in database_names:
        layer = db_name.split("_")[2].upper()
        data = db_name.split("_")[-1]
        path = f"s3://tpc-aws-ted-dev-edpp-{layer}-com-ap-northeast-1/ddt"
        sep = "'"
        if data == 'rwd':
            create_db_query = f"CREATE DATABASE IF NOT EXISTS {db_name} Location {sep}{path}/{db_name}.db{sep} COMMENT {sep}{layer} Layer RWD Database for DDT Team{sep};"
        else:
            create_db_query = f"CREATE DATABASE IF NOT EXISTS {db_name} Location {sep}{path}/{db_name}.db{sep} COMMENT {sep}{layer} Layer RWD {data} Database for DDT Team{sep};"
        print("database create query {}".format(create_db_query))
        #spark.sql(create_db_query)
        print(f"Created database: {db_name}")

# COMMAND ----------

"com_jp_lake_ddt_rwd","com_jp_hub_ddt_rwd","com_jp_mart_ddt_rwd","com_jp_alyt_ddt_rwd"


# COMMAND ----------



# COMMAND ----------

string = "com_jp_alyt_ddt_rwd"
layer = string.split("_")[-1]
path = f"s3://tpc-aws-ted-dev-edpp-{layer}-com-ap-northeast-1/ddt"
path
