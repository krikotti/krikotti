# Databricks notebook source
# MAGIC %py
# MAGIC #CORPSecuredServAccount 
# MAGIC group_names = ["296154d6-ee82-48a2-997d-c005c76668fb"]
# MAGIC database_names = ['corp_de_raw','corp_de_lake','corp_de_hub','corp_de_mart']
# MAGIC privileges = "ALL PRIVILEGES"
# MAGIC
# MAGIC for group_name in group_names:
# MAGIC     for database_name in database_names:
# MAGIC         query = "GRANT {} ON DATABASE {} TO `{}`".format(privileges, database_name, group_name)
# MAGIC         spark.sql(query)
# MAGIC         print("query",query)
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC GRANT SELECT, MODIFY ON any file to `296154d6-ee82-48a2-997d-c005c76668fb`;
