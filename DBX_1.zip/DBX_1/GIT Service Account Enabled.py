# Databricks notebook source
import requests

url = 'https://onetakeda-jpdev.cloud.databricks.com/api/2.0/git-credentials'
token='dapic21878d07ed5c5b6225f976213c0dd22'
headers = {
    'Content-Type': 'application/scim+json',
    'Authorization': 'Bearer ' + token
}
data = {
    'personal_access_token': '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',
    'git_username': 'COMJPDDTETLServAccount',
    'git_provider': 'gitHub'
}

response = requests.post(url, headers=headers, json=data)
print(response.text)

