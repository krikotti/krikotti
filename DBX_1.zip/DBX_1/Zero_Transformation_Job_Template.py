# Databricks notebook source
# MAGIC %md
# MAGIC **schema_list:** It contains one or more schemas delimited by comma(,)<br/>
# MAGIC **source_path:** It contains the file path to be read. Provide folder path to read multiple files<br/>
# MAGIC **table_name:** It contains the name of the table to be created or to have data appended to it<br/>
# MAGIC
# MAGIC **Note:** This Template supports ingestion for the files of CSV format only
# MAGIC

# COMMAND ----------

from pyspark.sql import SparkSession

def create_databricks_table():
    # Create a SparkSession or get an existing one
    spark = SparkSession.builder.getOrCreate()

    #Variable Initialization
    file_path = dbutils.widgets.get('source_path')
    table_name = dbutils.widgets.get('table_name')
    schema_list = dbutils.widgets.get('schema_list').split(',')

    if [var for var in (file_path, table_name, schema_list) if var == "" or var is None]:
        raise Exception("One Or More Parameters Are Empty/Null. Please Provide Values For All Parameters")
    
    print(f"file_path: {file_path}")
    print(f"table_name: {table_name}")
    print(f"schema_list: {schema_list}")

    #Listing All The Files In The Location
    file_list = dbutils.fs.ls(file_path)
    file_to_read = [
        x.path for x in file_list if x.path.split(".")[-1].upper() == "CSV"
    ][-1]

    # Read the CSV file into a DataFrame
    df = (
        spark.read.option("header", "true")
        .option("inferSchema", "true")
        .csv(file_to_read)
    )

    # List to store the column names and data types
    schema = []

    # Check if the table already exists in the catalog
    #table_exists = spark.catalog.tableExists(table_name)
    table_exists = spark.catalog._jcatalog.tableExists(table_name)

    # Iterate over each column in the DataFrame
    for column_name, data_type in df.dtypes:
        if table_exists:
            # If the table exists, check if the column already exists in the table schema
            table_schema = spark.catalog.listColumns(table_name)
            column_exists = any(field.name == column_name for field in table_schema)
            if not column_exists:
                # Append the column name and original data type to the schema list
                schema.append(f"{column_name} {data_type}")
        else:
            # If the table doesn't exist, append the column name and original data type to the schema list
            schema.append(f"{column_name} {data_type}")

    if table_exists:
        # If the table exists, create an ALTER TABLE statement to add the columns
        create_table_stmt = f"ALTER TABLE {table_name} ADD COLUMN {', '.join(schema)}"
    else:
        # If the table doesn't exist, create a CREATE TABLE statement with the specified columns
        create_table_stmt = (
            f"CREATE TABLE IF NOT EXISTS {table_name} ({', '.join(schema)})"
        )

    if schema:
        # If there are columns to be added, execute the create_table_stmt to create or alter the table
        spark.sql(create_table_stmt)

    
    for schema in schema_list:
        # Create the table if it doesn't exist
        if not table_exists:
            spark.sql(create_table_stmt)
            df.write.mode("overwrite").format("delta").saveAsTable(
                "{}.{}".format(schema, table_name)
            )
            print("Table Created And Data Added Successfully")
        else:
            # If the table exists, append the data to the existing table
            df.write.mode("append").format("delta").saveAsTable(
                "{}.{}".format(schema, table_name)
            )
            print("Table Already Exists And Appended Data Successfully")

# Call the create_databricks_table function
create_databricks_table()
