CREATE TABLE dbx_uc_usdev.abc_us_hub.audit_table (
  USERNAME STRING,
  USER_ID BIGINT,
  JOB_ID BIGINT,
  RUN_ID BIGINT,
  JOB_NAME STRING,
  TRIGGER_TYPE STRING,
  OPERATION_TIMESTAMP TIMESTAMP,
  VERSION BIGINT,
  OPERATION STRING,
  SRC_SYSTEM STRING,
  TGT_TBL_NM STRING,
  AUD_DTM TIMESTAMP,
  SRC_TOTAL_RECORDS BIGINT,
  TGT_TOTAL_RECORDS BIGINT,
  TGT_RECORDS_INSERTED BIGINT,
  TGT_RECORDS_UPDATED BIGINT,
  TGT_RECORDS_DELETED BIGINT,
  TGT_RECORDS_SKIPPED BIGINT,
  CLUSTER_ID STRING)
USING delta
LOCATION 's3://abcd-us-east-1/abc_us_hub/PPM/audit_table/DELTA';

Sample:
USERNAME	USER_ID	JOB_ID	RUN_ID	JOB_NAME	TRIGGER_TYPE	OPERATION_TIMESTAMP	VERSION	OPERATION	SRC_SYSTEM	TGT_TBL_NM	AUD_DTM	SRC_TOTAL_RECORDS	TGT_TOTAL_RECORDS	TGT_RECORDS_INSERTED	TGT_RECORDS_UPDATED	TGT_RECORDS_DELETED	TGT_RECORDS_SKIPPED	CLUSTER_ID
kkk@gmail	101724			null	null	2022-03-15T07:36:33.000+00:00	8	MERGE	hub	abc_us_hub.txn_disco_input_ppm_glbl_stg 	2022-04-28T11:38:34.558+00:00		7772	1616	0	0	0	0927-170152-arid674


CREATE TABLE dbx_uc_usdev.abc_us_hub.audit_log (
  OPERATION_TIMESTAMP TIMESTAMP COMMENT 'The timestamp of the operation, indicating when the action was performed.',
  OPERATION_TYPE STRING COMMENT 'Represents the type of operation that was executed, such as insert, update, or delete.',
  SRC_SYSTEM STRING COMMENT 'The name of the source system that initiated the operation.',
  SRC_TBL_NM STRING COMMENT 'The name of the source table from which the operation originated.',
  TGT_TBL_NM STRING COMMENT 'The name of the target table where the operation was applied.',
  TGT_RECORDS_INSERTED BIGINT COMMENT 'The number of records inserted into the target table as a result of the operation.',
  TGT_RECORDS_UPDATED BIGINT COMMENT 'The number of records updated in the target table as a result of the operation.',
  TGT_RECORDS_DELETED BIGINT COMMENT 'The number of records deleted from the target table as a result of the operation.',
  CLUSTER_ID STRING COMMENT 'A unique identifier for the cluster that the operation was associated with. This can be used to track and analyze operations within specific clusters.')
USING delta
COMMENT 'The \'audit_log\' table records all operations performed on the US hub\'s data. It includes details such as the timestamp, operation type, source system, target table, and the number of records inserted, updated, and deleted. This data can be used to monitor and analyze the activity on the US hub, providing insights into the frequency and nature of data operations. It can also be used to track the performance of the hub and identify potential issues or bottlenecks.'
LOCATION 's3://tpc-aws-ted-dev-edpp-hub-gms-us-east-1/abc_us_hub/PPM/audit_log_n/DELTA';

Sample Record:
OPERATION_TIMESTAMP	OPERATION_TYPE	SRC_SYSTEM	SRC_TBL_NM	TGT_TBL_NM	TGT_RECORDS_INSERTED	TGT_RECORDS_UPDATED	TGT_RECORDS_DELETED	CLUSTER_ID
2022-04-26T12:39:40.000+00:00	MERGE	HUB	abc_us_hub.source_dummy	abc_us_hub.target_dummy	2	0	0	0224-170209-doors220