# Databricks notebook source
# MAGIC %md
# MAGIC # Here is the ask :
# MAGIC
# MAGIC
# MAGIC 1.	Check the table for status <> Added or Removed.
# MAGIC 2.	We need to check whether user is available in E2
# MAGIC 3.	We need to check whether group is available in E2
# MAGIC 4.	If 2,3, are true then perform Action to ‘Add’ or ‘Remove’ user from the group based on the Action Column.
# MAGIC     o	Update Status to “Added” or “Removed” based on the action
# MAGIC     o	Update Action Date
# MAGIC 5.	If 2,3 are not true, please add in the comments of missing components
# MAGIC     o	Update Status to ‘Review Needed’
# MAGIC     o	Update Action Date
# MAGIC 6.	Trigger an email if we need to Review items / access.
# MAGIC 7.	Job has to run daily twice.
# MAGIC

# COMMAND ----------

dbutils.widgets.text(name="ENV",defaultValue="dev",label="ENVIRONMENT")


# COMMAND ----------

# MAGIC %md
# MAGIC #environment

# COMMAND ----------

# env =dbutils.notebook.entry_point.getDbutils().notebook().getContext().tags().get("browserHostName").get()
env = dbutils.widgets.get("ENV")
env = 'onetakeda-de{}.cloud.databricks.com'.format(env)

# COMMAND ----------

# MAGIC %md
# MAGIC #Libraries

# COMMAND ----------

import requests
import json
import pandas as pd
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
import numpy as np
import boto3
from botocore.exceptions import ClientError

# COMMAND ----------

# MAGIC %md
# MAGIC # Extract the DBX Account Credentiols from Secrets Manager to invoke the DBX API

# COMMAND ----------

### Extract the DBX Account Credentiols from Secrets Manager to invoke the DBX API

# COMMAND ----------

# MAGIC %run ./account_details

# COMMAND ----------

# MAGIC %md
# MAGIC #email_notification

# COMMAND ----------

SMTP_SERVER_HOST = "smtprelay-emear.onetakeda.com"
SMTP_SERVER_PORT = 25
EMAIL_SENDER = "GCCS.Insight.and.Analytics@takeda.com"



# COMMAND ----------

scim_api = "api/2.0/preview/scim/v2"
account_api = "https://accounts.cloud.databricks.com/api/2.0/accounts"

# COMMAND ----------

def email_notification(input_data):
    subject = ' Review needed : '
    # message = "This is a message from EDB. You can even attach a table:"
    recipients = ["Kranthi-Kumar.Sreeram@takeda.com","Matthias.Palmetshofer@takeda.com","Kirill.Otyutskiy@takeda.com","Narasimman.Jayaraman@takeda.com","jeremy.markson@takeda.com","krishna-reddy.kotti@takeda.com"]

    # Set up the email message
    msg = MIMEMultipart()
    msg['From'] = EMAIL_SENDER # who appears to be sending the email
    msg['To'] = ",".join(recipients) # who appears to be recieving the email (different from what you pass to server.sendmail())
    msg['Subject'] = subject
    msg.attach(MIMEText("Hi Team,<br><br>we have few access request for review please find the enclosed list.<br>{}<br><br>Thankyou<br>Cx Facing Shared Platforms and Services – I&A".format(input_data), 'html')) # I often use df.to_html() and attach to the mail.

    # Send the email
    with smtplib.SMTP(SMTP_SERVER_HOST, 25) as smtp:
        smtp.starttls()
        smtp.send_message(msg)
        print("successfully sent email to %s:" %(msg['To']))

# COMMAND ----------

# MAGIC %md 
# MAGIC #create Account Group

# COMMAND ----------

# import requests

# def create_account_group(account_id, name, description):

#   url = "https://accounts.cloud.databricks.com/api/2.0/accounts/{}/scim/v2/Groups".format(account_id)
#   auth = (admin_user_email, admin_user_password)
#   headers = {"Content-Type": "application/json"}
#   data = {"displayName": name, "description": description}

#   response = requests.post(url, headers=headers, data=json.dumps(data),auth=auth)
#   return response

# if __name__ == "__main__":
#   account_id = account_id
#   name = "COM_DE_AKV"
#   description = "This is my account group"

#   response = create_account_group(account_id, name, description)
#   print(response.text)


# COMMAND ----------

# MAGIC %md
# MAGIC ##fetching group_id and group_type

# COMMAND ----------

grp_df=pd.DataFrame(columns=["displayName","members","groups","id","meta.resourceType","entitlements","roles"])
def fetch_group_id(group):
    global grp_df
    grp_df=pd.DataFrame(columns=["displayName","members","groups","id","meta.resourceType","entitlements","roles"])
    api_command = f'{scim_api}/Groups?filter=displayName+eq+{group}'
    url = f"https://{env}/{api_command}"
    auth = (admin_user_email, admin_user_password)
    headers = {
        "Content-Type": "application/json"
    }
    response = requests.get(
    url = url,
    headers=headers,auth=auth
    )
    print(response)
    if response.status_code == 200:
        response_grp =json.loads(response.text)
        df1=pd.json_normalize(response_grp["Resources"])
        grp_df=pd.concat([grp_df,df1])
        grp_df=grp_df.explode("members")
        grp_df["member_extract"]=grp_df["members"].apply(lambda x:x.get("display") if type(x)==type({}) else None)
        grp_df["member_id"]=grp_df["members"].apply(lambda x:x.get("value") if type(x)==type({}) else None)
        return grp_df
    else:
        print(f"Error: {response.status_code} - {response.text}")

# COMMAND ----------

# MAGIC %md
# MAGIC ##fetching user_id

# COMMAND ----------

def fetch_user_id(user):
    #scim_api = "api/2.0/preview/scim/v2"
    api_command = f'{scim_api}/Users?filter=userName+eq+{user}'
    url = f"https://{env}/{api_command}"
    auth = (admin_user_email, admin_user_password)
    headers = {
        "Content-Type": "application/json"
    }
    response = requests.get(
    url = url,
    headers=headers,auth=auth
    )
    print(response)
    response_user =json.loads(response.text)
    df_user=pd.json_normalize(response_user["Resources"])
    return df_user


# COMMAND ----------

# MAGIC %md
# MAGIC #adding user_id in groups

# COMMAND ----------

def add_user(env,id_grp,id_user,grp_type):
    try:
        if(grp_type == 'WorkspaceGroup'):
            api_command = f'{scim_api}/Groups/{id_grp}'
            url = f"https://{env}/{api_command}"
        elif(grp_type == 'Group'):
            url=f"{account_api}/{account_id}/scim/v2/Groups/{id_grp}"
        # NEVER TO USE "PUT" method. IT'll remove all the existing users that are there in the group and add the one that you are passing
        auth = (admin_user_email, admin_user_password)
        headers = {"Content-Type": "application/json"}
        response = requests.patch(
        url = url,
        json = {
                "Operations": [
                    {
                        "op":"add",
                        "value": {
                            "members": [
                            {
                                "value":id_user
                            }
                            ]
                        }
                    }
                    ]
                },
            headers=headers,auth=auth
                )
        print('var3 response : ',response)
        var3 =json.loads(response.text)
        print(var3)
    except:
        print(response.text)
        print("somthing error")


    

# COMMAND ----------

# MAGIC %md
# MAGIC #revoking user_id in groups

# COMMAND ----------

def rm_user(env,id_grp,id_user,grp_type):
    try:
        if(grp_type == 'WorkspaceGroup'):
            api_command = f'api/2.0/preview/scim/v2/Groups/{id_grp}'
            url = f"https://{env}/{api_command}"
        elif(grp_type == 'Group'):
            url=f"{account_api}/{account_id}/scim/v2/Groups/{id_grp}"
        # NEVER TO USE "PUT" method. IT'll remove all the existing users that are there in the group and add the one that you are passing
        auth = (admin_user_email, admin_user_password)
        headers = {"Content-Type": "application/json"}
        response = requests.patch(
        url = url,
        json = {
                        "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
                        "Operations": [
                            {
                                "op": "remove",
                                "path": "members",
                                "value": [
                                    {
                                        "value": id_user,
                                        "type": "User"
                                    }
                                ]
                            }
                        ]
                    },
            headers=headers,auth=auth
                )
        print('var3 response : ',response)
        var3 =json.loads(response.text)
        print(var3)
    except:
        print(response.text)
        print("somthing error")


    

# COMMAND ----------

# MAGIC %md
# MAGIC #fetching user_list and group_list

# COMMAND ----------

user_list=spark.sql("show users").toPandas()["name"].tolist()
group_list=spark.sql("show groups").toPandas()["name"].tolist()

# COMMAND ----------

# MAGIC %md
# MAGIC #converting all user_list and group_list into lower case

# COMMAND ----------

def lw(x):
    return x.lower()

# COMMAND ----------

group_list=list(map(lw,group_list))
user_list=list(map(lw,user_list))

# COMMAND ----------

# MAGIC %md
# MAGIC #fetching the table for status <> Added or Removed.

# COMMAND ----------

main_table=spark.sql("select * from com_de_lake.GPD_DBX_ACCESS_REQ_STG where  Status is null or status = 'Review Needed'").collect()

# COMMAND ----------

# MAGIC %md
# MAGIC #main code

# COMMAND ----------


if main_table:  #added Krishna 09/27
    for i in main_table:
        check_user=i[1].lower().strip() in user_list # takeing user from main table and checking whether user is available in E2
        check_group=i["GroupName"].lower().strip() in group_list  # takeing group from main table and checking whether group is available in E2
        if check_user and check_group:  #if both user and group present in E2
            print(i["AccessType"],i[1],i["GroupName"]) #just printing access type, user email and group name from main table
            grp_df=fetch_group_id(i["GroupName"]) #passing group name in fetch_group_id function
            grp_id=grp_df["id"].unique().tolist()[0] #fetching group id
            grp_type=grp_df["meta.resourceType"].unique().tolist()[0]  #fetching group type
            grp_member=grp_df["member_id"].unique().tolist() #fetching list of members present in group
            print(grp_id,grp_type,grp_member) #just printing group id, group type, list of members in group

            user_df=fetch_user_id(i[1].lower()) #passing user email in fetch_user_id function
            user_id=user_df["id"].unique().tolist()[0] #fetching userid from email
            print(user_id) #just printing user id
            if user_id in grp_member: # if user present in list of members in group
                if i["AccessType"].lower()=="revoke": #if access type is revoke
                    print("revoke") #just printing revoke
                    rm_user(env,grp_id,user_id,grp_type) #passing details in rm_user function to remove user from group
                    print("update com_de_lake.GPD_DBX_ACCESS_REQ_STG set Status='Removed' ,Comments='user removed from group' Action_Date = curdate() where Req_ID='{}'".format(i[0]),i[1],i["GroupName"]) #just printing
                    spark.sql("update com_de_lake.GPD_DBX_ACCESS_REQ_STG set Status='Removed',Comments='user removed from group' ,Action_Date = curdate() where Req_ID='{}'".format(i[0])) #this will update the main table status to removed
                elif i["AccessType"].lower()=="add": #if access type is add
                    print("already present(add)") #print already present because user id already available in list of members in group
                    print("update com_de_lake.GPD_DBX_ACCESS_REQ_STG set Comments='user already exists in group' Action_Date = curdate() where Req_ID='{}'".format(i[0]),i[1],i["GroupName"])
                    spark.sql("update com_de_lake.GPD_DBX_ACCESS_REQ_STG set Status='no action Needed',Comments='user already exists in group' ,Action_Date = curdate() where Req_ID='{}'".format(i[0])) #this will update the main table status to no action needed user already present in group
            else:  #if userid not present in list of members in group
                if i["AccessType"].lower()=="revoke":# if access type is revoke
                    print("user not present(revoke)") # just printing user not present in group
                    print("update com_de_lake.GPD_DBX_ACCESS_REQ_STG set Comments='user not exists in group' Action_Date = curdate() where Req_ID='{}'".format(i[0]),i[1],i["GroupName"])
                    spark.sql("update com_de_lake.GPD_DBX_ACCESS_REQ_STG set Status='no action Needed',Comments='user not exists in group', Action_Date = curdate() where Req_ID='{}'".format(i[0])) #this will update the main table status to no action needed user already not present in group

                elif i["AccessType"].lower()=="add": #if access type is add
                    print("add") #just printing add
                    add_user(env,grp_id,user_id,grp_type) # passing details in add user function this will add user in the group
                    print("update com_de_lake.GPD_DBX_ACCESS_REQ_STG set Comments='user added in group' ,Action_Date = curdate() where Req_ID='{}'".format(i[0]),i[1],i["GroupName"])
                    spark.sql("update com_de_lake.GPD_DBX_ACCESS_REQ_STG set Status='Added',Comments='user added in group', Action_Date = curdate() where Req_ID='{}'".format(i[0])) #this will update the main table status to Added
                    



        elif check_user == False and check_group == False: #if user and group both not available in E2
            print("update com_de_lake.GPD_DBX_ACCESS_REQ_STG set Comments='user and group not exists',Status='Review Needed', where Req_ID='{}'".format(i[0]),i[1],i["GroupName"])
            spark.sql("update com_de_lake.GPD_DBX_ACCESS_REQ_STG set Status='Review Needed',Comments='user and group not exists' Action_Date = curdate() where Req_ID='{}'".format(i[0])) #this will update the main table status to review needed and add comments that both user and group not available in E2.
        elif check_user == False: #if only user not available in E2
            print("update com_de_lake.GPD_DBX_ACCESS_REQ_STG set Comments='user not exists' where Req_ID='{}'".format(i[0]),i[1],i["GroupName"])
            spark.sql("update com_de_lake.GPD_DBX_ACCESS_REQ_STG set Status='Review Needed',Comments='user not exists' ,Action_Date = curdate() where Req_ID='{}'".format(i[0])) #this will update the main table status to review needed and add comments that user not available in E2.
        elif check_group == False: #if only group not available in E2
            print("update com_de_lake.GPD_DBX_ACCESS_REQ_STG set Comments='group not exists' where Req_ID='{}'".format(i[0]),i[1],i["GroupName"])
            spark.sql("update com_de_lake.GPD_DBX_ACCESS_REQ_STG set Status='Review Needed',Comments='group not exists', Action_Date = curdate() where Req_ID='{}'".format(i[0]))  #this will update the main table status to review needed and add comments that group not available in E2.
else:
    print("No Users to add or remove from source table")
    

# COMMAND ----------

# MAGIC %md
# MAGIC # mail sent to team if status is 'Review Needed'

# COMMAND ----------

df_mail=spark.sql("select Req_ID,Email,GroupName,Status,Action_Date,Comments from com_de_lake.GPD_DBX_ACCESS_REQ_STG where Status ='Review Needed' ").toPandas()
if df_mail.empty:
    print("No users access to Review")
else:
    print("Review Needed")
    email_notification(df_mail.to_html()) # this will send the mail whose status is review needed in main table