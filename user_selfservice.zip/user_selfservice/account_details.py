# Databricks notebook source
# MAGIC %md ## ***#DBX Account Details Retrivel from Secrets Manager ***

# COMMAND ----------

##Imports
import boto3
from botocore.exceptions import ClientError
import json

# COMMAND ----------

### Extract the DBX Account Credentiols from Secrets Manager to invoke the DBX API
def get_account_credentials():

    secret_arn = 'arn:aws:secretsmanager:us-east-1:263789222982:secret:sc_dbx_account_details-Ec3l0U'
    region_name = "us-east-1"
    acc_user = "account_admin_user_name"
    acc_pwd = "account_admin_password"
    acc_id = "dbx_account_id"

    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name,
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_arn
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'ResourceNotFoundException':
            print("The requested secret " + secret_arn + " was not found")
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            print("The request was invalid due to:", e)
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            print("The request had invalid params:", e)
        else:
          raise
    else:
        # Secrets Manager decrypts the secret value using the associated KMS CMK
        # Depending on whether the secret was a string or binary, only one of these fields will be populated
        #print(get_secret_value_response)
        if 'SecretString' in get_secret_value_response:
            text_secret_data = get_secret_value_response['SecretString']
            # Parse the JSON string into a Python dictionary
            data = json.loads(text_secret_data)
            # Access the value of the specific key
            acc_usr_name = data.get(acc_user)
            acc_usr_pwd = data.get(acc_pwd)
            dbx_acc_id = data.get(acc_id)
        else:
            binary_secret_data = get_secret_value_response['SecretString']
            # Parse the JSON string into a Python dictionary
            data = json.loads(text_secret_data)
            # Access the value of the specific key
            acc_usr_name = data.get(acc_user)
            acc_usr_pwd = data.get(acc_pwd)
            dbx_acc_id = data.get(acc_id)
            
        return acc_usr_name,acc_usr_pwd,dbx_acc_id


# COMMAND ----------

admin_user_email,admin_user_password,account_id = get_account_credentials()