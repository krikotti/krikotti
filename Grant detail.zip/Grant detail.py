# Databricks notebook source
import pandas as pd

# COMMAND ----------

# MAGIC %md
# MAGIC #Database level

# COMMAND ----------

# MAGIC %md
# MAGIC ##Retrive Databases details

# COMMAND ----------

schema_df= spark.sql("show databases").toPandas()["databaseName"].tolist()

# COMMAND ----------

# MAGIC %md
# MAGIC ##Check Access Permissions for each database

# COMMAND ----------

final_df_schema=pd.DataFrame()
non_Access_db=[]
for i in schema_df:
  try:
    df_schema=spark.sql("show grant on database {}".format(i)).toPandas()
    df_schema["database"]=i
    final_df_schema=pd.concat([final_df_schema,df_schema])
  except:
    non_Access_db.append(i)


# COMMAND ----------

final_df_schema

# COMMAND ----------

# MAGIC %md
# MAGIC #non access databases

# COMMAND ----------

print(len(non_Access_db))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Store data into a table
# MAGIC ### com_de_lake.schema_permissions

# COMMAND ----------

# create table com_de_lake.schema_permissions 

# COMMAND ----------

sdf_schema=spark.createDataFrame(final_df_schema)
sdf_schema.write.mode("overwrite").format("delta").saveAsTable("com_de_alyt_gem.schema_permissions_E2")

# COMMAND ----------

# MAGIC %md
# MAGIC #Table level

# COMMAND ----------

# MAGIC %md
# MAGIC ## Retrive COM_* databases

# COMMAND ----------

required_schema=[]
for i in schema_df:
  if i.startswith("com_"):
    required_schema.append(i)
required_schema

# COMMAND ----------

non_access_tables=[]
df_final=pd.DataFrame()
for i in required_schema:
  table=spark.sql("show tables from {}".format(i)).toPandas()["tableName"].tolist()
  
  for j in table:
    try:
      print("show grant on {}.{}".format(i,j))
      df2=spark.sql("show grant on {}.{}".format(i,j)).toPandas()
      df2["tableName"]=j
      df2["database"]=i
      df_final=pd.concat([df_final,df2])
    except:
      non_access_tables.append((i,j))
      

# COMMAND ----------

# MAGIC %md
# MAGIC # non Access Database.tables

# COMMAND ----------

pd.DataFrame(non_access_tables,columns=["Database","Tables"])

# COMMAND ----------

df_final

# COMMAND ----------

# MAGIC %md
# MAGIC #Store data into a table

# COMMAND ----------

sdf_tables=spark.createDataFrame(df_final)
sdf_tables.write.mode("overwrite").format("delta").saveAsTable("com_de_alyt_gem.table_permissions_E2")

# COMMAND ----------


