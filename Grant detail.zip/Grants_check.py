# Databricks notebook source
import datetime
today = datetime.datetime.today().weekday()
current_time = datetime.datetime.now().strftime("%H:%M")
start_time = datetime.datetime.strptime('0:05', '%H:%M').strftime("%H:%M")
end_time = datetime.datetime.strptime('4:05', '%H:%M').strftime("%H:%M")
ist_time = datetime.datetime.now() + datetime.timedelta(hours=5, minutes=30)
if today == 4:
  print("Today is Friday!")
  if start_time <= current_time <= end_time:
    print(f"Current time in UTC {current_time}")
    print(f"The current time in UTC+5:30 is {ist_time.strftime('%H:%M')}")
  else:
    print("The Job is not suppossed to run this time")
    print(f"Current time in UTC {current_time}")
    print(f"The current time in UTC+5:30 is {ist_time.strftime('%H:%M')}")
    dbutils.notebook.exit("STOP Processing")
else:
  print("Today is", datetime.date.today().strftime("%A")) 
  dbutils.notebook.exit("STOP Processing")

# COMMAND ----------

import numpy as np
import pandas as pd
import random
import datetime
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC #Database level

# COMMAND ----------

# MAGIC %md
# MAGIC ##Retrive Databases details

# COMMAND ----------

schema_df= spark.sql("show databases").toPandas()["databaseName"].tolist()

# COMMAND ----------

# MAGIC %md
# MAGIC ##Check Access Permissions for each database

# COMMAND ----------

final_df_schema=pd.DataFrame()
non_Access_db=[]
for i in schema_df:
  try:
    df_schema=spark.sql("show grant on database {}".format(i)).toPandas()
    df_schema["database"]=i
    final_df_schema=pd.concat([final_df_schema,df_schema])
  except:
    non_Access_db.append(i)


# COMMAND ----------

final_df_schema

# COMMAND ----------

# MAGIC %md
# MAGIC #non access databases

# COMMAND ----------

print(len(non_Access_db))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Store data into a table - com_de_lake.schema_permissions

# COMMAND ----------

sdf=spark.createDataFrame(final_df_schema)
sdf_schema =  sdf.withColumn("Date",lit(datetime.datetime.today().date()))
sdf_schema.write.mode("append").format("delta").saveAsTable("com_de_alyt_gem.schema_permissions_e2")

# COMMAND ----------

# MAGIC %md
# MAGIC #Table level

# COMMAND ----------

# MAGIC %md
# MAGIC ## Retrive COM* and CORP* databases

# COMMAND ----------

required_schema=[]
for i in schema_df:
  # if (i.startswith("com_de_lake") or i.startswith("com_de_hub")):
  if (i.startswith("com") or i.startswith("corp")):
    required_schema.append(i)
required_schema

# COMMAND ----------

# MAGIC %md
# MAGIC ## Retrive Table Permissions and Store

# COMMAND ----------

non_access_tables=[]

for i in required_schema:
  try:
    df_final=pd.DataFrame()
    table=spark.sql("show tables from {}".format(i)).toPandas()["tableName"].tolist()
    for j in table:
     try:
       df2=spark.sql("show grant on {}.{}".format(i,j)).toPandas()
       df2["tableName"]=j
       df2["database"]=i
       df_final=pd.concat([df_final,df2])
     except:
       non_access_tables.append((i,j))
    sdf=spark.createDataFrame(df_final)
    sdf_tables=sdf.withColumn("Date",lit(datetime.datetime.today().date()))
    sdf_tables.write.mode("append").format("delta").saveAsTable("com_de_alyt_gem.table_permissions_e2")
    print("Completed : {}".format(i))
  except :
    print("Check : {}".format(i)) 
      

# COMMAND ----------

# MAGIC %md
# MAGIC # non Access Database tables

# COMMAND ----------

pd.DataFrame(non_access_tables,columns=["Database","Tables"])

# COMMAND ----------

# MAGIC %md
# MAGIC #Optmize data into a table

# COMMAND ----------

# MAGIC %sql
# MAGIC OPTIMIZE com_de_alyt_gem.schema_permissions_e2;

# COMMAND ----------

# MAGIC %sql
# MAGIC OPTIMIZE com_de_alyt_gem.table_permissions_e2;
